# PocketFlow-main — Context for AI

27 workflows · 1 risk findings · 640 verified connections · 425 code sections

Attach this file and `chunks.jsonl` together. Every code reference below identifies a source section in `chunks.jsonl`.

## 1. Business workflows

### 1. resume screening summary

Workflow ID: `business_path_084e61af77726862`

Batch map-reduce path that reads resume files, evaluates each resume against qualification criteria with an LLM, and produces a qualification summary.

**Purpose:** evaluate candidate resumes and summarize who qualifies

**Business outcome**

- reduces manual screening work
- produces a shortlist summary for review

**Important behavior and rules**

- A resume qualifies only when the LLM-produced YAML marks qualifies: true.

**Identified functions:** `ReduceResultsNode.prep/exec`, `EvaluateResumesNode.prep/exec`, `ReadResumesNode.exec`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| EvaluateResumesNode | `cookbook/pocketflow-map-reduce/nodes.py` | `chunk_b40ba65d22b1811d` |

### 2. retrieval-augmented question answering

Workflow ID: `business_path_3572bdc890144d33`

Offline document indexing path and online retrieval path that chunk documents, create embeddings and a FAISS index, then retrieve a relevant document and generate an LLM answer.

**Purpose:** index documents and answer user queries from retrieved context

**Business outcome**

- builds a searchable vector index
- returns a query-specific answer grounded in retrieved text

**Important behavior and rules**

- Offline indexing flow must chunk documents before embedding them and building the index.
- Online answering flow must embed the query before retrieval and answer generation.

**Identified functions:** `get_offline_flow`, `EmbedDocumentsNode.exec`, `RetrieveDocumentNode.exec`, `get_online_flow`, `ChunkDocumentsNode.exec`, `GenerateAnswerNode.exec`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| ChunkDocumentsNode/CreateIndexNode/EmbedQueryNode/RetrieveDocumentNode/GenerateAnswerNode | `cookbook/pocketflow-rag/nodes.py` | `chunk_e56e02b3ec2d330c` |
| get_offline_flow/get_online_flow | `cookbook/pocketflow-rag/flow.py` | `chunk_eb550e87b5734336` |

### 3. PDF text extraction and consolidation

Workflow ID: `business_path_9c893ccf32af877c`

Batch PDF processing path that discovers PDFs, converts them to page images, extracts text from each page using a vision tool, and combines the results into final text.

**Purpose:** extract and combine page text from a directory of PDFs

**Business outcome**

- turns PDFs into machine-readable text
- preserves page order in the output

**Important behavior and rules**

- Only files ending in .pdf are added to the batch.
- Extracted page text is sorted by page number before combining.

**Identified functions:** `CombineResultsNode.exec`, `ProcessPDFBatchNode.prep/exec`, `ExtractTextNode.exec`, `LoadPDFNode.exec`, `create_single_pdf_flow`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| ProcessPDFBatchNode.prep | `cookbook/pocketflow-tool-pdf-vision/nodes.py` | `chunk_413529fdaffc2f0e` |

### 4. async recipe recommendation and approval loop

Workflow ID: `business_path_6e9675f16ad1547a`

recipe seeker user enters an ingredient, receives an LLM-generated recipe suggestion, and either accepts it or retries for another suggestion

**Purpose:** choose a recipe from fetched candidates for a user-provided ingredient

**Business outcome**

- reduces user effort in selecting a recipe
- supports iterative refinement until approval

**Important behavior and rules**

- The recipe suggestion loop continues until the user approves a choice or requests another suggestion.
- If answer == 'y', return accept; otherwise return retry

**Identified functions:** `cookbook/pocketflow-async-basic/flow.py:create_flow`, `cookbook/pocketflow-async-basic/nodes.py:FetchRecipes.prep_async`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| FetchRecipes.prep_async | `cookbook/pocketflow-async-basic/nodes.py` | `chunk_23ef461e7c54abc9` |
| create_flow | `cookbook/pocketflow-async-basic/flow.py` | `chunk_d9b8f79f285b6b83` |

### 5. browser task automation in DOM mode / browser task automation in vision mode

Workflow ID: `business_path_f833b4fcda311109`

CLI operator launches a DOM-based browser agent that reads interactive page elements, asks an LLM for one action, and executes click/type/select/press actions until done / CLI operator launches a screenshot-based browser agent that captures images, asks an LLM for coordinates, and performs mouse/keyboard actions until done

**Purpose:** complete a page goal one step at a time using numbered interactive elements / complete a page goal using screenshot grounding and coordinate clicks

**Business outcome**

- automates browser interactions for a user-specified goal
- provides deterministic action logging through shared history
- supports operating pages not easily represented in the DOM
- uses raw pointer and keyboard actions to complete tasks

**Important behavior and rules**

- The agent must choose exactly one action at a time from the YAML decision output.
- The browser interaction is grounded in DOM element numbers rather than pixel coordinates in DOM mode.
- The agent must operate from screenshot grounding rather than DOM element numbers in vision mode.
- Only one action is requested per decision step.
- Stop when decision action is done or when history length reaches MAX_STEPS
- Only visible interactive elements are added to the candidate list

**Identified functions:** `cookbook/pocketflow-browser-agent/flow.py:create_dom_agent_flow`, `cookbook/pocketflow-browser-agent/main.py:main`, `cookbook/pocketflow-browser-agent/nodes_dom.py:Observe`, `cookbook/pocketflow-browser-agent/nodes_vision.py:Observe`, `cookbook/pocketflow-browser-agent/flow.py:create_vision_agent_flow`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Observe.exec | `cookbook/pocketflow-browser-agent/nodes_dom.py` | `chunk_1d2cb7d506a68103` |
| main | `cookbook/pocketflow-browser-agent/main.py` | `chunk_57746f06c9458c84` |
| Observe.post | `cookbook/pocketflow-browser-agent/nodes_vision.py` | `chunk_92b119521ef41d0a` |
| _build_loop | `cookbook/pocketflow-browser-agent/flow.py` | `chunk_92dad70a2a593307` |
| call_llm | `cookbook/pocketflow-browser-agent/utils.py` | `chunk_e80c2423e0aa04c3` |

### 6. A2A task submission and answer delivery for a research agent

Workflow ID: `business_path_4bff8fc8bc9ba83a`

A CLI or A2A client submits a text task to the PocketFlow A2A server, the task manager executes the research flow, and the server returns a completed task response or error.

**Purpose:** Ask a question and receive an agent-produced answer

**Business outcome**

- Converts a user prompt into a tracked task
- Produces a final answer artifact after PocketFlow execution
- Provides structured JSON-RPC or SSE protocol responses

**Important behavior and rules**

- If the server has no OPENAI_API_KEY, startup aborts with a configuration error.
- Unsupported content types are rejected before task execution.
- Tasks are created in submitted state and then moved to working before PocketFlow runs.
- Streaming task subscription is not implemented for this synchronous PocketFlow agent.
- OPENAI_API_KEY must be present before server startup
- Accepted output modes must be compatible with the agent's supported content types
- Only text parts are accepted as the user query for task execution

**Identified functions:** `cookbook/pocketflow-a2a/a2a_client.py:cli`, `cookbook/pocketflow-a2a/common/server/server.py:_process_request`, `cookbook/pocketflow-a2a/a2a_server.py:main`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `cookbook/pocketflow-coding-agent/setup_test_project.py` | `chunk_0a562e566a9a8612` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_1436f3c92ebf3353` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_1cfb5186cdb2fbd4` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_293e94c319be932a` |
| Source section | `cookbook/pocketflow-a2a/common/client/client.py` | `chunk_2b5331fea6551925` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_2fc5452fd1a1beb4` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_3ca7865839c3b21f` |
| Source section | `cookbook/pocketflow-a2a/common/server/server.py` | `chunk_41ff20bbaff0cab5` |
| PocketFlowTaskManager | `cookbook/pocketflow-a2a/task_manager.py` | `chunk_4c358d219e17eae5` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_4e571f6d9165848b` |
| Source section | `cookbook/pocketflow-coding-agent/setup_test_project.py` | `chunk_4fd431e496fc7f9f` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_5765a357b9387587` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_62fd45475bcdd543` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_637231d6b5bd62e4` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_6a66bef065f88083` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_6d003c9cace40ee6` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_86f22ff56f90782f` |
| call_llm/search_web | `cookbook/pocketflow-a2a/utils.py` | `chunk_87517b3f8b466ff5` |
| setup_test_project | `cookbook/pocketflow-coding-agent/setup_test_project.py` | `chunk_8bd287c43c30451e` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_8c61e8dc796b1716` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_908d1fa56db85982` |
| are_modalities_compatible | `cookbook/pocketflow-a2a/common/server/utils.py` | `chunk_90c0fa73aefc1728` |
| Source section | `cookbook/pocketflow-a2a/common/server/task_manager.py` | `chunk_99d9eeda09ab2beb` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_9b7e43db24365714` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_a11ddf314127f8c9` |
| DecideAction/SearchWeb/AnswerQuestion | `cookbook/pocketflow-coding-agent/nodes.py` | `chunk_a2505e22d23b56bd` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_b309c2d441f5f203` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_d36f27cdca6e5912` |
| Source section | `cookbook/pocketflow-coding-agent/setup_test_project.py` | `chunk_d79e656d39f9e963` |
| DecideAction.exec | `cookbook/pocketflow-a2a/nodes.py` | `chunk_dc2da69a7e57986a` |
| cli | `cookbook/pocketflow-a2a/a2a_client.py` | `chunk_dc9f169f3970953d` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_dca92bcefced8e54` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_e63b0ad5bc01cc9e` |
| main | `cookbook/pocketflow-a2a/a2a_server.py` | `chunk_e9d7fbc93cbd97c6` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_ea776097a0f2551e` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_eac65360a190e24c` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_ef6168ecb0ca77ae` |
| Source section | `cookbook/pocketflow-a2a/common/types.py` | `chunk_f8d625203ad30154` |

### 7. LLM-assisted coding repair workflow for a generated SQL mini-project

Workflow ID: `business_path_995a7fa0a9211883`

A CLI coding agent creates a mini SQL project, then iteratively uses LLM-selected tools to inspect files, patch the workspace, and run commands until the task is done.

**Purpose:** Edit the project until the supplied tests pass

**Business outcome**

- Automates local code repair and verification
- Produces edited source files and summarized result output
- Creates a reproducible test harness for SQL engine implementation

**Important behavior and rules**

- The workflow requires the generated test project to be created before the flow runs.
- The agent must choose exactly one tool per decision step using JSON output.
- Patch edits require a uniquely identifiable old_str and are applied only once.
- The SQL project is generated with tests that define the required parser and executor behavior.
- The coding agent stops once MAX_STEPS is reached or the model chooses done
- Patch application only proceeds if old_str is found exactly once in the file content
- Unknown tools are rejected and converted into a retry action

**Identified functions:** `cookbook/pocketflow-coding-agent/main.py:main`, `cookbook/pocketflow-coding-agent/flow.py:create_coding_agent_flow`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| create_coding_agent_flow | `cookbook/pocketflow-coding-agent/flow.py` | `chunk_00fc381a5f9b0791` |
| Source section | `cookbook/pocketflow-coding-agent/setup_test_project.py` | `chunk_0a562e566a9a8612` |
| Source section | `cookbook/pocketflow-coding-agent/setup_test_project.py` | `chunk_25cc894a13273c65` |
| main | `cookbook/pocketflow-coding-agent/main.py` | `chunk_3dbea6f7aed0e718` |
| Source section | `cookbook/pocketflow-coding-agent/setup_test_project.py` | `chunk_4be169fa435134dc` |
| Source section | `cookbook/pocketflow-coding-agent/setup_test_project.py` | `chunk_4fd431e496fc7f9f` |
| call_llm | `cookbook/pocketflow-a2a/utils.py` | `chunk_87517b3f8b466ff5` |
| setup_test_project | `cookbook/pocketflow-coding-agent/setup_test_project.py` | `chunk_8bd287c43c30451e` |
| DecideAction.exec | `cookbook/pocketflow-coding-agent/nodes.py` | `chunk_a2505e22d23b56bd` |
| Source section | `cookbook/pocketflow-coding-agent/setup_test_project.py` | `chunk_d79e656d39f9e963` |
| Source section | `cookbook/pocketflow-coding-agent/setup_test_project.py` | `chunk_e83ac791053c5c29` |

### 8. Mini SQL query processing over local CSV tables

Workflow ID: `business_path_4a48a370b7a94f0b`

Caller supplies SQL text; tokenizer/parser build an AST; executor reads CSV-backed tables and returns filtered/projected/joined/aggregated rows.

**Purpose:** Run a subset SQL query and obtain result rows

**Business outcome**

- Produces query results from CSV-backed tables
- Supports filtering, joining, grouping, ordering, deduplication, and limiting

**Important behavior and rules**

- SELECT parsing preserves DISTINCT, selected columns, FROM table, optional alias, joins, filters, grouping, having, ordering, and limit in the AST.
- JOIN execution evaluates ON conditions against merged rows and keeps unmatched left rows for LEFT JOIN.
- Aggregate functions include COUNT, SUM, AVG, MIN, and MAX; COUNT(*) counts rows and COUNT(expr) counts non-None values.
- Unknown tokens raise SyntaxError during tokenization.
- Missing table names raise ValueError when a table has not been loaded.

**Identified functions:** `execute(ast)`, `parse(sql)`, `tokenize(sql)`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| _aggregate | `cookbook/pocketflow-coding-agent/test_project/db.py` | `chunk_09f8b5f53252cd62` |
| parse | `cookbook/pocketflow-coding-agent/test_project/db.py` | `chunk_10c5e8372f94d68c` |
| parse_select | `cookbook/pocketflow-coding-agent/test_project/db.py` | `chunk_21e514aa53b6a698` |
| load_csv/get_table/init_db | `cookbook/pocketflow-coding-agent/test_project/database.py` | `chunk_64bda7992f8536ca` |
| execute_join | `cookbook/pocketflow-coding-agent/test_project/db.py` | `chunk_97092911d346a4e2` |
| test_executor.py | `cookbook/pocketflow-coding-agent/test_project/test_executor.py` | `chunk_a8109773490d4892` |
| execute | `cookbook/pocketflow-coding-agent/test_project/db.py` | `chunk_ab5dba1f9fda9910` |
| tokenize | `cookbook/pocketflow-coding-agent/test_project/db.py` | `chunk_bd019cb54cd3e04b` |
| test_parser.py | `cookbook/pocketflow-coding-agent/test_project/test_parser.py` | `chunk_ed2788812765104c` |

### 9. Generate and publish interactive flow visualizations

Workflow ID: `business_path_5e295b3e652c70c5`

Flow graph is converted to JSON, written to disk with an HTML D3 visualization, and optionally served and opened in a browser.

**Purpose:** Inspect or share a PocketFlow graph in the browser

**Business outcome**

- Creates a browsable graph artifact
- Serves the artifact locally for interactive viewing
- Can auto-open the visualization in a browser

**Important behavior and rules**

- The visualization must use the flow name as the HTML title when no custom title is supplied.
- The HTML template loads D3.js from a CDN and uses data files written next to the HTML document.
- If serve is true, the helper returns both the file path and server details; otherwise it returns only the HTML path.
- If auto_open is true, the browser is opened automatically; otherwise only the URL is printed.

**Identified functions:** `create_d3_visualization(json_data, output_dir, filename, html_title)`, `serve_and_open_visualization(html_path, auto_open)`, `visualize_flow(flow, flow_name, serve, auto_open, output_dir, html_title)`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| __main__ | `cookbook/pocketflow-visualization/visualize.py` | `chunk_07e55f145dbf4c53` |
| flow_to_json | `cookbook/pocketflow-visualization/visualize.py` | `chunk_0f73f3fa366b8d42` |
| Source section | `cookbook/pocketflow-visualization/visualize.py` | `chunk_34dbfd21a06d4886` |
| Source section | `cookbook/pocketflow-visualization/visualize.py` | `chunk_90cc1126ca961f80` |
| serve_and_open_visualization | `cookbook/pocketflow-visualization/visualize.py` | `chunk_b692c06a00e5e60c` |
| start_http_server | `cookbook/pocketflow-visualization/visualize.py` | `chunk_c0fbe913a12d8d3b` |
| Source section | `cookbook/pocketflow-visualization/visualize.py` | `chunk_f40cc91caf19e1b9` |
| visualize_flow | `cookbook/pocketflow-visualization/visualize.py` | `chunk_f556a23e20f9477b` |
| Source section | `cookbook/pocketflow-visualization/viz/flow_visualization.html` | `chunk_fdddaab890b36cc4` |

### 10. LLM-assisted code generation and verification loop

Workflow ID: `business_path_d34988d5103a3c5f`

CLI user submits a coding problem, the system generates test cases, implements a run_code function, executes tests, and revises code until tests pass or iteration limit is reached.

**Purpose:** Produce a working function for a programming problem using generated tests and iterative revision

**Business outcome**

- Automates drafting and refinement of solution code
- Produces test-backed iterative improvement
- Surfaces final function implementation and test status

**Important behavior and rules**

- The generated solution must define a function named exactly run_code.
- If any test fails, the system enters a revise loop; if all pass, it exits successfully.
- Function output must contain def run_code
- Test execution stops revising after max_iterations

**Identified functions:** `create_code_generator_flow`, `cookbook/pocketflow-code-generator/main.py:main`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| main | `cookbook/pocketflow-code-generator/main.py` | `chunk_023ea21d45bf3acd` |
| Source section | `cookbook/pocketflow-code-generator/nodes.py` | `chunk_5b290d89e9d7352b` |
| Source section | `cookbook/pocketflow-code-generator/nodes.py` | `chunk_6a7f0600b863a918` |
| execute_python | `cookbook/pocketflow-code-generator/utils/code_executor.py` | `chunk_6eaa52bfc116b851` |
| call_llm | `cookbook/pocketflow-code-generator/utils/call_llm.py` | `chunk_b300a3fbf6f38664` |
| Source section | `cookbook/pocketflow-code-generator/nodes.py` | `chunk_cfafc7419e2aa1a0` |
| Source section | `cookbook/pocketflow-code-generator/nodes.py` | `chunk_f02c9c34cae8aba3` |
| create_code_generator_flow | `cookbook/pocketflow-code-generator/flow.py` | `chunk_f3328b96bf99f52d` |

### 11. Conversational memory retrieval and answer generation

Workflow ID: `business_path_5abe7af952e6a937`

Interactive chat user asks a question, the system retrieves a similar archived conversation using embeddings and FAISS, answers with the LLM, and archives older exchanges back into the vector store.

**Purpose:** Maintain a chat that can recall relevant past conversations while continuing the dialogue

**Business outcome**

- Improves continuity of long-running conversations
- Preserves older exchanges as searchable embeddings
- Returns an LLM-generated response informed by recent and retrieved context

**Important behavior and rules**

- Only the oldest user-assistant pair is archived when the recent message window grows beyond 6 messages.
- Retrieval uses k=1 most similar archived conversation.
- Do not archive unless there are more than 6 messages.
- Do not retrieve unless vector_index and vector_items exist and are non-empty.

**Identified functions:** `create_chat_flow`, `cookbook/pocketflow-chat-memory/main.py:run_chat_memory_demo`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| call_llm | `cookbook/pocketflow-chat-memory/utils/call_llm.py` | `chunk_09cbe2d8a973b866` |
| create_index / add_vector / search_vectors | `cookbook/pocketflow-chat-memory/utils/vector_index.py` | `chunk_31238a6fb0579835` |
| create_chat_flow | `cookbook/pocketflow-chat-memory/flow.py` | `chunk_5884a27b5f9b9e76` |
| run_chat_memory_demo | `cookbook/pocketflow-chat-memory/main.py` | `chunk_5aa097be10d4f808` |
| get_embedding | `cookbook/pocketflow-chat-memory/utils/get_embedding.py` | `chunk_65267d798ee6cf4c` |
| GetUserQuestionNode | `cookbook/pocketflow-chat-memory/nodes.py` | `chunk_9d75ed97c274c038` |

### 12. Tool-using conversational assistant with human-in-the-loop style routing

Workflow ID: `business_path_505dd4c0e95cbd93`

A Gradio chat user asks for weather or hotel help; an LLM routes to tool calls, the tools enforce date constraints, and the system returns follow-up or result notifications while persisting session state.

**Purpose:** Help the user book hotels or check weather, or guide the user when input is incomplete/out of scope

**Business outcome**

- Returns weather or booking results
- Persists action state across turns
- Produces follow-up prompts when required parameters are missing or the request is out of scope

**Important behavior and rules**

- The assistant only chooses among check-weather, book-hotel, follow-up, and result-notification actions.
- A follow-up is used when the request is out of scope or when required parameters are missing.
- Action results and parameters are persisted per conversation id across turns.
- Weather requests are rejected when the requested date is more than 7 days away.
- Hotel bookings require check-in after current date and check-out after check-in, with stay duration not exceeding 7 days.

**Identified functions:** `cookbook/pocketflow-gradio-hitl/main.py:chat_fn`, `create_flow`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `cookbook/pocketflow-gradio-hitl/nodes.py` | `chunk_04470ca0623169e6` |
| chat_fn | `cookbook/pocketflow-gradio-hitl/main.py` | `chunk_23d131e689a48f07` |
| Source section | `cookbook/pocketflow-gradio-hitl/nodes.py` | `chunk_2dedbe3f6de58f52` |
| call_llm | `cookbook/pocketflow-gradio-hitl/utils/call_llm.py` | `chunk_37cb1eac2b7583ac` |
| call_check_weather_api | `cookbook/pocketflow-gradio-hitl/utils/call_mock_api.py` | `chunk_80a0fbd3c7725929` |
| Source section | `cookbook/pocketflow-gradio-hitl/nodes.py` | `chunk_af4f695285a07513` |
| create_flow | `cookbook/pocketflow-gradio-hitl/flow.py` | `chunk_b435af193e693ce8` |
| conversation_cache | `cookbook/pocketflow-gradio-hitl/utils/conversation.py` | `chunk_c1647b9a4b0c234d` |
| format_chat_history | `cookbook/pocketflow-gradio-hitl/utils/format_chat_history.py` | `chunk_d20cdbdcac499825` |
| Source section | `cookbook/pocketflow-gradio-hitl/nodes.py` | `chunk_d9ad38608ff5491d` |
| Source section | `cookbook/pocketflow-gradio-hitl/nodes.py` | `chunk_f3ad1562c334805a` |

### 13. Human-in-the-loop task processing loop

Workflow ID: `business_path_66e03c81046d2b48`

Registered web client submits a task, receives task_id and SSE status updates, then posts approved/rejected feedback to unblock the background workflow.

**Purpose:** Submit work, monitor progress, and provide approval or rejection feedback

**Business outcome**

- Immediate task acceptance with asynchronous processing
- Status visibility through server-sent events
- Feedback can unblock or redirect workflow execution

**Important behavior and rules**

- Feedback is accepted only when the task exists, has a review_event, and has not already received feedback.
- Feedback must be either approved or rejected.
- The SSE stream ends when the background task enqueues a None sentinel.

**Identified functions:** `GET /stream/{task_id}`, `POST /submit`, `POST /feedback/{task_id}`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `cookbook/pocketflow-fastapi-hitl/server.py` | `chunk_4bc5229a15d06f6b` |
| Source section | `cookbook/pocketflow-fastapi-hitl/server.py` | `chunk_4d639b0e366b7df9` |
| Source section | `cookbook/pocketflow-fastapi-hitl/server.py` | `chunk_53d31793c6abeef6` |
| Source section | `cookbook/pocketflow-fastapi-hitl/server.py` | `chunk_59dbaed79c3805e0` |
| Source section | `cookbook/pocketflow-fastapi-hitl/server.py` | `chunk_7e06aa0f0dfa320e` |
| Source section | `cookbook/pocketflow-fastapi-hitl/server.py` | `chunk_8956e7c2768e42a3` |
| Source section | `cookbook/pocketflow-fastapi-hitl/server.py` | `chunk_8c80f52e4c45dc89` |
| Source section | `cookbook/pocketflow-fastapi-hitl/server.py` | `chunk_b8af5dfae86827a1` |
| Source section | `cookbook/pocketflow-fastapi-hitl/server.py` | `chunk_ec8766cfd13de953` |
| Source section | `cookbook/pocketflow-fastapi-hitl/server.py` | `chunk_ed9d9e5e6e5091c2` |

### 14. Streaming chat interaction

Workflow ID: `business_path_8bd1021b4d5d0ddd`

WebSocket client sends user messages, receives streamed LLM chunks, and accumulates conversation history in shared state.

**Purpose:** Ask a question and receive incremental assistant output

**Business outcome**

- Low-latency partial responses
- Conversation state persists across turns within a connection

**Important behavior and rules**

- Every incoming websocket message is JSON-decoded and expected to contain a content field.
- The assistant response is streamed through explicit start, chunk, and end markers.

**Identified functions:** `WebSocket /ws`, `GET /`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| stream_llm | `cookbook/pocketflow-fastapi-websocket/utils/stream_llm.py` | `chunk_0e4cb9e04f03a24c` |
| websocket_endpoint | `cookbook/pocketflow-fastapi-websocket/main.py` | `chunk_a21ae5e988132963` |
| StreamingChatNode.exec_async | `cookbook/pocketflow-fastapi-websocket/nodes.py` | `chunk_ee4741757ddaf353` |

### 15. Natural-language to SQL execution workflow

Workflow ID: `business_path_20dc874400101dd6`

CLI-supplied database path and natural-language query are converted into schema-aware SQL, executed against SQLite, and retried through a debug loop on failure.

**Purpose:** Answer a question by querying a SQLite database

**Business outcome**

- Automated schema inspection
- Query generation from natural language
- Error-driven correction loop until success or max attempts

**Important behavior and rules**

- If SQL execution fails, the flow stores the error and retries until max_debug_attempts is reached.
- GenerateSQL and DebugSQL require YAML-wrapped SQL output from the LLM.
- SELECT/WITH statements are treated as read queries; other statements are committed as writes.

**Identified functions:** `GetSchema`, `create_text_to_sql_flow`, `ExecuteSQL`, `GenerateSQL`, `DebugSQL`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| create_text_to_sql_flow | `cookbook/pocketflow-text2sql/flow.py` | `chunk_0367efd98554aa88` |
| GetSchema.prep | `cookbook/pocketflow-text2sql/nodes.py` | `chunk_d71b21f68ec7f38a` |

### 16. voice chat conversation loop

Workflow ID: `business_path_48afe8a663ef35ed`

User speech is captured, transcribed, passed to an LLM, synthesized back to audio, and the conversation loops or ends.

**Purpose:** speak a query and receive spoken LLM output

**Business outcome**

- hands-free conversational interaction
- continuous turn-taking until the session ends or an error occurs

**Important behavior and rules**

- The conversation ends when audio capture fails or no speech is detected.
- The flow only advances to the next turn after synthesizing a response or after a skipped/failed TTS branch.
- User and assistant messages are appended to chat_history in turn order.
- If microphone capture returns no audio, end the conversation.
- If STT returns no text, end the conversation.
- If TTS fails, skip to the next turn; otherwise loop or end based on continue_conversation.

**Identified functions:** `cookbook/pocketflow-voice-chat/main.py:main`, `CaptureAudioNode.exec`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| speech_to_text_api | `cookbook/pocketflow-voice-chat/utils/speech_to_text.py` | `chunk_1e694702b7594048` |
| CaptureAudioNode.exec/post | `cookbook/pocketflow-voice-chat/nodes.py` | `chunk_22a4c27210fbc652` |
| main | `cookbook/pocketflow-voice-chat/main.py` | `chunk_36da92ad7778c608` |
| text_to_speech_api | `cookbook/pocketflow-voice-chat/utils/text_to_speech.py` | `chunk_4330bed9af656bd1` |
| create_voice_chat_flow | `cookbook/pocketflow-voice-chat/flow.py` | `chunk_4b729762c2ed693c` |
| record_audio | `cookbook/pocketflow-voice-chat/utils/audio_utils.py` | `chunk_9c720dc17051d097` |
| call_llm | `cookbook/pocketflow-voice-chat/utils/call_llm.py` | `chunk_adb8904d8ece0685` |

### 17. text-to-SQL demo bootstrap and database seeding

Workflow ID: `business_path_5da7b4868d80571e`

A CLI text-to-SQL demo ensures the ecommerce SQLite database exists, repopulates it when needed, and runs a query workflow over shared state.

**Purpose:** run a natural-language query against a prepared ecommerce database

**Business outcome**

- ensures the demo database is ready before execution
- creates deterministic sample commerce data for query workflows

**Important behavior and rules**

- The text-to-SQL demo bootstraps the database automatically when the configured DB file is absent or empty.
- Order totals are derived from order item quantities multiplied by product price and then written back to the orders table.
- The orders table enforces a finite status vocabulary for sample commerce rows.
- If the database file is missing or empty, populate it before running the workflow.
- If an existing database file is present, it is removed before reconstruction.

**Identified functions:** `cookbook/pocketflow-text2sql/main.py:run_text_to_sql`, `cookbook/pocketflow-text2sql/populate_db.py:populate_database`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| execute_sql | `cookbook/pocketflow-tool-database/tools/database.py` | `chunk_a64ac9d8fbb7c867` |
| populate_database | `cookbook/pocketflow-text2sql/populate_db.py` | `chunk_b979f09f119ce4ed` |
| __main__ | `cookbook/pocketflow-text2sql/main.py` | `chunk_bc4fd638512f2be7` |

### 18. documentation transformation pipeline

Workflow ID: `business_path_391d285ff4e4eefe`

A CLI documentation utility converts markdown docs into MDC files, combining guide/index and rewriting content before writing output files.

**Purpose:** convert PocketFlow docs into MDC rules files

**Business outcome**

- produces curated MDC documentation artifacts
- normalizes docs for downstream tooling and rule loading

**Important behavior and rules**

- Markdown frontmatter is stripped before transformation.
- guide.md and index.md are handled as a single combined MDC artifact rather than individual outputs.
- Only substantive processed content is emitted; near-empty content is skipped.
- guide.md and index.md are combined and skipped from individual processing.
- Subfolder index files without substantive content are skipped.

**Identified functions:** `utils/update_pocketflow_mdc.py:generate_mdc_files`, `utils/update_pocketflow_mdc.py:create_combined_guide`, `utils/update_pocketflow_mdc.py:convert_md_to_mdc`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| has_substantive_content | `utils/update_pocketflow_mdc.py` | `chunk_22e1628c78732cd9` |
| generate_mdc_files | `utils/update_pocketflow_mdc.py` | `chunk_49d93a9358a4c080` |
| convert_md_to_mdc | `utils/update_pocketflow_mdc.py` | `chunk_7a78a6d0a0043426` |
| create_combined_guide | `utils/update_pocketflow_mdc.py` | `chunk_7be1673af5bf9654` |
| process_markdown_content | `utils/update_pocketflow_mdc.py` | `chunk_82efc4c12f072cde` |
| generate_mdc_header | `utils/update_pocketflow_mdc.py` | `chunk_8d06e210e7047fa7` |
| __main__ | `utils/update_pocketflow_mdc.py` | `chunk_8efbca902eea0cf7` |

### 19. interactive agentic question answering with web search

Workflow ID: `business_path_16dc5740f30688e7`

CLI user asks a question, the agent decides whether to search the web or answer immediately, and the workflow produces a final answer after optionally appending search results to context.

**Purpose:** ask a question and receive a researched answer

**Business outcome**

- produces a synthesized answer for the user
- collects external search evidence into shared context

**Important behavior and rules**

- The LLM decision output is parsed from YAML and must include action-specific fields such as search_query when action is search.
- SearchWeb uses DuckDuckGo text search and converts at most five results into a concatenated text block.
- If the decision action is 'search', the flow stores search_query and routes to SearchWeb; otherwise it stores the answer context and terminates through AnswerQuestion.
- SearchWeb always appends retrieved results to context and returns 'decide' to continue the loop.

**Identified functions:** `cookbook/pocketflow-agent/flow.py::create_agent_flow`, `cookbook/pocketflow-agent/main.py::main`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| create_agent_flow | `cookbook/pocketflow-agent/flow.py` | `chunk_4e3a15d92870f496` |
| DecideAction/SearchWeb/AnswerQuestion | `cookbook/pocketflow-agent/nodes.py` | `chunk_5c877101dc3d1744` |
| search_web_duckduckgo | `cookbook/pocketflow-agent/utils.py` | `chunk_85dd6c1e08dfefdc` |
| main | `cookbook/pocketflow-agent/main.py` | `chunk_b147930696156cc5` |

### 20. agentic retrieval augmented generation over bundled docs

Workflow ID: `business_path_47e9f571a85e8d11`

CLI user asks a question, the agent chooses whether to read another PocketFlow document from DOCS or answer, and the workflow builds context from documents before generating a final answer.

**Purpose:** answer a PocketFlow question using internal document summaries

**Business outcome**

- retrieves document summaries instead of searching externally
- synthesizes an answer from accumulated document context

**Important behavior and rules**

- The LLM must output valid YAML with an action field, and when reading it must include a doc field.
- After each document read, the flow loops back to DecideAction rather than finishing immediately.
- If the LLM chooses 'read', the chosen document name is stored and the flow routes to ReadDoc; otherwise it proceeds to Answer.
- ReadDoc falls back to 'Document not found.' when DOCS does not contain the selected name.

**Identified functions:** `cookbook/pocketflow-agentic-rag/flow.py::create_agentic_rag_flow`, `cookbook/pocketflow-agentic-rag/main.py::main`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| main | `cookbook/pocketflow-agentic-rag/main.py` | `chunk_285e7daf305a5e31` |
| DOCS | `cookbook/pocketflow-agentic-rag/utils.py` | `chunk_3da9d24f53e09c94` |
| create_agentic_rag_flow | `cookbook/pocketflow-agentic-rag/flow.py` | `chunk_7272c12b8a9f2db2` |
| DecideAction/ReadDoc.post | `cookbook/pocketflow-agentic-rag/nodes.py` | `chunk_ca10c0b8b165fd43` |

### 21. recursive research and report synthesis

Workflow ID: `business_path_3e31dddf9b000f4f`

CLI user requests a topic-specific research report, the planner generates multiple web search queries, the researcher extracts facts from search results, and the synthesizer either loops for more research or finalizes a report.

**Purpose:** produce a concise research report about a topic

**Business outcome**

- generates a report from multiple search-driven evidence snippets
- refines research through iterative loops when information is incomplete

**Important behavior and rules**

- The planner must emit YAML containing exactly three research queries.
- The researcher searches the web for each query and then extracts key facts using the LLM.
- If the synthesizer decides to research again, the next planner cycle uses stored feedback to fill gaps.
- The synthesizer forces finalization once loop_count reaches 2.
- When the synthesizer returns 'research', loop_count increments and feedback is stored for the next planning cycle.

**Identified functions:** `cookbook/pocketflow-deep-research/flow.py::create_deep_research_flow`, `cookbook/pocketflow-deep-research/main.py::main`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| create_deep_research_flow | `cookbook/pocketflow-deep-research/flow.py` | `chunk_3e97140a0b9f4a50` |
| search_web | `cookbook/pocketflow-deep-research/utils.py` | `chunk_4890e94eef875569` |
| PlannerNode/ResearcherNode/SynthesizerNode | `cookbook/pocketflow-deep-research/nodes.py` | `chunk_493a52414e6ac24f` |
| main | `cookbook/pocketflow-deep-research/main.py` | `chunk_a972fbc419172bc4` |

### 22. Background article generation with live progress updates

Workflow ID: `business_path_08b3130fd848c5dc`

Web user submits a topic to start a background article-generation job, then polls a streaming progress endpoint until completion.

**Purpose:** Submit a topic and watch article generation progress

**Business outcome**

- Immediate job acceptance response
- Continuous progress visibility via SSE
- Completion or error feedback to the user

**Important behavior and rules**

- A submitted topic must be posted to /start-job and returns a generated job_id plus topic/status payload.
- The progress stream stays open until a message with step == 'complete' arrives, then removes the job from active_jobs.
- If job_id is missing from active_jobs, return an error SSE event and stop.
- If no queue item arrives within 1 second, emit a heartbeat event to keep the connection alive.

**Identified functions:** `POST /start-job`, `GET /progress/{job_id}`, `GET /`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| articleForm submit handler | `cookbook/pocketflow-fastapi-background/static/index.html` | `chunk_014bdf029cb18585` |
| start_job | `cookbook/pocketflow-fastapi-background/main.py` | `chunk_a37d754e8c59d3e3` |

### 23. Newsletter curation and formatting

Workflow ID: `business_path_2655ae366c5e6b1a`

CLI or flow-driven newsletter pipeline searches the web for topics, selects stories, summarizes them, and formats a markdown newsletter.

**Purpose:** Produce an AI weekly digest from topic searches

**Business outcome**

- Search results are condensed into a formatted digest
- Only the top four stories are retained
- LLM-generated blurbs provide short explanatory summaries

**Important behavior and rules**

- Exactly four stories are selected from raw search results.
- Each selected story receives a punchy 2-3 sentence blurb before newsletter formatting.
- The flow uses the current topics list, including any CLI-provided additions.

**Identified functions:** `create_newsletter_flow`, `main() in newsletter example`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| CurateSources.post | `cookbook/pocketflow-newsletter/nodes.py` | `chunk_69a4bcce1c36dd20` |
| search_web | `cookbook/pocketflow-newsletter/utils.py` | `chunk_7bd2a049f00d5eb6` |
| create_newsletter_flow | `cookbook/pocketflow-newsletter/flow.py` | `chunk_b966846cf3f0e4e8` |
| main | `cookbook/pocketflow-newsletter/main.py` | `chunk_ddfe19077e50b5b9` |

### 24. Document transformation to audio podcast

Workflow ID: `business_path_e48528edb07d63f2`

A document-to-podcast pipeline extracts nuggets from documents, writes a dialogue script, and saves generated speech to an audio file.

**Purpose:** Turn source documents into a saved podcast file

**Business outcome**

- Converts text documents into spoken content
- Writes generated audio to disk
- Handles MP3 or WAV output based on returned bytes

**Important behavior and rules**

- The script must be YAML-parsed into a list of dialog lines with speaker names.
- Text-to-speech output is saved under the requested output_file name when MP3 is returned, otherwise WAV fallback is used.
- If the generated bytes are not MP3-like, wrap them as WAV using 24kHz, 16-bit mono settings.

**Identified functions:** `create_podcast_flow`, `main() in notebook-lm example`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| main | `cookbook/pocketflow-notebook-lm/main.py` | `chunk_9a8f7ae86837fc0f` |
| create_podcast_flow | `cookbook/pocketflow-notebook-lm/flow.py` | `chunk_b1c2938a05f46ea3` |
| AnalyzeDocs | `cookbook/pocketflow-notebook-lm/nodes.py` | `chunk_bbcf6583cf4dff35` |

### 25. structured resume extraction

Workflow ID: `business_path_0b9330322351a75c`

A resume parser LLM path turns resume text plus target skills into validated structured YAML data.

**Purpose:** extract candidate fields and target skill indexes from a resume

**Business outcome**

- produces machine-readable candidate profile
- enables downstream selection or review of extracted skills

**Important behavior and rules**

- The parser only accepts YAML-formatted LLM output and validates required resume fields before continuing.
- Response must contain YAML fenced block before parsing.
- Parsed output must include name, email, experience, and skill_indexes and experience must be a list.

**Identified functions:** `cookbook/pocketflow-structured-output/main.py __main__`, `cookbook/pocketflow-structured-output/main.py:ResumeParserNode`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| call_llm | `cookbook/pocketflow-structured-output/utils.py` | `chunk_c8da2f621d0b15d2` |
| __main__ | `cookbook/pocketflow-structured-output/main.py` | `chunk_f0b0e3f316b4f66b` |

### 26. diagram generation with repair loop

Workflow ID: `business_path_fe919483ccf5bd58`

An LLM generates Mermaid code, the compiler checks it, and the flow retries with error feedback until success or three failed attempts.

**Purpose:** produce a valid Mermaid diagram from a task description

**Business outcome**

- automates diagram drafting
- self-corrects syntax failures with feedback
- limits retry cost through a max-attempt policy

**Important behavior and rules**

- Compile failures are fed back into the next prompt so the LLM can repair syntax errors.
- The flow stops retrying after three failed compilation attempts.
- Prompt instructs the LLM to output only Mermaid code in a fenced block.
- Compilation errors are normalized and truncated to relevant lines.
- Retry loop stops after 3 attempts.

**Identified functions:** `cookbook/pocketflow-self-healing-mermaid/main.py:main`, `cookbook/pocketflow-self-healing-mermaid/flow.py:create_mermaid_flow`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| create_mermaid_flow | `cookbook/pocketflow-self-healing-mermaid/flow.py` | `chunk_04eb14d659b17093` |
| call_llm | `cookbook/pocketflow-self-healing-mermaid/utils.py` | `chunk_0ef239d32623834f` |
| WriteChart.prep | `cookbook/pocketflow-self-healing-mermaid/nodes.py` | `chunk_497c459d442b27b4` |
| main | `cookbook/pocketflow-self-healing-mermaid/main.py` | `chunk_f8159d518d2593d1` |

### 27. human-in-the-loop image generation

Workflow ID: `business_path_f97738c1d39ee2c3`

A Streamlit UI sends a text prompt to an image generation node, then moves through review, approval, or regeneration states.

**Purpose:** generate an image from a prompt and approve or regenerate it

**Business outcome**

- produces an image from text
- supports user approval before finalizing
- allows regeneration when the preview is unsatisfactory

**Important behavior and rules**

- Generating an image advances the workflow to a review stage before final approval.
- Prompt must be non-empty before generation runs.
- Approval and regeneration are only available after a generated image exists.

**Identified functions:** `cookbook/pocketflow-streamlit-fsm/app.py:streamlit UI`, `cookbook/pocketflow-streamlit-fsm/flow.py:create_generation_flow`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| GenerateImageNode.post | `cookbook/pocketflow-streamlit-fsm/nodes.py` | `chunk_4488cf50bffd177f` |
| generate_image | `cookbook/pocketflow-streamlit-fsm/utils/generate_image.py` | `chunk_4be80ae68622d1f8` |
| create_generation_flow | `cookbook/pocketflow-streamlit-fsm/flow.py` | `chunk_bab789b610a77213` |
| streamlit_state_machine_ui | `cookbook/pocketflow-streamlit-fsm/app.py` | `chunk_bb3f5064d55fd5e4` |

## 2. Verified code connections and remaining repository context

Connections are static source relationships; they do not prove runtime execution.

- `chunk_003ad842827dbf29` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncNode
- `chunk_003ad842827dbf29` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncBatchNode
- `chunk_003ad842827dbf29` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncFlow
- `chunk_003ad842827dbf29` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_00fc381a5f9b0791` → `chunk_a2505e22d23b56bd`: imports_symbol; symbol: CompactHistory
- `chunk_00fc381a5f9b0791` → `chunk_a2505e22d23b56bd`: imports_symbol; symbol: ListFiles
- `chunk_00fc381a5f9b0791` → `chunk_a2505e22d23b56bd`: imports_symbol; symbol: GrepSearch
- `chunk_00fc381a5f9b0791` → `chunk_a2505e22d23b56bd`: imports_symbol; symbol: ReadFile
- `chunk_00fc381a5f9b0791` → `chunk_a2505e22d23b56bd`: imports_symbol; symbol: RunCommand
- `chunk_00fc381a5f9b0791` → `chunk_a2505e22d23b56bd`: imports_symbol; symbol: PatchRead
- `chunk_00fc381a5f9b0791` → `chunk_a2505e22d23b56bd`: imports_symbol; symbol: PatchValidate
- `chunk_00fc381a5f9b0791` → `chunk_a2505e22d23b56bd`: imports_symbol; symbol: PatchApply
- `chunk_00fc381a5f9b0791` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_00fc381a5f9b0791` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_01ac4b617402ad6f` → `chunk_35eaf7b0f17f46a0`: imports_symbol; symbol: TracingConfig
- `chunk_01ac4b617402ad6f` → `chunk_bd6c59e4f8578035`: imports_symbol; symbol: LangfuseTracer
- `chunk_023ea21d45bf3acd` → `chunk_f3328b96bf99f52d`: imports_symbol; symbol: create_code_generator_flow
- `chunk_02e386661d3b2bce` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_02e386661d3b2bce` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_0367efd98554aa88` → `chunk_d71b21f68ec7f38a`: imports_symbol; symbol: GetSchema
- `chunk_0367efd98554aa88` → `chunk_d71b21f68ec7f38a`: imports_symbol; symbol: GenerateSQL
- `chunk_0367efd98554aa88` → `chunk_d71b21f68ec7f38a`: imports_symbol; symbol: ExecuteSQL
- `chunk_0367efd98554aa88` → `chunk_d71b21f68ec7f38a`: imports_symbol; symbol: DebugSQL
- `chunk_0367efd98554aa88` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_0367efd98554aa88` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_0367efd98554aa88` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_04eb14d659b17093` → `chunk_497c459d442b27b4`: imports_symbol; symbol: WriteChart
- `chunk_04eb14d659b17093` → `chunk_497c459d442b27b4`: imports_symbol; symbol: CompileChart
- `chunk_04eb14d659b17093` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_04eb14d659b17093` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_08304a4654b291c2` → `chunk_5630ef3fbe60e8cb`: imports_symbol; symbol: create_embedding_flow
- `chunk_0b31a5e4521d49bd` → `chunk_1436f3c92ebf3353`: imports_symbol; symbol: AgentCard
- `chunk_0b31a5e4521d49bd` → `chunk_1cfb5186cdb2fbd4`: imports_symbol; symbol: GetTaskPushNotificationRequest
- `chunk_0b31a5e4521d49bd` → `chunk_3f5bce9c0daa0035`: imports_symbol; symbol: JSONParseError
- `chunk_0b31a5e4521d49bd` → `chunk_4e571f6d9165848b`: imports_symbol; symbol: CancelTaskRequest
- `chunk_0b31a5e4521d49bd` → `chunk_54c7944ae37e0ae8`: imports_symbol; symbol: Message
- `chunk_0b31a5e4521d49bd` → `chunk_5765a357b9387587`: imports_symbol; symbol: SetTaskPushNotificationRequest
- `chunk_0b31a5e4521d49bd` → `chunk_637231d6b5bd62e4`: file_import; symbol: not specified
- `chunk_0b31a5e4521d49bd` → `chunk_64dfe57771bd1f56`: imports_symbol; symbol: TaskManager
- `chunk_0b31a5e4521d49bd` → `chunk_7fb81435b87042b4`: imports_symbol; symbol: InvalidRequestError
- `chunk_0b31a5e4521d49bd` → `chunk_86f22ff56f90782f`: imports_symbol; symbol: JSONRPCResponse
- `chunk_0b31a5e4521d49bd` → `chunk_908d1fa56db85982`: imports_symbol; symbol: SendTaskStreamingRequest
- `chunk_0b31a5e4521d49bd` → `chunk_b309c2d441f5f203`: imports_symbol; symbol: TaskResubscriptionRequest
- `chunk_0b31a5e4521d49bd` → `chunk_c43c07f0af5210cf`: imports_symbol; symbol: InternalError
- `chunk_0b31a5e4521d49bd` → `chunk_e63b0ad5bc01cc9e`: imports_symbol; symbol: SendTaskRequest
- `chunk_0b31a5e4521d49bd` → `chunk_eac65360a190e24c`: imports_symbol; symbol: GetTaskRequest
- `chunk_0b5834f3100de60f` → `chunk_35eaf7b0f17f46a0`: imports_symbol; symbol: TracingConfig
- `chunk_0b5834f3100de60f` → `chunk_57a50f34f89bf36d`: imports_symbol; symbol: trace_flow
- `chunk_0b5834f3100de60f` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_0b5834f3100de60f` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_0b5834f3100de60f` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_0e92b8937bab3516` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_0e92b8937bab3516` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_18f10027de047f8f` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_18f10027de047f8f` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_19e04b9f21eebdd6` → `chunk_2b5331fea6551925`: imports_symbol; symbol: A2AClient
- `chunk_19e04b9f21eebdd6` → `chunk_70d070872e14646f`: file_import; symbol: not specified
- `chunk_19e04b9f21eebdd6` → `chunk_c79cdad02966e151`: imports_symbol; symbol: A2ACardResolver
- `chunk_19e04b9f21eebdd6` → `chunk_c79cdad02966e151`: file_import; symbol: not specified
- `chunk_1d2cb7d506a68103` → `chunk_e80c2423e0aa04c3`: imports_symbol; symbol: parse_yaml
- `chunk_1d2cb7d506a68103` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_1d2cb7d506a68103` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_22a4c27210fbc652` → `chunk_1e694702b7594048`: imports_symbol; symbol: speech_to_text_api
- `chunk_22a4c27210fbc652` → `chunk_1e694702b7594048`: file_import; symbol: not specified
- `chunk_22a4c27210fbc652` → `chunk_4330bed9af656bd1`: imports_symbol; symbol: text_to_speech_api
- `chunk_22a4c27210fbc652` → `chunk_4330bed9af656bd1`: file_import; symbol: not specified
- `chunk_22a4c27210fbc652` → `chunk_9c720dc17051d097`: imports_symbol; symbol: record_audio
- `chunk_22a4c27210fbc652` → `chunk_9c720dc17051d097`: imports_symbol; symbol: play_audio_data
- `chunk_22a4c27210fbc652` → `chunk_9c720dc17051d097`: file_import; symbol: not specified
- `chunk_22a4c27210fbc652` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_22a4c27210fbc652` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_23ef461e7c54abc9` → `chunk_903f964473008a05`: imports_symbol; symbol: fetch_recipes
- `chunk_23ef461e7c54abc9` → `chunk_903f964473008a05`: imports_symbol; symbol: call_llm_async
- `chunk_23ef461e7c54abc9` → `chunk_903f964473008a05`: imports_symbol; symbol: get_user_input
- `chunk_23ef461e7c54abc9` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncNode
- `chunk_23ef461e7c54abc9` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_285e7daf305a5e31` → `chunk_7272c12b8a9f2db2`: imports_symbol; symbol: create_agentic_rag_flow
- `chunk_28e84b61f59fec69` → `chunk_3419ec1926e6abeb`: imports_symbol; symbol: create_resume_processing_flow
- `chunk_2be45edb9b4d25ed` → `chunk_64ce49755de6c040`: imports_symbol; symbol: WriteSimpleContent
- `chunk_2be45edb9b4d25ed` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_2be45edb9b4d25ed` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_2c58bc3ee59b0232` → `chunk_01ac4b617402ad6f`: imports_symbol; symbol: setup_tracing
- `chunk_2c58bc3ee59b0232` → `chunk_35eaf7b0f17f46a0`: imports_symbol; symbol: TracingConfig
- `chunk_2c58bc3ee59b0232` → `chunk_57a50f34f89bf36d`: imports_symbol; symbol: trace_flow
- `chunk_2c58bc3ee59b0232` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_2c58bc3ee59b0232` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_2c58bc3ee59b0232` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncNode
- `chunk_2c58bc3ee59b0232` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncFlow
- `chunk_2c58bc3ee59b0232` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_2f248dc84b3387f1` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_2f248dc84b3387f1` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_2f248dc84b3387f1` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_3419ec1926e6abeb` → `chunk_b40ba65d22b1811d`: imports_symbol; symbol: ReadResumesNode
- `chunk_3419ec1926e6abeb` → `chunk_b40ba65d22b1811d`: imports_symbol; symbol: EvaluateResumesNode
- `chunk_3419ec1926e6abeb` → `chunk_b40ba65d22b1811d`: imports_symbol; symbol: ReduceResultsNode
- `chunk_3419ec1926e6abeb` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_3419ec1926e6abeb` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_36d4ccb2105d3de8` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncNode
- `chunk_36d4ccb2105d3de8` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_36da92ad7778c608` → `chunk_4b729762c2ed693c`: imports_symbol; symbol: create_voice_chat_flow
- `chunk_39789356236888ae` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_39789356236888ae` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_3a90fbb36b25ae44` → `chunk_0e92b8937bab3516`: imports_symbol; symbol: Generator
- `chunk_3a90fbb36b25ae44` → `chunk_0e92b8937bab3516`: imports_symbol; symbol: Judge
- `chunk_3a90fbb36b25ae44` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_3a90fbb36b25ae44` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_3b1c990bcabebe77` → `chunk_e7f222061791959a`: imports_symbol; symbol: create_invoice_flow
- `chunk_3dbea6f7aed0e718` → `chunk_00fc381a5f9b0791`: imports_symbol; symbol: create_coding_agent_flow
- `chunk_3dbea6f7aed0e718` → `chunk_4be169fa435134dc`: file_import; symbol: not specified
- `chunk_3dbea6f7aed0e718` → `chunk_8bd287c43c30451e`: imports_symbol; symbol: setup_test_project
- `chunk_3e97140a0b9f4a50` → `chunk_493a52414e6ac24f`: imports_symbol; symbol: PlannerNode
- `chunk_3e97140a0b9f4a50` → `chunk_493a52414e6ac24f`: imports_symbol; symbol: ResearcherNode
- `chunk_3e97140a0b9f4a50` → `chunk_493a52414e6ac24f`: imports_symbol; symbol: SynthesizerNode
- `chunk_3e97140a0b9f4a50` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_3e97140a0b9f4a50` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_413529fdaffc2f0e` → `chunk_59df996d3c3d2ec7`: imports_symbol; symbol: pdf_to_images
- `chunk_413529fdaffc2f0e` → `chunk_59df996d3c3d2ec7`: file_import; symbol: not specified
- `chunk_413529fdaffc2f0e` → `chunk_890d344dd585ca61`: imports_symbol; symbol: extract_text_from_image
- `chunk_413529fdaffc2f0e` → `chunk_890d344dd585ca61`: file_import; symbol: not specified
- `chunk_413529fdaffc2f0e` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_413529fdaffc2f0e` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchNode
- `chunk_413529fdaffc2f0e` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_425d6450326e4819` → `chunk_64bda7992f8536ca`: imports_symbol; symbol: get_table
- `chunk_4488cf50bffd177f` → `chunk_4be80ae68622d1f8`: imports_symbol; symbol: generate_image
- `chunk_4488cf50bffd177f` → `chunk_4be80ae68622d1f8`: file_import; symbol: not specified
- `chunk_4488cf50bffd177f` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_4488cf50bffd177f` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_44e26f313f106dba` → `chunk_31f639af730492d4`: imports_symbol; symbol: call_llm_with_image
- `chunk_44e26f313f106dba` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_44e26f313f106dba` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_455100195dba26d3` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_455100195dba26d3` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_455100195dba26d3` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_45fae4abfeb6c993` → `chunk_ab40b798a647533d`: imports_symbol; symbol: WaitNode
- `chunk_45fae4abfeb6c993` → `chunk_ab40b798a647533d`: imports_symbol; symbol: CheckEmail
- `chunk_45fae4abfeb6c993` → `chunk_ab40b798a647533d`: imports_symbol; symbol: ProcessEmail
- `chunk_45fae4abfeb6c993` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_45fae4abfeb6c993` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_4607d58619b1c6be` → `chunk_3a90fbb36b25ae44`: imports_symbol; symbol: create_judge_flow
- `chunk_493a52414e6ac24f` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_493a52414e6ac24f` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchNode
- `chunk_493a52414e6ac24f` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_497c459d442b27b4` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_497c459d442b27b4` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_4b5c09a90b91b288` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncNode
- `chunk_4b5c09a90b91b288` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncFlow
- `chunk_4b5c09a90b91b288` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_4b729762c2ed693c` → `chunk_22a4c27210fbc652`: imports_symbol; symbol: CaptureAudioNode
- `chunk_4b729762c2ed693c` → `chunk_22a4c27210fbc652`: imports_symbol; symbol: SpeechToTextNode
- `chunk_4b729762c2ed693c` → `chunk_22a4c27210fbc652`: imports_symbol; symbol: QueryLLMNode
- `chunk_4b729762c2ed693c` → `chunk_22a4c27210fbc652`: imports_symbol; symbol: TextToSpeechNode
- `chunk_4b729762c2ed693c` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_4b729762c2ed693c` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_4c358d219e17eae5` → `chunk_2ad0e8a657e2d432`: imports_symbol; symbol: TaskStatus
- `chunk_4c358d219e17eae5` → `chunk_2fc5452fd1a1beb4`: imports_symbol; symbol: SendTaskStreamingResponse
- `chunk_4c358d219e17eae5` → `chunk_54c7944ae37e0ae8`: imports_symbol; symbol: Message
- `chunk_4c358d219e17eae5` → `chunk_637231d6b5bd62e4`: imports_symbol; symbol: TaskState
- `chunk_4c358d219e17eae5` → `chunk_637231d6b5bd62e4`: file_import; symbol: not specified
- `chunk_4c358d219e17eae5` → `chunk_6fbbb4ad51604ad0`: imports_symbol; symbol: TextPart
- `chunk_4c358d219e17eae5` → `chunk_86f22ff56f90782f`: imports_symbol; symbol: JSONRPCResponse
- `chunk_4c358d219e17eae5` → `chunk_908d1fa56db85982`: imports_symbol; symbol: SendTaskStreamingRequest
- `chunk_4c358d219e17eae5` → `chunk_9321b60d8ce11e00`: imports_symbol; symbol: TaskSendParams
- `chunk_4c358d219e17eae5` → `chunk_99d9eeda09ab2beb`: imports_symbol; symbol: InMemoryTaskManager
- `chunk_4c358d219e17eae5` → `chunk_9b7e43db24365714`: imports_symbol; symbol: SendTaskResponse
- `chunk_4c358d219e17eae5` → `chunk_a11ddf314127f8c9`: imports_symbol; symbol: Task
- `chunk_4c358d219e17eae5` → `chunk_a999cbde229d7017`: imports_symbol; symbol: InvalidParamsError
- `chunk_4c358d219e17eae5` → `chunk_bf433a82940cf5d7`: imports_symbol; symbol: UnsupportedOperationError
- `chunk_4c358d219e17eae5` → `chunk_c43c07f0af5210cf`: imports_symbol; symbol: InternalError
- `chunk_4c358d219e17eae5` → `chunk_d558aa471f9e7d8b`: imports_symbol; symbol: Artifact
- `chunk_4c358d219e17eae5` → `chunk_e63b0ad5bc01cc9e`: imports_symbol; symbol: SendTaskRequest
- `chunk_4e3a15d92870f496` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_4e3a15d92870f496` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_4e65682a7c4d8f56` → `chunk_9f258f609bdd8286`: imports_symbol; symbol: process_task
- `chunk_4e65682a7c4d8f56` → `chunk_9f258f609bdd8286`: file_import; symbol: not specified
- `chunk_4e65682a7c4d8f56` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_4e65682a7c4d8f56` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncNode
- `chunk_4e65682a7c4d8f56` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_54d4d8ea8eaa061e` → `chunk_56e695a68b90a957`: imports_symbol; symbol: create_chain_of_thought_flow
- `chunk_54f4a49f867fbc27` → `chunk_6249b9be90442d7f`: imports_symbol; symbol: InitDatabaseNode
- `chunk_54f4a49f867fbc27` → `chunk_6249b9be90442d7f`: imports_symbol; symbol: CreateTaskNode
- `chunk_54f4a49f867fbc27` → `chunk_6249b9be90442d7f`: imports_symbol; symbol: ListTasksNode
- `chunk_54f4a49f867fbc27` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_54f4a49f867fbc27` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_562cf803f429f80a` → `chunk_5e6a0ead988a61f6`: imports_symbol; symbol: create_lead_generation_flow
- `chunk_5630ef3fbe60e8cb` → `chunk_df54b4a7b2c11bae`: imports_symbol; symbol: EmbeddingNode
- `chunk_5630ef3fbe60e8cb` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_5630ef3fbe60e8cb` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_564f231522b36324` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_564f231522b36324` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncNode
- `chunk_564f231522b36324` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_564f231522b36324` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncFlow
- `chunk_564f231522b36324` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_56e695a68b90a957` → `chunk_08ec8e3d3a8d9a49`: imports_symbol; symbol: ChainOfThoughtNode
- `chunk_56e695a68b90a957` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_56e695a68b90a957` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_57746f06c9458c84` → `chunk_92dad70a2a593307`: imports_symbol; symbol: create_dom_agent_flow
- `chunk_57746f06c9458c84` → `chunk_92dad70a2a593307`: imports_symbol; symbol: create_vision_agent_flow
- `chunk_57a50f34f89bf36d` → `chunk_35eaf7b0f17f46a0`: imports_symbol; symbol: TracingConfig
- `chunk_57a50f34f89bf36d` → `chunk_35eaf7b0f17f46a0`: file_import; symbol: not specified
- `chunk_57a50f34f89bf36d` → `chunk_bd6c59e4f8578035`: imports_symbol; symbol: LangfuseTracer
- `chunk_57a50f34f89bf36d` → `chunk_e8fd18a6a7822243`: file_import; symbol: not specified
- `chunk_5884a27b5f9b9e76` → `chunk_9d75ed97c274c038`: imports_symbol; symbol: GetUserQuestionNode
- `chunk_5884a27b5f9b9e76` → `chunk_9d75ed97c274c038`: imports_symbol; symbol: RetrieveNode
- `chunk_5884a27b5f9b9e76` → `chunk_9d75ed97c274c038`: imports_symbol; symbol: EmbedNode
- `chunk_5884a27b5f9b9e76` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_5884a27b5f9b9e76` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_59dbaed79c3805e0` → `chunk_f07a63c87d07d83f`: imports_symbol; symbol: create_feedback_flow
- `chunk_5c877101dc3d1744` → `chunk_85dd6c1e08dfefdc`: imports_symbol; symbol: search_web_duckduckgo
- `chunk_5c877101dc3d1744` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_5c877101dc3d1744` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_5e6a0ead988a61f6` → `chunk_ded36a6898be7007`: imports_symbol; symbol: ScrapeLeads
- `chunk_5e6a0ead988a61f6` → `chunk_ded36a6898be7007`: imports_symbol; symbol: EnrichLeads
- `chunk_5e6a0ead988a61f6` → `chunk_ded36a6898be7007`: imports_symbol; symbol: ScoreLeads
- `chunk_5e6a0ead988a61f6` → `chunk_ded36a6898be7007`: imports_symbol; symbol: PersonalizeEmails
- `chunk_5e6a0ead988a61f6` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_5e6a0ead988a61f6` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_602afb6753f67a2e` → `chunk_c7300e1703ef1602`: imports_symbol; symbol: LoadGrades
- `chunk_602afb6753f67a2e` → `chunk_c7300e1703ef1602`: imports_symbol; symbol: CalculateAverage
- `chunk_602afb6753f67a2e` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_602afb6753f67a2e` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchFlow
- `chunk_602afb6753f67a2e` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_603d62611c06ca2d` → `chunk_02e386661d3b2bce`: imports_symbol; symbol: SelectSkill
- `chunk_603d62611c06ca2d` → `chunk_02e386661d3b2bce`: imports_symbol; symbol: ApplySkill
- `chunk_603d62611c06ca2d` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_603d62611c06ca2d` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_61770c06cce2da58` → `chunk_8406f22031351c79`: imports_symbol; symbol: create_flows
- `chunk_6249b9be90442d7f` → `chunk_a64ac9d8fbb7c867`: imports_symbol; symbol: execute_sql
- `chunk_6249b9be90442d7f` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_6249b9be90442d7f` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_64aeda1a1b6fd3ff` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_64aeda1a1b6fd3ff` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_64ce49755de6c040` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_64ce49755de6c040` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchNode
- `chunk_64ce49755de6c040` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_65b2776ff5d78724` → `chunk_99425bc4d56be557`: file_import; symbol: not specified
- `chunk_65b2776ff5d78724` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_65b2776ff5d78724` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncParallelBatchNode
- `chunk_65b2776ff5d78724` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_65b2776ff5d78724` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_67d3f829ee6fc199` → `chunk_e98c1d895b27a89a`: imports_symbol; symbol: create_vision_flow
- `chunk_67de21658b9ed5df` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_67de21658b9ed5df` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_67de21658b9ed5df` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_69a4bcce1c36dd20` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_69a4bcce1c36dd20` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_6a7f0600b863a918` → `chunk_6eaa52bfc116b851`: imports_symbol; symbol: execute_python
- `chunk_6a7f0600b863a918` → `chunk_6eaa52bfc116b851`: file_import; symbol: not specified
- `chunk_6a7f0600b863a918` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_6a7f0600b863a918` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchNode
- `chunk_6a7f0600b863a918` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_6ab59529159a9559` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_6ab59529159a9559` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_6bd9e5d58254b801` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_6bd9e5d58254b801` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_6bd9e5d58254b801` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_6f0fba99af15b2ef` → `chunk_ee4741757ddaf353`: imports_symbol; symbol: StreamingChatNode
- `chunk_6f0fba99af15b2ef` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncFlow
- `chunk_6f0fba99af15b2ef` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_70d070872e14646f` → `chunk_1436f3c92ebf3353`: imports_symbol; symbol: AgentCard
- `chunk_70d070872e14646f` → `chunk_1cfb5186cdb2fbd4`: imports_symbol; symbol: GetTaskPushNotificationRequest
- `chunk_70d070872e14646f` → `chunk_293e94c319be932a`: imports_symbol; symbol: SetTaskPushNotificationResponse
- `chunk_70d070872e14646f` → `chunk_2fc5452fd1a1beb4`: imports_symbol; symbol: SendTaskStreamingResponse
- `chunk_70d070872e14646f` → `chunk_3c259747ed401b91`: imports_symbol; symbol: A2AClientHTTPError
- `chunk_70d070872e14646f` → `chunk_40303fde39531e4e`: imports_symbol; symbol: A2AClientJSONError
- `chunk_70d070872e14646f` → `chunk_4e571f6d9165848b`: imports_symbol; symbol: CancelTaskRequest
- `chunk_70d070872e14646f` → `chunk_5765a357b9387587`: imports_symbol; symbol: SetTaskPushNotificationRequest
- `chunk_70d070872e14646f` → `chunk_62fd45475bcdd543`: imports_symbol; symbol: GetTaskResponse
- `chunk_70d070872e14646f` → `chunk_637231d6b5bd62e4`: file_import; symbol: not specified
- `chunk_70d070872e14646f` → `chunk_6a66bef065f88083`: imports_symbol; symbol: TaskStatusUpdateEvent
- `chunk_70d070872e14646f` → `chunk_86f22ff56f90782f`: imports_symbol; symbol: JSONRPCResponse
- `chunk_70d070872e14646f` → `chunk_8c61e8dc796b1716`: imports_symbol; symbol: CancelTaskResponse
- `chunk_70d070872e14646f` → `chunk_908d1fa56db85982`: imports_symbol; symbol: SendTaskStreamingRequest
- `chunk_70d070872e14646f` → `chunk_9b7e43db24365714`: imports_symbol; symbol: SendTaskResponse
- `chunk_70d070872e14646f` → `chunk_a11ddf314127f8c9`: imports_symbol; symbol: Task
- `chunk_70d070872e14646f` → `chunk_d36f27cdca6e5912`: imports_symbol; symbol: GetTaskPushNotificationResponse
- `chunk_70d070872e14646f` → `chunk_dca92bcefced8e54`: imports_symbol; symbol: TaskArtifactUpdateEvent
- `chunk_70d070872e14646f` → `chunk_e63b0ad5bc01cc9e`: imports_symbol; symbol: SendTaskRequest
- `chunk_70d070872e14646f` → `chunk_ea776097a0f2551e`: imports_symbol; symbol: JSONRPCError
- `chunk_70d070872e14646f` → `chunk_eac65360a190e24c`: imports_symbol; symbol: GetTaskRequest
- `chunk_70d070872e14646f` → `chunk_ef6168ecb0ca77ae`: imports_symbol; symbol: TaskPushNotificationConfig
- `chunk_70d070872e14646f` → `chunk_f8d625203ad30154`: imports_symbol; symbol: JSONRPCRequest
- `chunk_71efd67c86ac91d5` → `chunk_54f4a49f867fbc27`: imports_symbol; symbol: create_database_flow
- `chunk_7272c12b8a9f2db2` → `chunk_ca10c0b8b165fd43`: imports_symbol; symbol: ReadDoc
- `chunk_7272c12b8a9f2db2` → `chunk_ca10c0b8b165fd43`: imports_symbol; symbol: Answer
- `chunk_7272c12b8a9f2db2` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_7272c12b8a9f2db2` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_7280699e806968a4` → `chunk_daf50629a9c1a199`: imports_symbol; symbol: CrawlWebsiteNode
- `chunk_7280699e806968a4` → `chunk_daf50629a9c1a199`: imports_symbol; symbol: AnalyzeContentBatchNode
- `chunk_7280699e806968a4` → `chunk_daf50629a9c1a199`: imports_symbol; symbol: GenerateReportNode
- `chunk_7280699e806968a4` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_7280699e806968a4` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_773dca9e3bd2a927` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncNode
- `chunk_773dca9e3bd2a927` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncBatchFlow
- `chunk_773dca9e3bd2a927` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_78738e0fab77ae70` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_78738e0fab77ae70` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchFlow
- `chunk_78738e0fab77ae70` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_7b0d064e46b12f91` → `chunk_9a02ca2ca8829725`: imports_symbol; symbol: create_tao_flow
- `chunk_7bda2aa89d2cbef2` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_7bda2aa89d2cbef2` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncNode
- `chunk_7bda2aa89d2cbef2` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncFlow
- `chunk_7bda2aa89d2cbef2` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_7e44e3314fe9316d` → `chunk_93fc6c984e2de7b6`: imports_symbol; symbol: UnreliableAnswerNode
- `chunk_7e44e3314fe9316d` → `chunk_93fc6c984e2de7b6`: imports_symbol; symbol: SupervisorNode
- `chunk_7e44e3314fe9316d` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_7e44e3314fe9316d` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_7ecebf391cdb6e2e` → `chunk_d1bdad5098963154`: imports_symbol; symbol: create_event
- `chunk_7ecebf391cdb6e2e` → `chunk_d1bdad5098963154`: imports_symbol; symbol: list_events
- `chunk_7ecebf391cdb6e2e` → `chunk_d1bdad5098963154`: imports_symbol; symbol: list_calendar_lists
- `chunk_7ecebf391cdb6e2e` → `chunk_d1bdad5098963154`: file_import; symbol: not specified
- `chunk_7ecebf391cdb6e2e` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_7ecebf391cdb6e2e` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_8406f22031351c79` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncParallelBatchFlow
- `chunk_8406f22031351c79` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncBatchFlow
- `chunk_8406f22031351c79` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_855c859ae91ac35b` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_855c859ae91ac35b` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchFlow
- `chunk_855c859ae91ac35b` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_855c859ae91ac35b` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_87ceaecc000a9f6e` → `chunk_18433cf3c9cc2c36`: imports_symbol; symbol: get_tools
- `chunk_87ceaecc000a9f6e` → `chunk_18433cf3c9cc2c36`: imports_symbol; symbol: call_tool
- `chunk_87ceaecc000a9f6e` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_87ceaecc000a9f6e` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_87ceaecc000a9f6e` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_890d344dd585ca61` → `chunk_59df996d3c3d2ec7`: imports_symbol; symbol: image_to_base64
- `chunk_890d344dd585ca61` → `chunk_59df996d3c3d2ec7`: file_import; symbol: not specified
- `chunk_89452bfafdbc5165` → `chunk_99425bc4d56be557`: file_import; symbol: not specified
- `chunk_89452bfafdbc5165` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_89452bfafdbc5165` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_89da935ce5cf7b6d` → `chunk_425d6450326e4819`: file_import; symbol: not specified
- `chunk_89da935ce5cf7b6d` → `chunk_bd019cb54cd3e04b`: imports_symbol; symbol: tokenize
- `chunk_8adb3332f5094f52` → `chunk_01ac4b617402ad6f`: imports_symbol; symbol: setup_tracing
- `chunk_8adb3332f5094f52` → `chunk_01ac4b617402ad6f`: imports_symbol; symbol: test_langfuse_connection
- `chunk_8adb3332f5094f52` → `chunk_01ac4b617402ad6f`: file_import; symbol: not specified
- `chunk_8c7845ec20c9ecc5` → `chunk_9b46240b5119362b`: imports_symbol; symbol: create_debate_flow
- `chunk_8ce5c3a95bbffd5f` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncFlow
- `chunk_8ce5c3a95bbffd5f` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncParallelBatchNode
- `chunk_8ce5c3a95bbffd5f` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_8fbca5f714a1d713` → `chunk_d1719c46b4712573`: imports_symbol; symbol: CSVProcessor
- `chunk_8fbca5f714a1d713` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_8fbca5f714a1d713` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_8fbca5f714a1d713` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_90c0fa73aefc1728` → `chunk_637231d6b5bd62e4`: file_import; symbol: not specified
- `chunk_90c0fa73aefc1728` → `chunk_86f22ff56f90782f`: imports_symbol; symbol: JSONRPCResponse
- `chunk_90c0fa73aefc1728` → `chunk_b15e56840cf8d21e`: imports_symbol; symbol: ContentTypeNotSupportedError
- `chunk_90c0fa73aefc1728` → `chunk_bf433a82940cf5d7`: imports_symbol; symbol: UnsupportedOperationError
- `chunk_911cf84eebfcfad4` → `chunk_08c0c3da04a2d8e4`: imports_symbol; symbol: PushNotificationNotSupportedError
- `chunk_911cf84eebfcfad4` → `chunk_1cfb5186cdb2fbd4`: imports_symbol; symbol: GetTaskPushNotificationRequest
- `chunk_911cf84eebfcfad4` → `chunk_293e94c319be932a`: imports_symbol; symbol: SetTaskPushNotificationResponse
- `chunk_911cf84eebfcfad4` → `chunk_2ad0e8a657e2d432`: imports_symbol; symbol: TaskStatus
- `chunk_911cf84eebfcfad4` → `chunk_2fc5452fd1a1beb4`: imports_symbol; symbol: SendTaskStreamingResponse
- `chunk_911cf84eebfcfad4` → `chunk_4e571f6d9165848b`: imports_symbol; symbol: CancelTaskRequest
- `chunk_911cf84eebfcfad4` → `chunk_5765a357b9387587`: imports_symbol; symbol: SetTaskPushNotificationRequest
- `chunk_911cf84eebfcfad4` → `chunk_62fd45475bcdd543`: imports_symbol; symbol: GetTaskResponse
- `chunk_911cf84eebfcfad4` → `chunk_637231d6b5bd62e4`: imports_symbol; symbol: TaskState
- `chunk_911cf84eebfcfad4` → `chunk_637231d6b5bd62e4`: file_import; symbol: not specified
- `chunk_911cf84eebfcfad4` → `chunk_6a66bef065f88083`: imports_symbol; symbol: TaskStatusUpdateEvent
- `chunk_911cf84eebfcfad4` → `chunk_8072209f07c28222`: imports_symbol; symbol: TaskNotCancelableError
- `chunk_911cf84eebfcfad4` → `chunk_86f22ff56f90782f`: imports_symbol; symbol: JSONRPCResponse
- `chunk_911cf84eebfcfad4` → `chunk_8c61e8dc796b1716`: imports_symbol; symbol: CancelTaskResponse
- `chunk_911cf84eebfcfad4` → `chunk_908d1fa56db85982`: imports_symbol; symbol: SendTaskStreamingRequest
- `chunk_911cf84eebfcfad4` → `chunk_90c0fa73aefc1728`: imports_symbol; symbol: new_not_implemented_error
- `chunk_911cf84eebfcfad4` → `chunk_9121001e94a8b3c2`: imports_symbol; symbol: PushNotificationConfig
- `chunk_911cf84eebfcfad4` → `chunk_9321b60d8ce11e00`: imports_symbol; symbol: TaskSendParams
- `chunk_911cf84eebfcfad4` → `chunk_9b7e43db24365714`: imports_symbol; symbol: SendTaskResponse
- `chunk_911cf84eebfcfad4` → `chunk_a11ddf314127f8c9`: imports_symbol; symbol: Task
- `chunk_911cf84eebfcfad4` → `chunk_a317b074d4aa8f8d`: imports_symbol; symbol: TaskNotFoundError
- `chunk_911cf84eebfcfad4` → `chunk_b309c2d441f5f203`: imports_symbol; symbol: TaskResubscriptionRequest
- `chunk_911cf84eebfcfad4` → `chunk_b50be4ca4ec0fe0e`: imports_symbol; symbol: TaskIdParams
- `chunk_911cf84eebfcfad4` → `chunk_bdf52875dce23a9b`: imports_symbol; symbol: TaskQueryParams
- `chunk_911cf84eebfcfad4` → `chunk_c43c07f0af5210cf`: imports_symbol; symbol: InternalError
- `chunk_911cf84eebfcfad4` → `chunk_d36f27cdca6e5912`: imports_symbol; symbol: GetTaskPushNotificationResponse
- `chunk_911cf84eebfcfad4` → `chunk_d558aa471f9e7d8b`: imports_symbol; symbol: Artifact
- `chunk_911cf84eebfcfad4` → `chunk_e63b0ad5bc01cc9e`: imports_symbol; symbol: SendTaskRequest
- `chunk_911cf84eebfcfad4` → `chunk_ea776097a0f2551e`: imports_symbol; symbol: JSONRPCError
- `chunk_911cf84eebfcfad4` → `chunk_eac65360a190e24c`: imports_symbol; symbol: GetTaskRequest
- `chunk_911cf84eebfcfad4` → `chunk_ef6168ecb0ca77ae`: imports_symbol; symbol: TaskPushNotificationConfig
- `chunk_917566287dfa3ed5` → `chunk_39789356236888ae`: imports_symbol; symbol: GetTopicNode
- `chunk_917566287dfa3ed5` → `chunk_39789356236888ae`: imports_symbol; symbol: GenerateJokeNode
- `chunk_917566287dfa3ed5` → `chunk_39789356236888ae`: imports_symbol; symbol: GetFeedbackNode
- `chunk_917566287dfa3ed5` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_917566287dfa3ed5` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_92b119521ef41d0a` → `chunk_e80c2423e0aa04c3`: imports_symbol; symbol: parse_yaml
- `chunk_92b119521ef41d0a` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_92b119521ef41d0a` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_92dad70a2a593307` → `chunk_1d2cb7d506a68103`: imports_module; symbol: not specified
- `chunk_92dad70a2a593307` → `chunk_1d2cb7d506a68103`: file_import; symbol: not specified
- `chunk_92dad70a2a593307` → `chunk_92b119521ef41d0a`: imports_module; symbol: not specified
- `chunk_92dad70a2a593307` → `chunk_92b119521ef41d0a`: file_import; symbol: not specified
- `chunk_92dad70a2a593307` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_92dad70a2a593307` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_92dad70a2a593307` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_93fc6c984e2de7b6` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_93fc6c984e2de7b6` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_989be3f6dcac408b` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_989be3f6dcac408b` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_99425bc4d56be557` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncNode
- `chunk_99425bc4d56be557` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncFlow
- `chunk_99425bc4d56be557` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_9a02ca2ca8829725` → `chunk_989be3f6dcac408b`: imports_symbol; symbol: ThinkNode
- `chunk_9a02ca2ca8829725` → `chunk_989be3f6dcac408b`: imports_symbol; symbol: ActionNode
- `chunk_9a02ca2ca8829725` → `chunk_989be3f6dcac408b`: imports_symbol; symbol: ObserveNode
- `chunk_9a02ca2ca8829725` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_9a02ca2ca8829725` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_9a8f7ae86837fc0f` → `chunk_b1c2938a05f46ea3`: imports_symbol; symbol: create_podcast_flow
- `chunk_9b46240b5119362b` → `chunk_18f10027de047f8f`: imports_symbol; symbol: AdvocateFor
- `chunk_9b46240b5119362b` → `chunk_18f10027de047f8f`: imports_symbol; symbol: AdvocateAgainst
- `chunk_9b46240b5119362b` → `chunk_18f10027de047f8f`: imports_symbol; symbol: JudgeDebate
- `chunk_9b46240b5119362b` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_9b46240b5119362b` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_9d294af22e022bec` → `chunk_917566287dfa3ed5`: imports_symbol; symbol: create_joke_flow
- `chunk_9d75ed97c274c038` → `chunk_31238a6fb0579835`: imports_symbol; symbol: create_index
- `chunk_9d75ed97c274c038` → `chunk_31238a6fb0579835`: imports_symbol; symbol: add_vector
- `chunk_9d75ed97c274c038` → `chunk_31238a6fb0579835`: imports_symbol; symbol: search_vectors
- `chunk_9d75ed97c274c038` → `chunk_31238a6fb0579835`: file_import; symbol: not specified
- `chunk_9d75ed97c274c038` → `chunk_65267d798ee6cf4c`: imports_symbol; symbol: get_embedding
- `chunk_9d75ed97c274c038` → `chunk_65267d798ee6cf4c`: file_import; symbol: not specified
- `chunk_9d75ed97c274c038` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_9d75ed97c274c038` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_a1c2a6f62733cf93` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_a1c2a6f62733cf93` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchNode
- `chunk_a1c2a6f62733cf93` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_a1c2a6f62733cf93` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_a21ae5e988132963` → `chunk_6f0fba99af15b2ef`: imports_symbol; symbol: create_streaming_chat_flow
- `chunk_a2505e22d23b56bd` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_a2505e22d23b56bd` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_a2505e22d23b56bd` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_a371052d18fd8f54` → `chunk_0b31a5e4521d49bd`: file_import; symbol: not specified
- `chunk_a371052d18fd8f54` → `chunk_41ff20bbaff0cab5`: imports_symbol; symbol: A2AServer
- `chunk_a371052d18fd8f54` → `chunk_64dfe57771bd1f56`: imports_symbol; symbol: TaskManager
- `chunk_a371052d18fd8f54` → `chunk_911cf84eebfcfad4`: file_import; symbol: not specified
- `chunk_a371052d18fd8f54` → `chunk_99d9eeda09ab2beb`: imports_symbol; symbol: InMemoryTaskManager
- `chunk_a8109773490d4892` → `chunk_10c5e8372f94d68c`: imports_symbol; symbol: parse
- `chunk_a8109773490d4892` → `chunk_425d6450326e4819`: file_import; symbol: not specified
- `chunk_a8109773490d4892` → `chunk_64bda7992f8536ca`: imports_symbol; symbol: reset
- `chunk_a8109773490d4892` → `chunk_ab5dba1f9fda9910`: imports_symbol; symbol: execute
- `chunk_a972fbc419172bc4` → `chunk_3e97140a0b9f4a50`: imports_symbol; symbol: create_deep_research_flow
- `chunk_ab40b798a647533d` → `chunk_4aa7e4a95f3a5176`: imports_symbol; symbol: check_email
- `chunk_ab40b798a647533d` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_ab40b798a647533d` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_ae365df008de54c0` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncNode
- `chunk_ae365df008de54c0` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncParallelBatchNode
- `chunk_ae365df008de54c0` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncParallelBatchFlow
- `chunk_ae365df008de54c0` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_afd996d45a17776c` → `chunk_45fae4abfeb6c993`: imports_symbol; symbol: create_heartbeat_flow
- `chunk_b1c2938a05f46ea3` → `chunk_bbcf6583cf4dff35`: imports_symbol; symbol: AnalyzeDocs
- `chunk_b1c2938a05f46ea3` → `chunk_bbcf6583cf4dff35`: imports_symbol; symbol: WriteScript
- `chunk_b1c2938a05f46ea3` → `chunk_bbcf6583cf4dff35`: imports_symbol; symbol: TextToSpeech
- `chunk_b1c2938a05f46ea3` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_b1c2938a05f46ea3` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_b40ba65d22b1811d` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_b40ba65d22b1811d` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchNode
- `chunk_b40ba65d22b1811d` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_b435af193e693ce8` → `chunk_04470ca0623169e6`: imports_symbol; symbol: ResultNotification
- `chunk_b435af193e693ce8` → `chunk_2dedbe3f6de58f52`: imports_symbol; symbol: CheckWeather
- `chunk_b435af193e693ce8` → `chunk_d9ad38608ff5491d`: imports_symbol; symbol: FollowUp
- `chunk_b435af193e693ce8` → `chunk_f3ad1562c334805a`: imports_symbol; symbol: BookHotel
- `chunk_b435af193e693ce8` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_b435af193e693ce8` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_b6429a13672663c0` → `chunk_4a153349eaa4794b`: imports_symbol; symbol: fake_stream_llm
- `chunk_b6429a13672663c0` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_b6429a13672663c0` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_b6429a13672663c0` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_b966846cf3f0e4e8` → `chunk_69a4bcce1c36dd20`: imports_symbol; symbol: CurateSources
- `chunk_b966846cf3f0e4e8` → `chunk_69a4bcce1c36dd20`: imports_symbol; symbol: FilterStories
- `chunk_b966846cf3f0e4e8` → `chunk_69a4bcce1c36dd20`: imports_symbol; symbol: SummarizeStories
- `chunk_b966846cf3f0e4e8` → `chunk_69a4bcce1c36dd20`: imports_symbol; symbol: FormatNewsletter
- `chunk_b966846cf3f0e4e8` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_b966846cf3f0e4e8` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_bab789b610a77213` → `chunk_4488cf50bffd177f`: imports_symbol; symbol: GenerateImageNode
- `chunk_bab789b610a77213` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_bab789b610a77213` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_bb3f5064d55fd5e4` → `chunk_bab789b610a77213`: imports_symbol; symbol: create_generation_flow
- `chunk_bbcf6583cf4dff35` → `chunk_0161cd2f893c24d2`: imports_symbol; symbol: text_to_speech
- `chunk_bbcf6583cf4dff35` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_bbcf6583cf4dff35` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_bbd67f050aa9739c` → `chunk_7ecebf391cdb6e2e`: imports_symbol; symbol: CreateCalendarEventNode
- `chunk_bbd67f050aa9739c` → `chunk_7ecebf391cdb6e2e`: imports_symbol; symbol: ListCalendarEventsNode
- `chunk_bbd67f050aa9739c` → `chunk_7ecebf391cdb6e2e`: imports_symbol; symbol: ListCalendarsNode
- `chunk_bbd67f050aa9739c` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_bbd67f050aa9739c` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_bc4fd638512f2be7` → `chunk_0367efd98554aa88`: imports_symbol; symbol: create_text_to_sql_flow
- `chunk_bc4fd638512f2be7` → `chunk_b979f09f119ce4ed`: imports_symbol; symbol: populate_database
- `chunk_bc4fd638512f2be7` → `chunk_b979f09f119ce4ed`: imports_symbol; symbol: DB_FILE
- `chunk_bc4fd638512f2be7` → `chunk_b979f09f119ce4ed`: file_import; symbol: not specified
- `chunk_bd6a836c58db6683` → `chunk_35eaf7b0f17f46a0`: imports_symbol; symbol: TracingConfig
- `chunk_bd6a836c58db6683` → `chunk_35eaf7b0f17f46a0`: file_import; symbol: not specified
- `chunk_bd6a836c58db6683` → `chunk_57a50f34f89bf36d`: imports_symbol; symbol: trace_flow
- `chunk_bd6a836c58db6683` → `chunk_57a50f34f89bf36d`: file_import; symbol: not specified
- `chunk_bd6a836c58db6683` → `chunk_bd6c59e4f8578035`: imports_symbol; symbol: LangfuseTracer
- `chunk_bd6a836c58db6683` → `chunk_e8fd18a6a7822243`: file_import; symbol: not specified
- `chunk_c7300e1703ef1602` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_c7300e1703ef1602` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_c77f357e9a8524fa` → `chunk_cc87f8672fac52f4`: imports_symbol; symbol: call_llm
- `chunk_c77f357e9a8524fa` → `chunk_cc87f8672fac52f4`: file_import; symbol: not specified
- `chunk_c79cdad02966e151` → `chunk_1436f3c92ebf3353`: imports_symbol; symbol: AgentCard
- `chunk_c79cdad02966e151` → `chunk_40303fde39531e4e`: imports_symbol; symbol: A2AClientJSONError
- `chunk_c79cdad02966e151` → `chunk_637231d6b5bd62e4`: file_import; symbol: not specified
- `chunk_ca087e0a962b7f36` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_ca087e0a962b7f36` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_ca10c0b8b165fd43` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_ca10c0b8b165fd43` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_ca77abcf77ce6fcf` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchNode
- `chunk_ca77abcf77ce6fcf` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_ca77abcf77ce6fcf` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_cadfc16d14ea57bb` → `chunk_09156c18ce34b7a9`: imports_symbol; symbol: analyze_results
- `chunk_cadfc16d14ea57bb` → `chunk_32be8df479ab7dd6`: imports_symbol; symbol: SearchTool
- `chunk_cadfc16d14ea57bb` → `chunk_32be8df479ab7dd6`: file_import; symbol: not specified
- `chunk_cadfc16d14ea57bb` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_cadfc16d14ea57bb` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_d0b1048e9698a6e5` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_d0b1048e9698a6e5` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_d0b1048e9698a6e5` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_d1719c46b4712573` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchNode
- `chunk_d1719c46b4712573` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_d3b9b93655fc5350` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_d3b9b93655fc5350` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_d3b9b93655fc5350` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_d5ffaeb68d6dbc41` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_d5ffaeb68d6dbc41` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchNode
- `chunk_d5ffaeb68d6dbc41` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_d71b21f68ec7f38a` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_d71b21f68ec7f38a` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_d9b8f79f285b6b83` → `chunk_23ef461e7c54abc9`: imports_symbol; symbol: FetchRecipes
- `chunk_d9b8f79f285b6b83` → `chunk_23ef461e7c54abc9`: imports_symbol; symbol: SuggestRecipe
- `chunk_d9b8f79f285b6b83` → `chunk_23ef461e7c54abc9`: imports_symbol; symbol: GetApproval
- `chunk_d9b8f79f285b6b83` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncFlow
- `chunk_d9b8f79f285b6b83` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_d9b8f79f285b6b83` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_daf50629a9c1a199` → `chunk_1576c19c87303947`: imports_symbol; symbol: analyze_site
- `chunk_daf50629a9c1a199` → `chunk_628bf19588d30cb1`: imports_symbol; symbol: WebCrawler
- `chunk_daf50629a9c1a199` → `chunk_628bf19588d30cb1`: file_import; symbol: not specified
- `chunk_daf50629a9c1a199` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_daf50629a9c1a199` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchNode
- `chunk_daf50629a9c1a199` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_dc2da69a7e57986a` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_dc2da69a7e57986a` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_dc9f169f3970953d` → `chunk_04285d326770b26c`: imports_symbol; symbol: A2AClientError
- `chunk_dc9f169f3970953d` → `chunk_2b5331fea6551925`: imports_symbol; symbol: A2AClient
- `chunk_dc9f169f3970953d` → `chunk_637231d6b5bd62e4`: imports_symbol; symbol: TaskState
- `chunk_dc9f169f3970953d` → `chunk_637231d6b5bd62e4`: file_import; symbol: not specified
- `chunk_dc9f169f3970953d` → `chunk_6fbbb4ad51604ad0`: imports_symbol; symbol: TextPart
- `chunk_dc9f169f3970953d` → `chunk_70d070872e14646f`: file_import; symbol: not specified
- `chunk_dc9f169f3970953d` → `chunk_86f22ff56f90782f`: imports_symbol; symbol: JSONRPCResponse
- `chunk_ddfe19077e50b5b9` → `chunk_69a4bcce1c36dd20`: imports_symbol; symbol: TOPICS
- `chunk_ddfe19077e50b5b9` → `chunk_b966846cf3f0e4e8`: imports_symbol; symbol: create_newsletter_flow
- `chunk_ded36a6898be7007` → `chunk_402c3517623e6f48`: imports_symbol; symbol: PRODUCT
- `chunk_ded36a6898be7007` → `chunk_402c3517623e6f48`: imports_symbol; symbol: SAMPLE_LEADS
- `chunk_ded36a6898be7007` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_ded36a6898be7007` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_df54b4a7b2c11bae` → `chunk_c619080b6dbd1a35`: imports_symbol; symbol: get_embedding
- `chunk_df54b4a7b2c11bae` → `chunk_c619080b6dbd1a35`: file_import; symbol: not specified
- `chunk_df54b4a7b2c11bae` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_df54b4a7b2c11bae` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_e336ec9f7df2adb2` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchNode
- `chunk_e336ec9f7df2adb2` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_e336ec9f7df2adb2` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_e482031d8d50e8b4` → `chunk_35eaf7b0f17f46a0`: imports_symbol; symbol: TracingConfig
- `chunk_e482031d8d50e8b4` → `chunk_57a50f34f89bf36d`: imports_symbol; symbol: trace_flow
- `chunk_e482031d8d50e8b4` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncNode
- `chunk_e482031d8d50e8b4` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncFlow
- `chunk_e482031d8d50e8b4` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_e56e02b3ec2d330c` → `chunk_db37da287657c26f`: imports_symbol; symbol: fixed_size_chunk
- `chunk_e56e02b3ec2d330c` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_e56e02b3ec2d330c` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_e56e02b3ec2d330c` → `chunk_f490d1da79768001`: imports_symbol; symbol: BatchNode
- `chunk_e56e02b3ec2d330c` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_e7f222061791959a` → `chunk_44e26f313f106dba`: imports_symbol; symbol: ExtractFields
- `chunk_e7f222061791959a` → `chunk_44e26f313f106dba`: imports_symbol; symbol: Validate
- `chunk_e7f222061791959a` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_e7f222061791959a` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_e89c9cd725ed3e91` → `chunk_80a0fbd3c7725929`: imports_symbol; symbol: call_book_hotel_api
- `chunk_e89c9cd725ed3e91` → `chunk_80a0fbd3c7725929`: imports_symbol; symbol: call_check_weather_api
- `chunk_e89c9cd725ed3e91` → `chunk_80a0fbd3c7725929`: file_import; symbol: not specified
- `chunk_e89c9cd725ed3e91` → `chunk_c1647b9a4b0c234d`: imports_symbol; symbol: load_conversation
- `chunk_e89c9cd725ed3e91` → `chunk_c1647b9a4b0c234d`: imports_symbol; symbol: save_conversation
- `chunk_e89c9cd725ed3e91` → `chunk_c1647b9a4b0c234d`: file_import; symbol: not specified
- `chunk_e89c9cd725ed3e91` → `chunk_d20cdbdcac499825`: imports_symbol; symbol: format_chat_history
- `chunk_e89c9cd725ed3e91` → `chunk_d20cdbdcac499825`: file_import; symbol: not specified
- `chunk_e89c9cd725ed3e91` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_e89c9cd725ed3e91` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_e8fd18a6a7822243` → `chunk_35eaf7b0f17f46a0`: imports_symbol; symbol: TracingConfig
- `chunk_e8fd18a6a7822243` → `chunk_35eaf7b0f17f46a0`: file_import; symbol: not specified
- `chunk_e98c1d895b27a89a` → `chunk_413529fdaffc2f0e`: imports_symbol; symbol: ProcessPDFBatchNode
- `chunk_e98c1d895b27a89a` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_e98c1d895b27a89a` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_e9d7fbc93cbd97c6` → `chunk_1436f3c92ebf3353`: imports_symbol; symbol: AgentCard
- `chunk_e9d7fbc93cbd97c6` → `chunk_41ff20bbaff0cab5`: imports_symbol; symbol: A2AServer
- `chunk_e9d7fbc93cbd97c6` → `chunk_4c358d219e17eae5`: imports_symbol; symbol: PocketFlowTaskManager
- `chunk_e9d7fbc93cbd97c6` → `chunk_60c31cfe8bc49e54`: imports_symbol; symbol: MissingAPIKeyError
- `chunk_e9d7fbc93cbd97c6` → `chunk_637231d6b5bd62e4`: file_import; symbol: not specified
- `chunk_e9d7fbc93cbd97c6` → `chunk_d1c14132ed71dc62`: imports_symbol; symbol: AgentCapabilities
- `chunk_e9d7fbc93cbd97c6` → `chunk_f90f2b6e68a81c56`: imports_symbol; symbol: AgentSkill
- `chunk_eb550e87b5734336` → `chunk_e56e02b3ec2d330c`: imports_symbol; symbol: EmbedDocumentsNode
- `chunk_eb550e87b5734336` → `chunk_e56e02b3ec2d330c`: imports_symbol; symbol: CreateIndexNode
- `chunk_eb550e87b5734336` → `chunk_e56e02b3ec2d330c`: imports_symbol; symbol: EmbedQueryNode
- `chunk_eb550e87b5734336` → `chunk_e56e02b3ec2d330c`: imports_symbol; symbol: RetrieveDocumentNode
- `chunk_eb550e87b5734336` → `chunk_e56e02b3ec2d330c`: imports_symbol; symbol: ChunkDocumentsNode
- `chunk_eb550e87b5734336` → `chunk_e56e02b3ec2d330c`: imports_symbol; symbol: GenerateAnswerNode
- `chunk_eb550e87b5734336` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_eb550e87b5734336` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_ed2788812765104c` → `chunk_10c5e8372f94d68c`: imports_symbol; symbol: parse
- `chunk_ed2788812765104c` → `chunk_425d6450326e4819`: file_import; symbol: not specified
- `chunk_ee4741757ddaf353` → `chunk_0e4cb9e04f03a24c`: imports_symbol; symbol: stream_llm
- `chunk_ee4741757ddaf353` → `chunk_0e4cb9e04f03a24c`: file_import; symbol: not specified
- `chunk_ee4741757ddaf353` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncNode
- `chunk_ee4741757ddaf353` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_f07a63c87d07d83f` → `chunk_4e65682a7c4d8f56`: imports_symbol; symbol: ProcessNode
- `chunk_f07a63c87d07d83f` → `chunk_4e65682a7c4d8f56`: imports_symbol; symbol: ReviewNode
- `chunk_f07a63c87d07d83f` → `chunk_4e65682a7c4d8f56`: imports_symbol; symbol: ResultNode
- `chunk_f07a63c87d07d83f` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncFlow
- `chunk_f07a63c87d07d83f` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_f0b0e3f316b4f66b` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_f0b0e3f316b4f66b` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_f0b0e3f316b4f66b` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_f0e877e4f0f49e8e` → `chunk_d5ffaeb68d6dbc41`: imports_symbol; symbol: WriteContent
- `chunk_f0e877e4f0f49e8e` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_f0e877e4f0f49e8e` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_f19dfc92f325926a` → `chunk_ca087e0a962b7f36`: imports_symbol; symbol: WordCounter
- `chunk_f19dfc92f325926a` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_f19dfc92f325926a` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_f3328b96bf99f52d` → `chunk_5b290d89e9d7352b`: imports_symbol; symbol: ImplementFunction
- `chunk_f3328b96bf99f52d` → `chunk_6a7f0600b863a918`: imports_symbol; symbol: GenerateTestCases
- `chunk_f3328b96bf99f52d` → `chunk_cfafc7419e2aa1a0`: imports_symbol; symbol: RunTests
- `chunk_f3328b96bf99f52d` → `chunk_f02c9c34cae8aba3`: imports_symbol; symbol: Revise
- `chunk_f3328b96bf99f52d` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_f3328b96bf99f52d` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_f8159d518d2593d1` → `chunk_04eb14d659b17093`: imports_symbol; symbol: create_mermaid_flow
- `chunk_f8cc940455308a99` → `chunk_cadfc16d14ea57bb`: imports_symbol; symbol: SearchNode
- `chunk_f8cc940455308a99` → `chunk_cadfc16d14ea57bb`: imports_symbol; symbol: AnalyzeResultsNode
- `chunk_f8cc940455308a99` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_f8cc940455308a99` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_fa9f7536688bcc43` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_fa9f7536688bcc43` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_facaf1f5d6c1d10a` → `chunk_f490d1da79768001`: imports_symbol; symbol: Node
- `chunk_facaf1f5d6c1d10a` → `chunk_f490d1da79768001`: imports_symbol; symbol: Flow
- `chunk_facaf1f5d6c1d10a` → `chunk_f490d1da79768001`: file_import; symbol: not specified
- `chunk_fecd7e4e79e864fe` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncParallelBatchNode
- `chunk_fecd7e4e79e864fe` → `chunk_f490d1da79768001`: imports_symbol; symbol: AsyncParallelBatchFlow
- `chunk_fecd7e4e79e864fe` → `chunk_f490d1da79768001`: file_import; symbol: not specified

Other source sections remain available in `chunks.jsonl`; code is stored only once.

## 3. Business risks

Analysis status: **COMPLETED**

### risk_0000: Failed article jobs stay active after the error is reported

**Finding:** When a background article job ends with an error, the progress endpoint forwards the error update but does not close the job or clear its active state.

**Trigger:** When a started article-generation job hits an exception and emits an error progress update, the client continues using the progress stream for that job.

**Observed behavior:** The progress stream cleans up only when step == 'complete'. Error updates are streamed to the client, but the job remains in active tracking and the stream continues with heartbeat events.

**Business impact:** Failed article requests stay stuck in progress tracking and stale job records remain allocated.

**Expected behavior:** Ensure every terminal job outcome closes client progress tracking and clears active job state.

**Associated workflow IDs:** `business_path_08b3130fd848c5dc`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| articleForm submit handler | `cookbook/pocketflow-fastapi-background/static/index.html` | `chunk_014bdf029cb18585` |
| start_job | `cookbook/pocketflow-fastapi-background/main.py` | `chunk_a37d754e8c59d3e3` |
