# django-payments-main — Context for AI

7 workflows · 2 risk findings · 196 verified connections · 181 code sections

Attach this file and `chunks.jsonl` together. Every code reference below identifies a source section in `chunks.jsonl`.

## 1. Business workflows

### 1. provider-backed payment checkout and callback handling

Workflow ID: `business_path_60b18a242ff0f9fb`

Application code builds a provider-specific checkout form, redirects the user or returns hidden fields, then handles callback processing to update payment state and return success/failure outcomes.

**Purpose:** submit a payment and receive a gateway redirect or callback-driven completion

**Business outcome**

- creates a gateway-ready payment form
- directs the customer to the correct payment/callback URL
- enables provider implementations to update payment status and amounts

**Important behavior and rules**

- A provider implementation should return or raise RedirectNeeded for customer navigation after checkout creation.
- Callback handling should update the payment instance and then redirect to success or failure URLs.
- If a payment variant name is missing from settings, provider_factory raises ValueError.
- If PAYMENT_HOST is unset and Sites is unavailable, configuration is invalid.

**Identified functions:** `BasicProvider.process_data`, `BasicProvider.get_return_url`, `BasicProvider.get_form`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `payments/stripe/providers.py` | `chunk_2977e95b1ac23898` |
| MercadoPagoProvider.create_preference | `payments/mercadopago/__init__.py` | `chunk_2c19279b69e65a2d` |
| Source section | `payments/stripe/providers.py` | `chunk_444e890eb5d91bee` |
| get_payment_model | `payments/__init__.py` | `chunk_7efb6aa47a100ca3` |
| BasicProvider | `payments/core.py` | `chunk_870405bfc93e4ebc` |
| DummyProvider.process_data | `payments/dummy/__init__.py` | `chunk_ea3f9b01fbcd390e` |

### 2. card payment authorization and settlement

Workflow ID: `business_path_14afb4c904e906be`

Braintree payment form collects card data, submits a gateway sale, then captures and confirms the payment before redirecting to the success URL.

**Purpose:** submit a payment and complete checkout

**Business outcome**

- payment is settled with the gateway
- payment state becomes CONFIRMED
- captured amount is recorded
- caller is redirected to the success page

**Important behavior and rules**

- Braintree supports capture/settlement flows but not pre-authorization mode.
- A successful Braintree sale causes the payment to be settled and confirmed locally.
- Only waiting payments are moved into input state before rendering the form
- Gateway sale is only attempted when the form has no errors and no prior transaction_id
- Provider initialization rejects pre-authorization mode

**Identified functions:** `BraintreePaymentForm.clean`, `BraintreeProvider.get_form`, `BraintreePaymentForm.save`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| BraintreeProvider.__init__ | `payments/braintree/__init__.py` | `chunk_33f301840d24b30d` |
| Source section | `payments/models.py` | `chunk_7f48b3e76c391cc5` |
| BraintreePaymentForm.clean | `payments/braintree/forms.py` | `chunk_bf70018d7eaa9972` |
| test_provider_redirects_to_success_on_payment_success | `payments/braintree/test_braintree.py` | `chunk_eefa674a9cd18a97` |

### 3. card payment authorization and capture via Authorize.Net

Workflow ID: `business_path_6982e20b6fa0efba`

Authorize.Net provider posts card data to the gateway, updates payment status from waiting/input to confirmed or error, and redirects to the success URL on valid input.

**Purpose:** complete payment using card details and receive a result page

**Business outcome**

- successful approval creates a confirmed payment
- declined or errored card input surfaces a form error message
- transaction id is stored for the approved charge
- caller is redirected to the success URL on valid form submission

**Important behavior and rules**

- Authorize.Net provider only supports capture flows and not pre-authorization.
- A response code of 1 confirms the payment and stores the transaction id; code 2 rejects it.
- Only waiting payments are converted to input state before validation
- Gateway response is processed only when the form is error-free and there is no existing transaction_id
- Authorize.Net pre-authorization is rejected at initialization

**Identified functions:** `AuthorizeNetProvider.get_form`, `PaymentForm.clean`, `AuthorizeNetProvider.get_payment_response`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| PaymentForm.clean | `payments/authorizenet/forms.py` | `chunk_03291ad9bd6ee7a6` |
| test_provider_redirects_to_success_on_payment_success | `payments/authorizenet/test_authorizenet.py` | `chunk_10c5cc425c45dd0b` |
| AuthorizeNetProvider.__init__ | `payments/authorizenet/__init__.py` | `chunk_72e0cab9c5a54f30` |
| Source section | `payments/models.py` | `chunk_7f48b3e76c391cc5` |

### 4. gateway-specific checkout callback handling

Workflow ID: `business_path_57afbea1c19415a7`

CyberSource and Sagepay provider flows create gateway requests, process gateway callbacks, and move payment state to confirmed, preauth, rejected, or error depending on gateway outcome.

**Purpose:** hand off payment to an external processor and reconcile the returned result

**Business outcome**

- handles 3-D Secure or encrypted return flows
- updates fraud and payment status based on gateway reason/status codes
- stores transaction identifiers and payment metadata
- routes the user to success or failure depending on outcome

**Important behavior and rules**

- CyberSource supports both capture and preauthorization flows depending on provider configuration.
- CyberSource callback processing requires an XID match and signed token before payment validation proceeds.
- Sagepay encrypts checkout payload fields before redirecting the user to the external payment page.
- CyberSource capture-only or preauth path is selected by the capture flag
- CyberSource 3-D Secure callback must match the stored XID and contain a signed token
- Sagepay only confirms a waiting payment when returned Status is OK

**Identified functions:** `SagepayProvider.process_data`, `CyberSourceProvider.process_data`, `CyberSourceProvider.charge`, `SagepayProvider.get_hidden_fields`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `payments/cybersource/__init__.py` | `chunk_0f9ce3345893de40` |
| SagepayProvider.__init__ | `payments/sagepay/__init__.py` | `chunk_10f58cad7e2c11da` |
| Source section | `payments/models.py` | `chunk_7f48b3e76c391cc5` |
| Source section | `payments/cybersource/__init__.py` | `chunk_baebd57594d1f752` |
| test_provider_raises_redirect_needed_on_success | `payments/sofort/test_sofort.py` | `chunk_eb856ca3be01943c` |
| Source section | `payments/cybersource/__init__.py` | `chunk_fbfa4ef577ae745f` |

### 5. Process provider callback to update a payment record

Workflow ID: `business_path_c3778b1f3da6e259`

Django payment callback route locks a payment row, resolves the configured provider, and delegates asynchronous callback processing to update payment state.

**Purpose:** Deliver asynchronous payment status updates for a specific payment

**Business outcome**

- Prevents concurrent callback races
- Updates the canonical payment record from provider data
- Returns a deterministic response for the callback caller

**Important behavior and rules**

- A callback request must resolve to a specific payment via token before provider processing occurs.
- Concurrent callbacks for one payment are serialized with a database row lock.
- Static callback errors do not expose the full token in the 404 response.
- Lock the payment row before processing callback data
- Return JSON 400 when the provider variant is invalid
- Return JSON 400 when the webhook token cannot be extracted

**Identified functions:** `/payments/process/<uuid:token>/`, `payments.urls.process_data`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| CoinbaseProvider.process_data | `payments/coinbase/__init__.py` | `chunk_272be524ca0ecbfd` |
| process_data | `payments/urls.py` | `chunk_ba4463764ed697b7` |
| DotpayProvider.process_data | `payments/dotpay/__init__.py` | `chunk_eaeeaf63e03cb235` |
| ProcessDataLockingTestCase.test_process_data_locks_the_payment_row | `payments/test_urls.py` | `chunk_ec6bc21444c61b96` |

### 6. PayPal checkout and post-payment reconciliation

Workflow ID: `business_path_76c6213522540dfd`

PayPal provider creates or reuses checkout sessions, redirects the user, then processes the return/callback to capture, preauthorize, refund, or reject the payment.

**Purpose:** Guide the buyer through PayPal checkout and reconcile the payment after return or refund/capture operations

**Business outcome**

- Creates redirectable checkout sessions
- Confirms, preauthorizes, refunds, or rejects payment records
- Persists API response data for later reconciliation

**Important behavior and rules**

- A PayPal callback must include a token; otherwise the provider returns a forbidden response.
- When PayerID is absent, the payment is rejected unless it was already confirmed; then the success URL is used.
- Refunds are only allowed when the payment is confirmed and a payment_intent exists in stored session data.
- If an existing approval link is present, reuse it instead of creating a new payment.
- If the return request lacks token, reject the callback.
- If PayPal returns HTTP 401 on an authorized request, refresh the token and retry once.

**Identified functions:** `payments.paypal.PaypalProvider.capture`, `payments.paypal.PaypalProvider.refund`, `payments.paypal.PaypalProvider.get_form`, `payments.paypal.PaypalProvider.process_data`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| test_provider_renews_access_token | `payments/paypal/test_paypal.py` | `chunk_0c5f911042fa327a` |
| test_provider_refund_failure_no_payment_intent | `payments/paypal/test_paypal.py` | `chunk_44867c1a7d34f0e8` |
| test_provider_request_without_payerid_redirects_on_failure | `payments/paypal/test_paypal.py` | `chunk_469cdd3d17d1d8fd` |
| Source section | `payments/paypal/__init__.py` | `chunk_4cf94194f16e0660` |
| test_provider_captures_payment | `payments/paypal/test_paypal.py` | `chunk_6ccbcfe20857a590` |
| authorize | `payments/paypal/__init__.py` | `chunk_a611d142cd8af74b` |
| Source section | `payments/paypal/__init__.py` | `chunk_b2585f5903443863` |
| Source section | `payments/paypal/__init__.py` | `chunk_d4f44cf220cb0d25` |
| test_provider_raises_redirect_needed_on_success | `payments/paypal/test_paypal.py` | `chunk_ee9c058f1b2af79f` |
| test_provider_refunds_payment_fully | `payments/paypal/test_paypal.py` | `chunk_f07a97c4cc7e0a9d` |

### 7. Provider-specific payment request composition and callback verification

Workflow ID: `business_path_20a73509f5a820d6`

Dotpay and Coinbase providers build provider-specific payment requests and reconcile callbacks by verifying signatures or custom tokens before confirming or rejecting the payment.

**Purpose:** Start and confirm payment flows through gateway-specific fields and signed callback data

**Business outcome**

- Produces provider-specific redirect/form payloads
- Rejects malformed or forged callback data
- Confirms completed payments and records transaction identifiers

**Important behavior and rules**

- Dotpay callback data must match a SHA-256 signature derived from configured fields and the payment id.
- Dotpay rejects callbacks when the signature or payment id does not validate.
- Coinbase only confirms a payment after the custom token in the callback matches the generated token for that payment.
- Dotpay requires a valid ProcessPaymentForm before accepting callback data.
- Coinbase callback data must contain a JSON order body and a matching custom token.
- Coinbase pre-authorization is not allowed when capture is disabled.

**Identified functions:** `payments.coinbase.CoinbaseProvider.get_checkout_code`, `payments.coinbase.CoinbaseProvider.process_data`, `payments.dotpay.DotpayProvider.process_data`, `payments.dotpay.DotpayProvider.get_hidden_fields`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| ProcessPaymentForm.save | `payments/dotpay/forms.py` | `chunk_22220b3fe07065a8` |
| CoinbaseProvider.get_custom_token/get_checkout_code/process_data | `payments/coinbase/__init__.py` | `chunk_272be524ca0ecbfd` |
| test_process_data_payment_accepted | `payments/dotpay/test_dotpay.py` | `chunk_68e6c28fff8bf4e1` |
| test_process_data | `payments/coinbase/test_coinbase.py` | `chunk_88450674f173be90` |
| DotpayProvider.get_action/get_hidden_fields/process_data | `payments/dotpay/__init__.py` | `chunk_eaeeaf63e03cb235` |

## 2. Verified code connections and remaining repository context

Connections are static source relationships; they do not prove runtime execution.

- `chunk_02847f544a81ac43` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentError
- `chunk_02847f544a81ac43` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_02847f544a81ac43` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_02847f544a81ac43` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_02847f544a81ac43` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: BasicProvider
- `chunk_02847f544a81ac43` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_03291ad9bd6ee7a6` → `chunk_0a4b912c2a5d2bf8`: imports_symbol; symbol: CreditCardPaymentForm
- `chunk_03291ad9bd6ee7a6` → `chunk_0a4b912c2a5d2bf8`: file_import; symbol: not specified
- `chunk_03291ad9bd6ee7a6` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_03291ad9bd6ee7a6` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_052882efa37288ac` → `chunk_0a4b912c2a5d2bf8`: imports_symbol; symbol: PaymentForm
- `chunk_052882efa37288ac` → `chunk_0a4b912c2a5d2bf8`: file_import; symbol: not specified
- `chunk_052882efa37288ac` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: FraudStatus
- `chunk_052882efa37288ac` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_052882efa37288ac` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_0a4b912c2a5d2bf8` → `chunk_1c593f1379acc147`: imports_symbol; symbol: CreditCardExpiryField
- `chunk_0a4b912c2a5d2bf8` → `chunk_1c593f1379acc147`: imports_symbol; symbol: CreditCardNameField
- `chunk_0a4b912c2a5d2bf8` → `chunk_1c593f1379acc147`: imports_symbol; symbol: CreditCardNumberField
- `chunk_0a4b912c2a5d2bf8` → `chunk_1c593f1379acc147`: imports_symbol; symbol: CreditCardVerificationField
- `chunk_0a4b912c2a5d2bf8` → `chunk_1c593f1379acc147`: file_import; symbol: not specified
- `chunk_0e3c9df6160c8969` → `chunk_0cfdca4f7bddea00`: file_import; symbol: not specified
- `chunk_0e3c9df6160c8969` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentError
- `chunk_0e3c9df6160c8969` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_0e3c9df6160c8969` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PurchasedItem
- `chunk_0e3c9df6160c8969` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_0e3c9df6160c8969` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_10c5cc425c45dd0b` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_10c5cc425c45dd0b` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_10c5cc425c45dd0b` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_10f58cad7e2c11da` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_10f58cad7e2c11da` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_10f58cad7e2c11da` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: BasicProvider
- `chunk_10f58cad7e2c11da` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_10f58cad7e2c11da` → `chunk_faae3645fb56bbff`: file_import; symbol: not specified
- `chunk_1c593f1379acc147` → `chunk_0cfdca4f7bddea00`: imports_symbol; symbol: get_month_choices
- `chunk_1c593f1379acc147` → `chunk_0cfdca4f7bddea00`: imports_symbol; symbol: get_year_choices
- `chunk_1c593f1379acc147` → `chunk_0cfdca4f7bddea00`: file_import; symbol: not specified
- `chunk_1c593f1379acc147` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: CARD_TYPES
- `chunk_1c593f1379acc147` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: get_credit_card_issuer
- `chunk_1c593f1379acc147` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_1c593f1379acc147` → `chunk_d7bd1b0540a03d2c`: imports_symbol; symbol: CreditCardExpiryWidget
- `chunk_1c593f1379acc147` → `chunk_d7bd1b0540a03d2c`: imports_symbol; symbol: CreditCardNumberWidget
- `chunk_1c593f1379acc147` → `chunk_d7bd1b0540a03d2c`: file_import; symbol: not specified
- `chunk_22220b3fe07065a8` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_22220b3fe07065a8` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_272be524ca0ecbfd` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_272be524ca0ecbfd` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_272be524ca0ecbfd` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: BasicProvider
- `chunk_272be524ca0ecbfd` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_2c19279b69e65a2d` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentError
- `chunk_2c19279b69e65a2d` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_2c19279b69e65a2d` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_2c19279b69e65a2d` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_2c19279b69e65a2d` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: BasicProvider
- `chunk_2c19279b69e65a2d` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_2c19279b69e65a2d` → `chunk_faae3645fb56bbff`: file_import; symbol: not specified
- `chunk_33f301840d24b30d` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_33f301840d24b30d` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_33f301840d24b30d` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_33f301840d24b30d` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: BasicProvider
- `chunk_33f301840d24b30d` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_33f301840d24b30d` → `chunk_bf70018d7eaa9972`: imports_symbol; symbol: BraintreePaymentForm
- `chunk_33f301840d24b30d` → `chunk_bf70018d7eaa9972`: file_import; symbol: not specified
- `chunk_3ed1e737e90d1720` → `chunk_0a4b912c2a5d2bf8`: imports_symbol; symbol: CreditCardPaymentFormWithName
- `chunk_3ed1e737e90d1720` → `chunk_0a4b912c2a5d2bf8`: file_import; symbol: not specified
- `chunk_3ed1e737e90d1720` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentError
- `chunk_3ed1e737e90d1720` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_444e890eb5d91bee` → `chunk_0a4b912c2a5d2bf8`: imports_symbol; symbol: PaymentForm
- `chunk_444e890eb5d91bee` → `chunk_0a4b912c2a5d2bf8`: file_import; symbol: not specified
- `chunk_444e890eb5d91bee` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentError
- `chunk_444e890eb5d91bee` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_444e890eb5d91bee` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_444e890eb5d91bee` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_444e890eb5d91bee` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: BasicProvider
- `chunk_444e890eb5d91bee` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_47b071a8fe7fa2c4` → `chunk_2977e95b1ac23898`: imports_symbol; symbol: StripeProviderV3
- `chunk_47b071a8fe7fa2c4` → `chunk_444e890eb5d91bee`: file_import; symbol: not specified
- `chunk_47fe52d8e7862343` → `chunk_2c19279b69e65a2d`: imports_symbol; symbol: MercadoPagoProvider
- `chunk_47fe52d8e7862343` → `chunk_2c19279b69e65a2d`: file_import; symbol: not specified
- `chunk_47fe52d8e7862343` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentError
- `chunk_47fe52d8e7862343` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_47fe52d8e7862343` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PurchasedItem
- `chunk_47fe52d8e7862343` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_47fe52d8e7862343` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_4fa0dff3f99d7fe2` → `chunk_1c593f1379acc147`: imports_symbol; symbol: CreditCardNumberField
- `chunk_4fa0dff3f99d7fe2` → `chunk_1c593f1379acc147`: file_import; symbol: not specified
- `chunk_51506ce2ad5a78d2` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_51506ce2ad5a78d2` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PurchasedItem
- `chunk_51506ce2ad5a78d2` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_51506ce2ad5a78d2` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_51506ce2ad5a78d2` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_68e6c28fff8bf4e1` → `chunk_22220b3fe07065a8`: imports_symbol; symbol: COMPLETED
- `chunk_68e6c28fff8bf4e1` → `chunk_22220b3fe07065a8`: imports_symbol; symbol: REJECTED
- `chunk_68e6c28fff8bf4e1` → `chunk_22220b3fe07065a8`: file_import; symbol: not specified
- `chunk_68e6c28fff8bf4e1` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_68e6c28fff8bf4e1` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_72e0cab9c5a54f30` → `chunk_03291ad9bd6ee7a6`: imports_symbol; symbol: PaymentForm
- `chunk_72e0cab9c5a54f30` → `chunk_03291ad9bd6ee7a6`: file_import; symbol: not specified
- `chunk_72e0cab9c5a54f30` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_72e0cab9c5a54f30` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_72e0cab9c5a54f30` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_72e0cab9c5a54f30` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: BasicProvider
- `chunk_72e0cab9c5a54f30` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_7ea01ce5ca3b245a` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_7ea01ce5ca3b245a` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_7efb6aa47a100ca3` → `chunk_b5415b4b2bdba77f`: file_import; symbol: not specified
- `chunk_7f48b3e76c391cc5` → `chunk_629191f538e01494`: file_import; symbol: not specified
- `chunk_830722a9450f0a3b` → `chunk_0cfdca4f7bddea00`: file_import; symbol: not specified
- `chunk_830722a9450f0a3b` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentError
- `chunk_830722a9450f0a3b` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_830722a9450f0a3b` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_830722a9450f0a3b` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_830722a9450f0a3b` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: BasicProvider
- `chunk_830722a9450f0a3b` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: get_credit_card_issuer
- `chunk_830722a9450f0a3b` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_830722a9450f0a3b` → `chunk_fc4aab28def6b99c`: imports_symbol; symbol: PaymentForm
- `chunk_830722a9450f0a3b` → `chunk_fc4aab28def6b99c`: file_import; symbol: not specified
- `chunk_870405bfc93e4ebc` → `chunk_0a4b912c2a5d2bf8`: file_import; symbol: not specified
- `chunk_870405bfc93e4ebc` → `chunk_b5415b4b2bdba77f`: file_import; symbol: not specified
- `chunk_870405bfc93e4ebc` → `chunk_faae3645fb56bbff`: file_import; symbol: not specified
- `chunk_88450674f173be90` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_88450674f173be90` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PurchasedItem
- `chunk_88450674f173be90` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_b5415b4b2bdba77f` → `chunk_7efb6aa47a100ca3`: imports_module; symbol: not specified
- `chunk_b5415b4b2bdba77f` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_ba4463764ed697b7` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_bcdc1f5fada70265` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_bcdc1f5fada70265` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: get_payment_model
- `chunk_bcdc1f5fada70265` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_bcdc1f5fada70265` → `chunk_c4de48111a6b8ca8`: imports_symbol; symbol: TestPaymentForm
- `chunk_bf70018d7eaa9972` → `chunk_0a4b912c2a5d2bf8`: imports_symbol; symbol: CreditCardPaymentFormWithName
- `chunk_bf70018d7eaa9972` → `chunk_0a4b912c2a5d2bf8`: file_import; symbol: not specified
- `chunk_bf70018d7eaa9972` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_bf70018d7eaa9972` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_c4de48111a6b8ca8` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: get_payment_model
- `chunk_c4de48111a6b8ca8` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_d5d05babaf5eaf94` → `chunk_0a4b912c2a5d2bf8`: imports_symbol; symbol: CreditCardPaymentFormWithName
- `chunk_d5d05babaf5eaf94` → `chunk_0a4b912c2a5d2bf8`: imports_symbol; symbol: PaymentForm
- `chunk_d5d05babaf5eaf94` → `chunk_0a4b912c2a5d2bf8`: file_import; symbol: not specified
- `chunk_d5d05babaf5eaf94` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_d5d05babaf5eaf94` → `chunk_7f48b3e76c391cc5`: imports_symbol; symbol: BasePayment
- `chunk_d5d05babaf5eaf94` → `chunk_faae3645fb56bbff`: file_import; symbol: not specified
- `chunk_d9a63c9f2822046e` → `chunk_0a4b912c2a5d2bf8`: imports_symbol; symbol: PaymentForm
- `chunk_d9a63c9f2822046e` → `chunk_0a4b912c2a5d2bf8`: file_import; symbol: not specified
- `chunk_d9a63c9f2822046e` → `chunk_3ed1e737e90d1720`: imports_symbol; symbol: PaymentForm
- `chunk_d9a63c9f2822046e` → `chunk_3ed1e737e90d1720`: file_import; symbol: not specified
- `chunk_d9a63c9f2822046e` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: ExternalPostNeeded
- `chunk_d9a63c9f2822046e` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: FraudStatus
- `chunk_d9a63c9f2822046e` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentError
- `chunk_d9a63c9f2822046e` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_d9a63c9f2822046e` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_d9a63c9f2822046e` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_d9a63c9f2822046e` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: BasicProvider
- `chunk_d9a63c9f2822046e` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: get_credit_card_issuer
- `chunk_d9a63c9f2822046e` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_dd57caaf5f176d46` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentError
- `chunk_dd57caaf5f176d46` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_dd57caaf5f176d46` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PurchasedItem
- `chunk_dd57caaf5f176d46` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_dd57caaf5f176d46` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_ea3f9b01fbcd390e` → `chunk_052882efa37288ac`: imports_symbol; symbol: DummyForm
- `chunk_ea3f9b01fbcd390e` → `chunk_052882efa37288ac`: file_import; symbol: not specified
- `chunk_ea3f9b01fbcd390e` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentError
- `chunk_ea3f9b01fbcd390e` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_ea3f9b01fbcd390e` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_ea3f9b01fbcd390e` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_ea3f9b01fbcd390e` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: BasicProvider
- `chunk_ea3f9b01fbcd390e` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_eaeeaf63e03cb235` → `chunk_22220b3fe07065a8`: imports_symbol; symbol: ProcessPaymentForm
- `chunk_eaeeaf63e03cb235` → `chunk_22220b3fe07065a8`: file_import; symbol: not specified
- `chunk_eaeeaf63e03cb235` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: BasicProvider
- `chunk_eaeeaf63e03cb235` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_eb856ca3be01943c` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_eb856ca3be01943c` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_eb856ca3be01943c` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_ec6bc21444c61b96` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentError
- `chunk_ec6bc21444c61b96` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_eefa674a9cd18a97` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_eefa674a9cd18a97` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_eefa674a9cd18a97` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_fa01d1f8f651c22f` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: FraudStatus
- `chunk_fa01d1f8f651c22f` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentError
- `chunk_fa01d1f8f651c22f` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_fa01d1f8f651c22f` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: RedirectNeeded
- `chunk_fa01d1f8f651c22f` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_faae3645fb56bbff` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified
- `chunk_fbe9579ae6a7fd42` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PurchasedItem
- `chunk_fbe9579ae6a7fd42` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_fbe9579ae6a7fd42` → `chunk_7f48b3e76c391cc5`: imports_symbol; symbol: BasePayment
- `chunk_fbe9579ae6a7fd42` → `chunk_faae3645fb56bbff`: file_import; symbol: not specified
- `chunk_fc4aab28def6b99c` → `chunk_0a4b912c2a5d2bf8`: imports_symbol; symbol: CreditCardPaymentFormWithName
- `chunk_fc4aab28def6b99c` → `chunk_0a4b912c2a5d2bf8`: file_import; symbol: not specified
- `chunk_fc4aab28def6b99c` → `chunk_7efb6aa47a100ca3`: imports_symbol; symbol: PaymentStatus
- `chunk_fc4aab28def6b99c` → `chunk_7efb6aa47a100ca3`: file_import; symbol: not specified
- `chunk_fc4aab28def6b99c` → `chunk_870405bfc93e4ebc`: imports_symbol; symbol: get_credit_card_issuer
- `chunk_fc4aab28def6b99c` → `chunk_870405bfc93e4ebc`: file_import; symbol: not specified

Other source sections remain available in `chunks.jsonl`; code is stored only once.

## 3. Business risks

Analysis status: **COMPLETED**

### risk_0000: CyberSource rejection results are committed as successful payments

**Finding:** When CyberSource returns listed reject or verification-failure reason codes, the provider records the payment as CONFIRMED or PREAUTH and uses the success path.

**Trigger:** A CyberSource charge or payer-auth callback returns a mapped reject or verification-failure reason code.

**Observed behavior:** The mapped reject branches set a reject-oriented fraud result and then call the success-state helper, which sets captured amount and moves the payment to CONFIRMED or PREAUTH.

**Business impact:** Rejected or suspicious transactions enter the successful payment workflow.

**Expected behavior:** Gateway reject outcomes must never commit a payment into a successful lifecycle state.

**Associated workflow IDs:** `business_path_57afbea1c19415a7`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `payments/cybersource/__init__.py` | `chunk_0f9ce3345893de40` |
| Source section | `payments/models.py` | `chunk_7f48b3e76c391cc5` |
| Source section | `payments/cybersource/__init__.py` | `chunk_baebd57594d1f752` |
| Source section | `payments/cybersource/__init__.py` | `chunk_fbfa4ef577ae745f` |

### risk_0001: Sagepay callbacks update whichever waiting payment is supplied

**Finding:** Submitting a valid Sagepay callback against a different waiting payment changes that payment because the callback is not matched to the payment before status changes.

**Trigger:** A Sagepay callback is processed for a waiting payment object.

**Observed behavior:** The callback handler decrypts the callback, reads the returned status, and confirms or rejects the supplied payment based on WAITING state and returned status without validating that the callback belongs to that payment.

**Business impact:** A different payment record is reconciled with the wrong gateway result.

**Expected behavior:** Gateway callbacks must be bound to the intended payment before any payment state transition is committed.

**Associated workflow IDs:** `business_path_57afbea1c19415a7`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| SagepayProvider.process_data | `payments/sagepay/__init__.py` | `chunk_10f58cad7e2c11da` |
| process_data | `payments/urls.py` | `chunk_ba4463764ed697b7` |
