# mini-swe-agent-main — Context for AI

15 workflows · 0 risk findings · 466 verified connections · 432 code sections

Attach this file and `chunks.jsonl` together. Every code reference below identifies a source section in `chunks.jsonl`.

## 1. Business workflows

### 1. agent orchestration and trajectory persistence / task execution loop and limit enforcement

Workflow ID: `business_path_164ecdd419e365b8`

DefaultAgent renders prompts, queries the model, executes returned bash actions in the environment, and saves the resulting trajectory or exit state. / DefaultAgent processes model-driven shell actions, captures observations, and stops on wall-time, cost, or repeated format-error limits.

**Purpose:** solve a task by repeatedly querying an LLM, running the model-selected shell actions, and recording the session / carry out a task until submission or a stopping limit is reached

**Business outcome**

- Produces a saved run record with model/environment metadata
- Converts model actions into local command execution
- Stops on limits, time, or task completion
- produces a submitted final output when completion is reached
- terminates cleanly on time, cost, or format-error budget conditions
- preserves step-by-step observation history for later review

**Important behavior and rules**

- The agent stops and emits LimitsExceeded when step or cost limits are reached, and TimeExceeded when wall-clock time is reached.
- A clean step resets the consecutive format-error counter; repeated format errors can end the run with RepeatedFormatError.
- If output_path is configured, the agent writes the serialized trajectory to disk after each loop iteration.
- A run that exceeds wall-clock budget terminates cleanly with TimeExceeded.
- Consecutive format errors are tracked and can terminate the run at the configured threshold.
- Failed tool-call parsing still contributes to billing/cost accounting.
- Stop when wall_time_limit_seconds is reached
- Stop when max_consecutive_format_errors is reached
- Count format errors against the cost budget

**Identified functions:** `DefaultAgent.step`, `DefaultAgent.run`, `DefaultAgent.query`, `DefaultAgent.save`, `DefaultAgent.execute_actions`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| OpenRouterModel | `src/minisweagent/models/openrouter_model.py` | `chunk_01c94c8c07ea442b` |
| test_wall_time_limit_enforcement | `tests/agents/test_default.py` | `chunk_05c62c910e8844f1` |
| Source section | `src/minisweagent/agents/default.py` | `chunk_5a5887c60edc8843` |
| test_repeated_format_errors_terminate_cleanly | `tests/agents/test_default.py` | `chunk_7cb615605a167d4d` |
| Source section | `src/minisweagent/agents/default.py` | `chunk_8f30f2a408c8f61c` |
| test_message_history_tracking | `tests/agents/test_default.py` | `chunk_927ab8f3676f881f` |
| parse_toolcall_actions | `src/minisweagent/models/utils/actions_toolcall.py` | `chunk_bb150d3352e3d600` |
| FormatError/Submitted/LimitsExceeded/TimeExceeded | `src/minisweagent/exceptions.py` | `chunk_beeff3307d88c18a` |
| test_format_errors_count_against_cost_limit | `tests/agents/test_default.py` | `chunk_cf76583bd6e7a9a3` |
| LocalEnvironment.execute | `src/minisweagent/environments/local.py` | `chunk_d0fd281bfdef33e4` |
| test_agent_save_includes_class_names | `tests/run/test_save.py` | `chunk_de13ba6224a4f262` |
| test_step_adds_messages | `tests/agents/test_default.py` | `chunk_fff3a4d912278433` |

### 2. human-in-the-loop command execution / interactive task execution and mode switching

Workflow ID: `business_path_9afc14491173bbff`

InteractiveAgent lets a human switch modes, confirm or reject LM commands, and intercept submission or interruption before execution. / InteractiveAgent routes user confirmations and mode switches (confirm, yolo, human) while allowing continuation after completion.

**Purpose:** supervise or override LM-issued commands before they run / inspect, approve, reject, or directly issue commands before submission

**Business outcome**

- Prevents undesired command execution unless confirmed
- Allows user to switch between human, confirm, and yolo modes
- Supports new-task handoff or clean submission when the agent finishes
- supports safer confirmation before shell commands
- permits yolo mode for fast execution
- allows human mode to bypass model calls and enter commands directly
- lets users append new tasks after completion

**Important behavior and rules**

- In confirm mode, any command not matching a whitelist regex requires user confirmation before execution.
- A user rejection or /u interruption prevents command execution and raises UserInterruption.
- When confirm_exit is enabled, a submission request first prompts the user for a new task or quit decision.
- A user may reject a proposed action and the conversation records that rejection.
- Entering /y switches the agent into yolo mode and bypasses future confirmations.
- Entering /u from confirm mode can switch to human mode and reject the current action.
- Non-whitelisted actions require confirmation
- Whitelisted actions can skip confirmation
- Human mode should not call the model

**Identified functions:** `InteractiveAgent.query`, `InteractiveAgent._check_for_new_task_or_submit`, `InteractiveAgent.execute_actions`, `InteractiveAgent.step`, `InteractiveAgent._ask_confirmation_or_interrupt`, `InteractiveAgent.run`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| test_confirmation_mode_switch_to_human_with_rejection | `tests/agents/test_interactive.py` | `chunk_0a015fc268dab2af` |
| Source section | `src/minisweagent/agents/interactive.py` | `chunk_0a69e435cedc1bc5` |
| test_human_mode_switch_to_yolo | `tests/agents/test_interactive.py` | `chunk_0ef46b4f86bfe1ce` |
| test_action_rejection_and_recovery | `tests/agents/test_interactive.py` | `chunk_0fffddb45b111b83` |
| test_whitelisted_actions_skip_confirmation | `tests/agents/test_interactive.py` | `chunk_157100400599916d` |
| test_continue_after_completion_with_new_task | `tests/agents/test_interactive.py` | `chunk_240ae74f6cfe47a2` |
| test_yolo_mode_activation | `tests/agents/test_interactive.py` | `chunk_45c8ca435adf0314` |
| test_human_mode_basic_functionality | `tests/agents/test_interactive.py` | `chunk_53b1145da8281a6a` |
| test_non_whitelisted_action_requires_confirmation | `tests/agents/test_interactive.py` | `chunk_68d6e29fdad29a7f` |
| test_human_mode_switch_to_confirm | `tests/agents/test_interactive.py` | `chunk_7b05386a25e68abd` |
| test_continue_after_completion_multiple_cycles | `tests/agents/test_interactive.py` | `chunk_800e2785b054f5e8` |
| Source section | `src/minisweagent/agents/interactive.py` | `chunk_8ba2247e7fb17b4e` |
| test_successful_completion_with_confirmation | `tests/agents/test_interactive.py` | `chunk_a648acb8c3564678` |
| UserInterruption/FormatError | `src/minisweagent/exceptions.py` | `chunk_beeff3307d88c18a` |
| LocalEnvironment.execute/_check_finished | `src/minisweagent/environments/local.py` | `chunk_d0fd281bfdef33e4` |
| Source section | `src/minisweagent/agents/interactive.py` | `chunk_e5c59a4f9a311533` |

### 3. local task execution

Workflow ID: `business_path_bf56f3a9c6e0675e`

CLI user provides a task and config, then the mini CLI builds runtime components and runs the agent in a local environment.

**Purpose:** run a coding/problem-solving task with selected model, agent, and environment settings

**Business outcome**

- starts an agent session
- persists the resulting trajectory to the configured output path
- shows the saved output location when available

**Important behavior and rules**

- Later config specs override earlier ones, and UNSET values are omitted during recursive merge.
- If the task is not supplied in config, the CLI prompts the user for it.
- The CLI only reports a saved trajectory when an output path is configured.

**Identified functions:** `src/minisweagent/run/mini.py:main`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| get_agent_class/get_agent | `src/minisweagent/agents/__init__.py` | `chunk_14741a57a30d6b30` |
| main | `src/minisweagent/run/mini.py` | `chunk_1524a0dadbc8d637` |
| get_model | `src/minisweagent/models/__init__.py` | `chunk_4567d473a70901a9` |
| recursive_merge | `src/minisweagent/utils/serialize.py` | `chunk_63236af5541e60e3` |
| get_environment_class/get_environment | `src/minisweagent/environments/__init__.py` | `chunk_c8f7612f6f51f7d6` |
| package_dir/global_config_dir | `src/minisweagent/__init__.py` | `chunk_c99464483c37187a` |

### 4. benchmark batch execution

Workflow ID: `business_path_a65aedf3ed4548a9`

Batch benchmark runner loads SWE-bench instances, creates per-instance environments and agents, executes them in parallel, and archives submissions and trajectories.

**Purpose:** run many benchmark instances and collect artifacts for evaluation

**Business outcome**

- produces evaluation-ready outputs
- records per-instance status
- archives workspace submission artifacts

**Important behavior and rules**

- Per-instance processing writes a trajectory file even when execution fails, including exit status and exception info.
- Instances with existing submission archives are skipped unless redo_existing is requested.
- Existing submission archives are skipped unless redo_existing is enabled.
- copy_submission requires a container-backed environment exposing container_id and executable.

**Identified functions:** `src/minisweagent/run/benchmarks/programbench.py:main`, `src/minisweagent/run/benchmarks/programbench.py:process_instance`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `src/minisweagent/run/benchmarks/programbench.py` | `chunk_4e96a3869941a924` |
| Source section | `src/minisweagent/run/benchmarks/programbench.py` | `chunk_58a0e5f864192e88` |
| Source section | `src/minisweagent/run/benchmarks/programbench.py` | `chunk_7ad78cdc025694af` |
| module header and DATASET_MAPPING | `src/minisweagent/run/benchmarks/swebench.py` | `chunk_ef0158240404aa4b` |

### 5. LLM provider adapter

Workflow ID: `business_path_88a8deb6689e4988`

The Litellm model adapter sends completion requests, retries on transient failures, computes cost, parses tool calls, and packages the response for the agent loop.

**Purpose:** obtain a structured model response for the agent loop

**Business outcome**

- returns assistant message plus metadata
- tracks per-call cost
- preserves response data when formatting fails

**Important behavior and rules**

- Model.query implementations must persist response and cost on FormatError.
- Global model limits are enforced against cumulative cost and call count.
- Retry logic is applied around the LLM completion call for non-abort exceptions.
- Anthropic thinking blocks are reordered before API submission.
- FormatError paths persist response and cost before re-raising.

**Identified functions:** `src/minisweagent/models/litellm_model.py:query`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| LitellmModel.__init__/query | `src/minisweagent/models/litellm_model.py` | `chunk_0f7756391b750dc4` |
| GlobalModelStats | `src/minisweagent/models/__init__.py` | `chunk_4567d473a70901a9` |
| _reorder_anthropic_thinking_blocks | `src/minisweagent/models/utils/anthropic_utils.py` | `chunk_87e1ac5a1fe5050f` |

### 6. LLM provider response handling

Workflow ID: `business_path_b207ae1007ac9f8d`

Model wrapper calls a Responses API, extracts bash tool calls, and preserves the raw response payload when parsing fails.

**Purpose:** Send a conversation to a model provider, recover tool-call actions, and keep the raw response for later inspection if parsing fails

**Business outcome**

- Returns a structured message enriched with actions, cost, and timestamp
- Preserves the raw provider response in FormatError extra data for debugging and replay
- Supports stateless Responses-API conversation handling

**Important behavior and rules**

- If parsing actions fails, the handler enriches the FormatError message with cost metadata and the serialized raw response before re-raising.
- Responses-API output parsing only accepts function_call items named bash with a command argument.
- Responses-API truncation reason max_output_tokens is normalized to finish_reason='length' so the error template can report cut-off behavior.

**Identified functions:** `OpenRouterResponseModel.query`, `LitellmResponseModel.query`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| test_persisted_response_round_trips_through_json | `tests/models/test_format_error_response_persistence.py` | `chunk_419228e42f945198` |
| test_litellm_model_format_error_persists_response | `tests/models/test_format_error_response_persistence.py` | `chunk_905b71410cb2c811` |
| _TOOLCALL_TEMPLATE | `tests/models/test_truncation_finish_reason.py` | `chunk_a3cfc322b7c11184` |
| LitellmResponseModel.query | `src/minisweagent/models/litellm_response_model.py` | `chunk_ae352e849425b0e3` |
| module docstring | `tests/models/test_format_error_response_persistence.py` | `chunk_b23fe33efbdb04e9` |
| parse_toolcall_actions_response | `src/minisweagent/models/utils/actions_toolcall_response.py` | `chunk_bf7acfc3bc96fe67` |
| OpenRouterResponseModel.query | `src/minisweagent/models/openrouter_response_model.py` | `chunk_eaff58997eb46d2a` |

### 7. LLM provider orchestration through Portkey

Workflow ID: `business_path_67d84c205c9812e9`

Portkey-backed chat/completions and Responses-API wrappers send stateless requests, parse bash actions, and serialize response metadata with cost tracking.

**Purpose:** Call a model provider via Portkey, recover tool-call actions, and keep structured response metadata for later use

**Business outcome**

- Returns structured assistant message output with parsed actions
- Persists serialized response metadata in message.extra
- Tracks cost and adds it to GLOBAL_MODEL_STATS
- Supports both chat-completions and Responses-API provider modes

**Important behavior and rules**

- If a model response cannot be parsed into actions, the response payload is persisted before the original FormatError is re-raised.
- Tool calls must target the bash function and include a command argument.
- The Portkey Responses-API wrapper treats response objects as stateless and flattens prior response objects into outgoing input items.
- Portkey API key must be present before initialization succeeds.

**Identified functions:** `PortkeyModel.query`, `PortkeyResponseAPIModel.query`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `tests/models/test_portkey_model.py` | `chunk_4078a25944159e10` |
| Source section | `tests/models/test_portkey_model.py` | `chunk_45af038da305346c` |
| Source section | `tests/models/test_portkey_model.py` | `chunk_62f17132ab9ee66e` |
| PortkeyResponseAPIModel.__init__ | `src/minisweagent/models/portkey_response_model.py` | `chunk_6621213052031421` |
| Source section | `src/minisweagent/models/portkey_model.py` | `chunk_679fe8d47e7809da` |
| Source section | `tests/models/test_portkey_model.py` | `chunk_8f7f13f63726f45d` |
| Source section | `tests/models/test_portkey_model.py` | `chunk_915340d3fdaea842` |
| test_response_api_model_stateless_flattens_response | `tests/models/test_portkey_response_model.py` | `chunk_9346fd79b1657c65` |
| parse_toolcall_actions_response | `src/minisweagent/models/utils/actions_toolcall_response.py` | `chunk_bf7acfc3bc96fe67` |
| Source section | `src/minisweagent/models/portkey_model.py` | `chunk_ccac1c9236e4861b` |
| Source section | `src/minisweagent/models/portkey_model.py` | `chunk_e1ed86a408aee5de` |
| test_portkey_response_model_format_error_persists_response_with_model_dump | `tests/models/test_format_error_response_persistence.py` | `chunk_e30c483dc7038f6a` |

### 8. legacy text action parsing and observation formatting

Workflow ID: `business_path_99806a1902aa48a3`

Legacy text-based model utilities extract a single bash action from model text and render observation messages from tool outputs.

**Purpose:** Turn a text-only model reply into one executable bash action and then render execution output back into chat messages

**Business outcome**

- Produces a single normalized command for execution
- Raises a structured FormatError when output does not match the required shape
- Formats tool output into a user-visible observation message for the next turn

**Important behavior and rules**

- A text response must match the action regex exactly once or a FormatError is raised.
- The error template can use finish_reason and action count to explain truncation or mismatch conditions.
- Exactly one action must be present in the text response.
- Observation formatting can optionally expand multimodal content when a regex is configured.

**Identified functions:** `parse_regex_actions`, `format_observation_messages`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| parse_regex_actions | `src/minisweagent/models/utils/actions_text.py` | `chunk_5a7e2e83d68b5009` |
| LitellmTextbasedModel._parse_actions | `src/minisweagent/models/litellm_textbased_model.py` | `chunk_8aa11d29c823da85` |
| TestRegexActionsTemplateKwargs | `tests/models/test_truncation_finish_reason.py` | `chunk_a3cfc322b7c11184` |

### 9. containerized command execution for agent tasks

Workflow ID: `business_path_a2b8a58d84768187`

Caller supplies a command to DockerEnvironment; the environment runs it in a container and returns captured output/returncode, with a special submission marker raising Submitted.

**Purpose:** run a command in an isolated container and receive the result back

**Business outcome**

- Provides the sandbox used by agent workflows
- Converts command completion into structured observation output
- Ends the environment cleanly after use

**Important behavior and rules**

- The container runs with a configurable working directory, interpreter, timeout, and forwarded/configured environment variables.
- Explicit env entries take precedence over forwarded host env values in command construction.
- execute() asserts that a container has been started before running a command
- A submission is recognized only when the first output line is COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT and returncode is 0

**Identified functions:** `DockerEnvironment.__init__`, `DockerEnvironment.cleanup`, `DockerEnvironment.execute`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `tests/environments/test_docker.py` | `chunk_0ea15b575c5a5a13` |
| Source section | `tests/environments/test_docker.py` | `chunk_294654e2b4f70fad` |
| Source section | `tests/environments/test_docker.py` | `chunk_2b2e6d0587916a01` |
| Source section | `tests/environments/test_docker.py` | `chunk_2d9b071b8a1ef0f4` |
| Source section | `tests/environments/test_docker.py` | `chunk_45edef9286a50c60` |
| Source section | `tests/environments/test_docker.py` | `chunk_4c82e138661f3fe7` |
| DockerEnvironment | `src/minisweagent/environments/docker.py` | `chunk_7ad2df29f66efd06` |
| Source section | `tests/environments/test_docker.py` | `chunk_8c812935128fe8f1` |
| Source section | `tests/environments/test_docker.py` | `chunk_9d227ca698628fe1` |
| Source section | `tests/environments/test_docker.py` | `chunk_bc3001ba40bff6dc` |
| Source section | `tests/environments/test_docker.py` | `chunk_dde322b78232fd3f` |
| Source section | `tests/environments/test_docker.py` | `chunk_f3a5d1772a98fee9` |

### 10. global configuration file management

Workflow ID: `business_path_4d99706840dfac27`

CLI user sets, unsets, edits, or initializes the global config file, which updates the .env-backed model/API-key state and reloads the runtime environment.

**Purpose:** initialize and maintain model/API-key settings

**Business outcome**

- Persists model selection and credential names/values
- Allows later runs to reuse configured defaults
- Supports editing and removal of config entries

**Important behavior and rules**

- Later configuration values overwrite earlier ones when written to the global config file.
- Unset removes the requested key without disturbing other keys.
- setup() only runs automatically on first use when MSWEA_CONFIGURED is not set
- setup() skips persisting an API key value when the user leaves it blank

**Identified functions:** `setup`, `unset`, `edit`, `set`, `configure_if_first_time`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| TestTyperAppIntegration.test_app_help_contains_config_file_path / test_app_no_args_is_help | `tests/run/test_extra_config.py` | `chunk_2223695eea7fc339` |
| TestConfigUnset | `tests/run/test_extra_config.py` | `chunk_5f47fbb33ae640a9` |
| TestConfigSet | `tests/run/test_extra_config.py` | `chunk_9b3ac1564b953ca4` |
| app | `src/minisweagent/run/utilities/config.py` | `chunk_cd1d73a686e478b7` |
| TestConfigSetup | `tests/run/test_extra_config.py` | `chunk_f260a2292d19e74a` |

### 11. trajectory browsing and inspection

Workflow ID: `business_path_9439a89735975182`

User opens a trajectory file or directory in the TrajectoryInspector UI, browses steps and trajectories, toggles reasoning, reloads files, and may open content in jless.

**Purpose:** review saved agent conversations and their rendered tool/assistant content

**Business outcome**

- Provides visual review of agent steps and reasoning
- Supports navigation across multiple trajectories and steps
- Allows refreshing from disk after file changes

**Important behavior and rules**

- The inspector accepts either a single file or a directory of *.traj.json files, and directory input must contain at least one trajectory file.
- Trajectory messages are rendered with null bytes stripped and ANSI content normalized for display.
- Reasoning is only shown for assistant messages when show_reasoning is enabled.
- Empty or missing trajectory input shows a no-data screen instead of crashing
- Reload clamps the saved step index to the new number of steps after file changes

**Identified functions:** `main`, `TrajectoryInspector.action_reload`, `TrajectoryInspector.__init__`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| test_trajectory_inspector_ansi_content | `tests/run/test_inspector.py` | `chunk_1d2e3096fe8c8801` |
| test_trajectory_inspector_reload_clamps_step | `tests/run/test_inspector.py` | `chunk_382641b55f4071cc` |
| test_trajectory_inspector_toggle_reasoning | `tests/run/test_inspector.py` | `chunk_5b3080b6f140c501` |
| main | `src/minisweagent/run/utilities/inspector.py` | `chunk_6684fa0da4b43989` |
| test_trajectory_inspector_reasoning_display | `tests/run/test_inspector.py` | `chunk_7e7a6190046c4440` |
| test_trajectory_inspector_reload | `tests/run/test_inspector.py` | `chunk_daebc8b6cfd0167b` |
| TrajectoryInspector.__init__ | `src/minisweagent/run/utilities/inspector.py` | `chunk_e02080e85f0eeb74` |
| test_trajectory_inspector_load_trajectory_formats | `tests/run/test_inspector.py` | `chunk_eba748e702ce4a5b` |

### 12. Run a local agent task from CLI

Workflow ID: `business_path_f3d50a1f7b6da0c9`

CLI user supplies config/model/task; mini main constructs the agent and runs the task, optionally writing an output trajectory file.

**Purpose:** Launch the agent against a user-provided task with selected model/environment settings

**Business outcome**

- Produces an agent submission/result
- Can persist a trajectory/output file for later inspection
- Supports confirm vs yolo mode and exit-immediately behavior

**Important behavior and rules**

- The mini CLI must call first-time configuration setup before executing the agent flow.
- If a task is not supplied, the CLI obtains it from a multiline prompt before running the agent.
- The CLI preserves an explicit cost_limit value of 0 during config merging.
- When task is not provided, the CLI prompts for it before running the agent.
- --exit-immediately flips confirm_exit to False.

**Identified functions:** `mini --help`, `python -m minisweagent --help`, `minisweagent.run.mini.main`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| test_configure_if_first_time_called | `tests/run/test_cli_integration.py` | `chunk_0df8c173051fab95` |
| _save_overview_data_yaml | `src/minisweagent/run/benchmarks/utils/batch_progress.py` | `chunk_5e5ea0bb98fba951` |
| test_cost_limit_zero_is_preserved | `tests/run/test_cli_integration.py` | `chunk_6346f7e9da698fa5` |
| test_no_exit_immediately_flag_sets_confirm_exit_true | `tests/run/test_cli_integration.py` | `chunk_801674cce2a2b821` |
| test_output_file_is_created | `tests/run/test_cli_integration.py` | `chunk_993dd1249b129a8c` |
| test_exit_immediately_flag_sets_confirm_exit_false | `tests/run/test_cli_integration.py` | `chunk_c83f8f444f6118d7` |
| test_mini_calls_prompt_when_no_task_provided | `tests/run/test_cli_integration.py` | `chunk_cd91e8881c6b9840` |

### 13. Run benchmark instances and persist predictions

Workflow ID: `business_path_6cf8d4e2929a0667`

Benchmark runner filters SWEBench instances, executes them in workers, records predictions and trajectories, and can skip or redo existing results.

**Purpose:** Process a selected SWEBench subset and write benchmark outputs for each instance

**Business outcome**

- Produces deterministic benchmark predictions
- Persists per-instance trajectory artifacts
- Allows rerun control via redo_existing and filtering

**Important behavior and rules**

- Filtering and slicing can reduce the benchmark instance set before execution.
- An existing predictions file may be left unchanged when redo_existing is false.
- A benchmark instance may be overwritten when redo_existing is true.
- Per-instance environment startup command is rendered with instance_id and passed as a dict to env.execute.
- Instances can be filtered by regex and sliced before execution.
- redo_existing=False skips instances that already have outputs.
- Exceptions during agent.run are caught and recorded into outputs rather than aborting the batch.

**Identified functions:** `filter_instances`, `update_preds_file`, `remove_from_preds_file`, `minisweagent.run.benchmarks.swebench.main`, `get_sb_environment`, `get_swebench_docker_image_name`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| test_filter_instances_no_filters | `tests/run/test_swebench.py` | `chunk_0e90f3d6bf2b5266` |
| test_swebench_end_to_end | `tests/run/test_swebench.py` | `chunk_0fcbca5d1291ddc8` |
| test_filter_instances_filter_and_slice | `tests/run/test_swebench.py` | `chunk_1f37422c228be9d8` |
| test_redo_existing_true_overwrites_existing | `tests/run/test_swebench.py` | `chunk_3132965cae92db67` |
| test_exception_handling_in_agent_run | `tests/run/test_swebench.py` | `chunk_5e69d17348b5a735` |
| test_different_exception_types | `tests/run/test_swebench.py` | `chunk_7dcfa807a928cccd` |
| test_filter_instances_regex_filter | `tests/run/test_swebench.py` | `chunk_ada29eaaa3add1ec` |
| test_update_preds_file_new_file | `tests/run/test_swebench.py` | `chunk_b999d7ae1fa2ae0c` |
| test_filter_instances_slice_only | `tests/run/test_swebench.py` | `chunk_d4c552386df28c6c` |
| test_redo_existing_false_skips_existing | `tests/run/test_swebench.py` | `chunk_f32a8d4b8bfb1a05` |
| test_get_sb_environment_runs_startup_command_as_dict | `tests/run/test_swebench.py` | `chunk_f5f74ef6dbb44d16` |

### 14. Track and summarize batch execution progress

Workflow ID: `business_path_11c142bc6944b601`

Batch progress manager tracks per-instance lifecycle, counts exit statuses, computes ETA and cost, and optionally saves a YAML overview report.

**Purpose:** Provide live progress feedback and a persisted summary during benchmark runs

**Business outcome**

- Shows live progress and ETA
- Aggregates exit statuses for review
- Persists a YAML summary of instance outcomes

**Important behavior and rules**

- The progress manager keeps a count of completed instances by exit status group sizes.
- Each completed instance is appended to the corresponding exit-status bucket before UI refresh and optional YAML persistence.
- ETA calculation avoids division by zero when no instances are completed.
- Instance removal from the task progress bar tolerates missing task IDs.

**Identified functions:** `RunBatchProgressManager.on_instance_start`, `RunBatchProgressManager.__init__`, `RunBatchProgressManager.update_instance_status`, `RunBatchProgressManager._save_overview_data_yaml`, `RunBatchProgressManager.on_instance_end`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| test_instance_lifecycle | `tests/run/test_batch_progress.py` | `chunk_23f4f83027515d1a` |
| RunBatchProgressManager | `src/minisweagent/run/benchmarks/utils/batch_progress.py` | `chunk_5e5ea0bb98fba951` |

### 15. Run benchmark evaluation batches

Workflow ID: `business_path_59dec117050df4c5`

CLI benchmark operator launches SWE-bench batch processing, which runs agent instances in sandboxed environments and persists per-instance submissions and trajectories.

**Purpose:** Evaluate many SWE-bench instances and collect results

**Business outcome**

- Produces per-instance model patches for evaluation
- Persists execution traces for later inspection
- Tracks batch progress and completion status

**Important behavior and rules**

- The batch runner skips already-processed instances unless redo_existing is enabled.
- Per-instance predictions are written under a lock to avoid concurrent file corruption.
- The environment class is chosen from configuration and image names are adapted for the selected backend.
- If redo_existing is false and preds.json already contains instance IDs, those instances are skipped.
- A startup command is rendered from the instance and executed before evaluation when configured.

**Identified functions:** `src/minisweagent/run/utilities/mini_extra.py:mini-extra swebench`, `src/minisweagent/run/benchmarks/swebench.py:main`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| main | `src/minisweagent/run/benchmarks/swebench.py` | `chunk_1ebfe97c2aad0064` |
| _build_sandbox | `src/minisweagent/environments/singularity.py` | `chunk_2e7078da4140aa34` |
| update_preds_file | `src/minisweagent/run/benchmarks/swebench.py` | `chunk_526393903fbea091` |
| BubblewrapEnvironment | `src/minisweagent/environments/extra/bubblewrap.py` | `chunk_55c34f615652d67b` |
| remove_from_preds_file | `src/minisweagent/run/benchmarks/swebench.py` | `chunk_6c9ea38ac29364c6` |
| get_sb_environment | `src/minisweagent/run/benchmarks/swebench.py` | `chunk_93aef08a10f7394d` |
| process_instance | `src/minisweagent/run/benchmarks/swebench.py` | `chunk_a7e611c581e00e2b` |
| SwerexModalEnvironment | `src/minisweagent/environments/extra/swerex_modal.py` | `chunk_ad0c9ffd42523e10` |
| subcommands | `src/minisweagent/run/utilities/mini_extra.py` | `chunk_dc5d85d383e9297d` |

## 2. Verified code connections and remaining repository context

Connections are static source relationships; they do not prove runtime execution.

- `chunk_00c806f96a50f574` → `chunk_01c94c8c07ea442b`: file_import; symbol: not specified
- `chunk_01c94c8c07ea442b` → `chunk_57fb9f9187f07ab8`: imports_symbol; symbol: retry
- `chunk_01c94c8c07ea442b` → `chunk_57fb9f9187f07ab8`: file_import; symbol: not specified
- `chunk_01c94c8c07ea442b` → `chunk_87e1ac5a1fe5050f`: imports_symbol; symbol: _reorder_anthropic_thinking_blocks
- `chunk_01c94c8c07ea442b` → `chunk_87e1ac5a1fe5050f`: file_import; symbol: not specified
- `chunk_01c94c8c07ea442b` → `chunk_9bd9f3e0dfd43e6d`: imports_symbol; symbol: set_cache_control
- `chunk_01c94c8c07ea442b` → `chunk_9bd9f3e0dfd43e6d`: file_import; symbol: not specified
- `chunk_01c94c8c07ea442b` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: BASH_TOOL
- `chunk_01c94c8c07ea442b` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: format_toolcall_observation_messages
- `chunk_01c94c8c07ea442b` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: parse_toolcall_actions
- `chunk_01c94c8c07ea442b` → `chunk_bb150d3352e3d600`: file_import; symbol: not specified
- `chunk_01c94c8c07ea442b` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_01c94c8c07ea442b` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_01c94c8c07ea442b` → `chunk_d55ef449931ac735`: imports_symbol; symbol: expand_multimodal_content
- `chunk_01c94c8c07ea442b` → `chunk_d55ef449931ac735`: file_import; symbol: not specified
- `chunk_0787bb470f27ba38` → `chunk_63236af5541e60e3`: imports_symbol; symbol: recursive_merge
- `chunk_0787bb470f27ba38` → `chunk_63236af5541e60e3`: file_import; symbol: not specified
- `chunk_0787bb470f27ba38` → `chunk_7ad2df29f66efd06`: file_import; symbol: not specified
- `chunk_0787bb470f27ba38` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: Submitted
- `chunk_0787bb470f27ba38` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_09fb58407d618885` → `chunk_01db2a32b2377fbc`: imports_symbol; symbol: DeterministicModel
- `chunk_09fb58407d618885` → `chunk_13621e8326bd0593`: imports_symbol; symbol: make_output
- `chunk_09fb58407d618885` → `chunk_1ebfe97c2aad0064`: imports_symbol; symbol: main
- `chunk_09fb58407d618885` → `chunk_271c599703fad5d4`: imports_symbol; symbol: filter_instances
- `chunk_09fb58407d618885` → `chunk_526393903fbea091`: imports_symbol; symbol: update_preds_file
- `chunk_09fb58407d618885` → `chunk_6166fd9c0ac12e76`: file_import; symbol: not specified
- `chunk_09fb58407d618885` → `chunk_6c9ea38ac29364c6`: imports_symbol; symbol: remove_from_preds_file
- `chunk_09fb58407d618885` → `chunk_93aef08a10f7394d`: imports_symbol; symbol: get_sb_environment
- `chunk_09fb58407d618885` → `chunk_ef0158240404aa4b`: file_import; symbol: not specified
- `chunk_09fb58407d618885` → `chunk_fdd72eb5f1093ff1`: imports_symbol; symbol: get_swebench_docker_image_name
- `chunk_0a69e435cedc1bc5` → `chunk_13de85721b3faf55`: imports_symbol; symbol: get_content_string
- `chunk_0a69e435cedc1bc5` → `chunk_13de85721b3faf55`: file_import; symbol: not specified
- `chunk_0a69e435cedc1bc5` → `chunk_5a5887c60edc8843`: imports_symbol; symbol: DefaultAgent
- `chunk_0a69e435cedc1bc5` → `chunk_8f30f2a408c8f61c`: imports_symbol; symbol: AgentConfig
- `chunk_0a69e435cedc1bc5` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: LimitsExceeded
- `chunk_0a69e435cedc1bc5` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: Submitted
- `chunk_0a69e435cedc1bc5` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: TimeExceeded
- `chunk_0a69e435cedc1bc5` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: UserInterruption
- `chunk_0a69e435cedc1bc5` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_0a69e435cedc1bc5` → `chunk_f22c5058b892f148`: file_import; symbol: not specified
- `chunk_0a69e435cedc1bc5` → `chunk_f63f7effe4b12d78`: imports_symbol; symbol: _multiline_prompt
- `chunk_0a69e435cedc1bc5` → `chunk_f63f7effe4b12d78`: file_import; symbol: not specified
- `chunk_0cbfd19642d6545f` → `chunk_01c94c8c07ea442b`: file_import; symbol: not specified
- `chunk_0d7e72694d042a18` → `chunk_e1ed86a408aee5de`: file_import; symbol: not specified
- `chunk_0de2e4905907e818` → `chunk_01db2a32b2377fbc`: imports_symbol; symbol: DeterministicModel
- `chunk_0de2e4905907e818` → `chunk_13621e8326bd0593`: imports_symbol; symbol: make_output
- `chunk_0de2e4905907e818` → `chunk_6166fd9c0ac12e76`: file_import; symbol: not specified
- `chunk_0de2e4905907e818` → `chunk_799a6fe5b1904ba5`: imports_symbol; symbol: main
- `chunk_0de2e4905907e818` → `chunk_799a6fe5b1904ba5`: file_import; symbol: not specified
- `chunk_0de2e4905907e818` → `chunk_e85f1f276eb98a0c`: imports_symbol; symbol: assert_observations_match
- `chunk_0de2e4905907e818` → `chunk_e85f1f276eb98a0c`: file_import; symbol: not specified
- `chunk_0f7756391b750dc4` → `chunk_57fb9f9187f07ab8`: imports_symbol; symbol: retry
- `chunk_0f7756391b750dc4` → `chunk_57fb9f9187f07ab8`: file_import; symbol: not specified
- `chunk_0f7756391b750dc4` → `chunk_87e1ac5a1fe5050f`: imports_symbol; symbol: _reorder_anthropic_thinking_blocks
- `chunk_0f7756391b750dc4` → `chunk_87e1ac5a1fe5050f`: file_import; symbol: not specified
- `chunk_0f7756391b750dc4` → `chunk_9bd9f3e0dfd43e6d`: imports_symbol; symbol: set_cache_control
- `chunk_0f7756391b750dc4` → `chunk_9bd9f3e0dfd43e6d`: file_import; symbol: not specified
- `chunk_0f7756391b750dc4` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: BASH_TOOL
- `chunk_0f7756391b750dc4` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: format_toolcall_observation_messages
- `chunk_0f7756391b750dc4` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: parse_toolcall_actions
- `chunk_0f7756391b750dc4` → `chunk_bb150d3352e3d600`: file_import; symbol: not specified
- `chunk_0f7756391b750dc4` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_0f7756391b750dc4` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_0f7756391b750dc4` → `chunk_d55ef449931ac735`: imports_symbol; symbol: expand_multimodal_content
- `chunk_0f7756391b750dc4` → `chunk_d55ef449931ac735`: file_import; symbol: not specified
- `chunk_106443a2096b7282` → `chunk_6979a407975db252`: imports_symbol; symbol: _key_value_spec_to_nested_dict
- `chunk_106443a2096b7282` → `chunk_6979a407975db252`: imports_symbol; symbol: get_config_from_spec
- `chunk_106443a2096b7282` → `chunk_6979a407975db252`: imports_symbol; symbol: get_config_path
- `chunk_106443a2096b7282` → `chunk_cd1d73a686e478b7`: file_import; symbol: not specified
- `chunk_14741a57a30d6b30` → `chunk_c99464483c37187a`: imports_symbol; symbol: Agent
- `chunk_14741a57a30d6b30` → `chunk_c99464483c37187a`: imports_symbol; symbol: Environment
- `chunk_14741a57a30d6b30` → `chunk_c99464483c37187a`: imports_symbol; symbol: Model
- `chunk_1524a0dadbc8d637` → `chunk_14741a57a30d6b30`: imports_symbol; symbol: get_agent
- `chunk_1524a0dadbc8d637` → `chunk_4567d473a70901a9`: imports_symbol; symbol: get_model
- `chunk_1524a0dadbc8d637` → `chunk_63236af5541e60e3`: imports_symbol; symbol: recursive_merge
- `chunk_1524a0dadbc8d637` → `chunk_63236af5541e60e3`: file_import; symbol: not specified
- `chunk_1524a0dadbc8d637` → `chunk_6979a407975db252`: imports_symbol; symbol: get_config_from_spec
- `chunk_1524a0dadbc8d637` → `chunk_c8f7612f6f51f7d6`: imports_symbol; symbol: get_environment
- `chunk_1524a0dadbc8d637` → `chunk_cd1d73a686e478b7`: imports_symbol; symbol: configure_if_first_time
- `chunk_1524a0dadbc8d637` → `chunk_cd1d73a686e478b7`: file_import; symbol: not specified
- `chunk_1524a0dadbc8d637` → `chunk_f63f7effe4b12d78`: imports_symbol; symbol: _multiline_prompt
- `chunk_1524a0dadbc8d637` → `chunk_f63f7effe4b12d78`: file_import; symbol: not specified
- `chunk_16237ca067e9b5bb` → `chunk_6166fd9c0ac12e76`: file_import; symbol: not specified
- `chunk_1af21969c8050b35` → `chunk_6684fa0da4b43989`: imports_symbol; symbol: main
- `chunk_1af21969c8050b35` → `chunk_dfc7ee01ae80b4ef`: file_import; symbol: not specified
- `chunk_1af21969c8050b35` → `chunk_e02080e85f0eeb74`: imports_symbol; symbol: TrajectoryInspector
- `chunk_1c337c2d447fe5cc` → `chunk_01db2a32b2377fbc`: imports_symbol; symbol: DeterministicModel
- `chunk_1c337c2d447fe5cc` → `chunk_13621e8326bd0593`: imports_symbol; symbol: make_output
- `chunk_1c337c2d447fe5cc` → `chunk_543f6faaa93711bd`: imports_symbol; symbol: main
- `chunk_1c337c2d447fe5cc` → `chunk_543f6faaa93711bd`: file_import; symbol: not specified
- `chunk_1c337c2d447fe5cc` → `chunk_6166fd9c0ac12e76`: file_import; symbol: not specified
- `chunk_23f4f83027515d1a` → `chunk_5e5ea0bb98fba951`: imports_symbol; symbol: RunBatchProgressManager
- `chunk_23f4f83027515d1a` → `chunk_5e5ea0bb98fba951`: imports_symbol; symbol: _shorten_str
- `chunk_23f4f83027515d1a` → `chunk_5e5ea0bb98fba951`: file_import; symbol: not specified
- `chunk_24e7c50f0bfeb51c` → `chunk_8aa11d29c823da85`: file_import; symbol: not specified
- `chunk_27a7d76b92b4af2a` → `chunk_6166fd9c0ac12e76`: file_import; symbol: not specified
- `chunk_2932c33fe3b991aa` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: BASH_TOOL
- `chunk_2932c33fe3b991aa` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: format_toolcall_observation_messages
- `chunk_2932c33fe3b991aa` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: parse_toolcall_actions
- `chunk_2932c33fe3b991aa` → `chunk_bb150d3352e3d600`: file_import; symbol: not specified
- `chunk_2932c33fe3b991aa` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_2932c33fe3b991aa` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_2c2c67ae85e4da32` → `chunk_ae352e849425b0e3`: file_import; symbol: not specified
- `chunk_2e7078da4140aa34` → `chunk_63236af5541e60e3`: imports_symbol; symbol: recursive_merge
- `chunk_2e7078da4140aa34` → `chunk_63236af5541e60e3`: file_import; symbol: not specified
- `chunk_2e7078da4140aa34` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: Submitted
- `chunk_2e7078da4140aa34` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_37e52b15343ac915` → `chunk_c8f7612f6f51f7d6`: imports_symbol; symbol: get_environment_class
- `chunk_37e52b15343ac915` → `chunk_d0fd281bfdef33e4`: imports_symbol; symbol: LocalEnvironment
- `chunk_37e52b15343ac915` → `chunk_d0fd281bfdef33e4`: file_import; symbol: not specified
- `chunk_3b4deea29d570d48` → `chunk_01c94c8c07ea442b`: imports_symbol; symbol: OpenRouterAPIError
- `chunk_3b4deea29d570d48` → `chunk_01c94c8c07ea442b`: imports_symbol; symbol: OpenRouterAuthenticationError
- `chunk_3b4deea29d570d48` → `chunk_01c94c8c07ea442b`: imports_symbol; symbol: OpenRouterModel
- `chunk_3b4deea29d570d48` → `chunk_01c94c8c07ea442b`: imports_symbol; symbol: OpenRouterModelConfig
- `chunk_3b4deea29d570d48` → `chunk_01c94c8c07ea442b`: imports_symbol; symbol: OpenRouterRateLimitError
- `chunk_3b4deea29d570d48` → `chunk_01c94c8c07ea442b`: file_import; symbol: not specified
- `chunk_3b4deea29d570d48` → `chunk_5a7e2e83d68b5009`: imports_symbol; symbol: format_observation_messages
- `chunk_3b4deea29d570d48` → `chunk_5a7e2e83d68b5009`: imports_symbol; symbol: parse_regex_actions
- `chunk_3b4deea29d570d48` → `chunk_5a7e2e83d68b5009`: file_import; symbol: not specified
- `chunk_3e3cca98a1ee3f4e` → `chunk_57fb9f9187f07ab8`: imports_symbol; symbol: retry
- `chunk_3e3cca98a1ee3f4e` → `chunk_57fb9f9187f07ab8`: file_import; symbol: not specified
- `chunk_3e3cca98a1ee3f4e` → `chunk_87e1ac5a1fe5050f`: imports_symbol; symbol: _reorder_anthropic_thinking_blocks
- `chunk_3e3cca98a1ee3f4e` → `chunk_87e1ac5a1fe5050f`: file_import; symbol: not specified
- `chunk_3e3cca98a1ee3f4e` → `chunk_9bd9f3e0dfd43e6d`: imports_symbol; symbol: set_cache_control
- `chunk_3e3cca98a1ee3f4e` → `chunk_9bd9f3e0dfd43e6d`: file_import; symbol: not specified
- `chunk_3e3cca98a1ee3f4e` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: BASH_TOOL
- `chunk_3e3cca98a1ee3f4e` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: format_toolcall_observation_messages
- `chunk_3e3cca98a1ee3f4e` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: parse_toolcall_actions
- `chunk_3e3cca98a1ee3f4e` → `chunk_bb150d3352e3d600`: file_import; symbol: not specified
- `chunk_3e3cca98a1ee3f4e` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_3e3cca98a1ee3f4e` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_3e3cca98a1ee3f4e` → `chunk_d55ef449931ac735`: imports_symbol; symbol: expand_multimodal_content
- `chunk_3e3cca98a1ee3f4e` → `chunk_d55ef449931ac735`: file_import; symbol: not specified
- `chunk_4078a25944159e10` → `chunk_679fe8d47e7809da`: imports_symbol; symbol: PortkeyModelConfig
- `chunk_4078a25944159e10` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: BASH_TOOL
- `chunk_4078a25944159e10` → `chunk_bb150d3352e3d600`: file_import; symbol: not specified
- `chunk_4078a25944159e10` → `chunk_ccac1c9236e4861b`: imports_symbol; symbol: PortkeyModel
- `chunk_4078a25944159e10` → `chunk_e1ed86a408aee5de`: file_import; symbol: not specified
- `chunk_41659ee5dda7855f` → `chunk_4e96a3869941a924`: imports_symbol; symbol: copy_submission
- `chunk_41659ee5dda7855f` → `chunk_6eecf9b51c6fc4dc`: file_import; symbol: not specified
- `chunk_41659ee5dda7855f` → `chunk_7ad2df29f66efd06`: imports_symbol; symbol: DockerEnvironment
- `chunk_41659ee5dda7855f` → `chunk_7ad2df29f66efd06`: file_import; symbol: not specified
- `chunk_41659ee5dda7855f` → `chunk_7ad78cdc025694af`: imports_symbol; symbol: main
- `chunk_41659ee5dda7855f` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: Submitted
- `chunk_41659ee5dda7855f` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_4174b9552383e7f5` → `chunk_01db2a32b2377fbc`: imports_symbol; symbol: DeterministicModel
- `chunk_4174b9552383e7f5` → `chunk_6166fd9c0ac12e76`: file_import; symbol: not specified
- `chunk_419228e42f945198` → `chunk_0f7756391b750dc4`: file_import; symbol: not specified
- `chunk_4567d473a70901a9` → `chunk_0f7756391b750dc4`: file_import; symbol: not specified
- `chunk_4567d473a70901a9` → `chunk_c99464483c37187a`: imports_symbol; symbol: Model
- `chunk_49c02554e4ed43ce` → `chunk_eaff58997eb46d2a`: file_import; symbol: not specified
- `chunk_4f30c7195d928852` → `chunk_e1ed86a408aee5de`: file_import; symbol: not specified
- `chunk_51fc6a3401798e44` → `chunk_63236af5541e60e3`: imports_symbol; symbol: recursive_merge
- `chunk_51fc6a3401798e44` → `chunk_63236af5541e60e3`: file_import; symbol: not specified
- `chunk_543f6faaa93711bd` → `chunk_14741a57a30d6b30`: imports_symbol; symbol: get_agent
- `chunk_543f6faaa93711bd` → `chunk_4567d473a70901a9`: imports_symbol; symbol: get_model
- `chunk_543f6faaa93711bd` → `chunk_589988301dc5c796`: file_import; symbol: not specified
- `chunk_543f6faaa93711bd` → `chunk_63236af5541e60e3`: imports_symbol; symbol: recursive_merge
- `chunk_543f6faaa93711bd` → `chunk_63236af5541e60e3`: file_import; symbol: not specified
- `chunk_543f6faaa93711bd` → `chunk_6979a407975db252`: imports_symbol; symbol: get_config_from_spec
- `chunk_543f6faaa93711bd` → `chunk_93aef08a10f7394d`: imports_symbol; symbol: get_sb_environment
- `chunk_543f6faaa93711bd` → `chunk_cd1d73a686e478b7`: file_import; symbol: not specified
- `chunk_543f6faaa93711bd` → `chunk_ef0158240404aa4b`: imports_symbol; symbol: DATASET_MAPPING
- `chunk_543f6faaa93711bd` → `chunk_ef0158240404aa4b`: file_import; symbol: not specified
- `chunk_55c34f615652d67b` → `chunk_63236af5541e60e3`: imports_symbol; symbol: recursive_merge
- `chunk_55c34f615652d67b` → `chunk_63236af5541e60e3`: file_import; symbol: not specified
- `chunk_55c34f615652d67b` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: Submitted
- `chunk_55c34f615652d67b` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_5a3bbf61db5b5aeb` → `chunk_01db2a32b2377fbc`: imports_symbol; symbol: DeterministicModel
- `chunk_5a3bbf61db5b5aeb` → `chunk_13621e8326bd0593`: imports_symbol; symbol: make_output
- `chunk_5a3bbf61db5b5aeb` → `chunk_4567d473a70901a9`: imports_symbol; symbol: GlobalModelStats
- `chunk_5a3bbf61db5b5aeb` → `chunk_4567d473a70901a9`: imports_symbol; symbol: get_model
- `chunk_5a3bbf61db5b5aeb` → `chunk_4567d473a70901a9`: imports_symbol; symbol: get_model_class
- `chunk_5a3bbf61db5b5aeb` → `chunk_4567d473a70901a9`: imports_symbol; symbol: get_model_name
- `chunk_5a3bbf61db5b5aeb` → `chunk_6166fd9c0ac12e76`: file_import; symbol: not specified
- `chunk_5a7e2e83d68b5009` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_5a7e2e83d68b5009` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_5a7e2e83d68b5009` → `chunk_d55ef449931ac735`: imports_symbol; symbol: expand_multimodal_content
- `chunk_5a7e2e83d68b5009` → `chunk_d55ef449931ac735`: file_import; symbol: not specified
- `chunk_6166fd9c0ac12e76` → `chunk_5a7e2e83d68b5009`: imports_symbol; symbol: format_observation_messages
- `chunk_6166fd9c0ac12e76` → `chunk_5a7e2e83d68b5009`: file_import; symbol: not specified
- `chunk_6166fd9c0ac12e76` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: format_toolcall_observation_messages
- `chunk_6166fd9c0ac12e76` → `chunk_bb150d3352e3d600`: file_import; symbol: not specified
- `chunk_6166fd9c0ac12e76` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: format_toolcall_observation_messages
- `chunk_6166fd9c0ac12e76` → `chunk_bf7acfc3bc96fe67`: file_import; symbol: not specified
- `chunk_6166fd9c0ac12e76` → `chunk_d55ef449931ac735`: imports_symbol; symbol: expand_multimodal_content
- `chunk_6166fd9c0ac12e76` → `chunk_d55ef449931ac735`: file_import; symbol: not specified
- `chunk_64928fa6e4224fb8` → `chunk_1524a0dadbc8d637`: imports_symbol; symbol: main
- `chunk_64928fa6e4224fb8` → `chunk_1524a0dadbc8d637`: file_import; symbol: not specified
- `chunk_6621213052031421` → `chunk_57fb9f9187f07ab8`: imports_symbol; symbol: retry
- `chunk_6621213052031421` → `chunk_57fb9f9187f07ab8`: file_import; symbol: not specified
- `chunk_6621213052031421` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_6621213052031421` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_6621213052031421` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: BASH_TOOL_RESPONSE_API
- `chunk_6621213052031421` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: finish_reason_from_responses_api
- `chunk_6621213052031421` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: format_toolcall_observation_messages
- `chunk_6621213052031421` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: parse_toolcall_actions_response
- `chunk_6621213052031421` → `chunk_bf7acfc3bc96fe67`: file_import; symbol: not specified
- `chunk_6652e293d6bc1677` → `chunk_01db2a32b2377fbc`: imports_symbol; symbol: DeterministicModel
- `chunk_6652e293d6bc1677` → `chunk_041d822261feab60`: imports_symbol; symbol: make_toolcall_output
- `chunk_6652e293d6bc1677` → `chunk_0a69e435cedc1bc5`: file_import; symbol: not specified
- `chunk_6652e293d6bc1677` → `chunk_13621e8326bd0593`: imports_symbol; symbol: make_output
- `chunk_6652e293d6bc1677` → `chunk_422970b0496ca5ca`: imports_symbol; symbol: DeterministicResponseAPIToolcallModel
- `chunk_6652e293d6bc1677` → `chunk_6166fd9c0ac12e76`: file_import; symbol: not specified
- `chunk_6652e293d6bc1677` → `chunk_8a09104403c73a30`: imports_symbol; symbol: make_response_api_output
- `chunk_6652e293d6bc1677` → `chunk_d0fd281bfdef33e4`: imports_symbol; symbol: LocalEnvironment
- `chunk_6652e293d6bc1677` → `chunk_d0fd281bfdef33e4`: file_import; symbol: not specified
- `chunk_6652e293d6bc1677` → `chunk_e5c59a4f9a311533`: imports_symbol; symbol: InteractiveAgent
- `chunk_6652e293d6bc1677` → `chunk_e6c44452329fea0f`: imports_symbol; symbol: DeterministicToolcallModel
- `chunk_66761b4abd201242` → `chunk_0f7756391b750dc4`: imports_symbol; symbol: LitellmModel
- `chunk_66761b4abd201242` → `chunk_0f7756391b750dc4`: imports_symbol; symbol: LitellmModelConfig
- `chunk_66761b4abd201242` → `chunk_0f7756391b750dc4`: file_import; symbol: not specified
- `chunk_66761b4abd201242` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: BASH_TOOL
- `chunk_66761b4abd201242` → `chunk_bb150d3352e3d600`: file_import; symbol: not specified
- `chunk_66761b4abd201242` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_66761b4abd201242` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_6ba504351777222f` → `chunk_ae352e849425b0e3`: file_import; symbol: not specified
- `chunk_6e94c91bedc09044` → `chunk_6621213052031421`: imports_symbol; symbol: PortkeyResponseAPIModel
- `chunk_6e94c91bedc09044` → `chunk_6621213052031421`: file_import; symbol: not specified
- `chunk_6e94c91bedc09044` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: BASH_TOOL_RESPONSE_API
- `chunk_6e94c91bedc09044` → `chunk_bf7acfc3bc96fe67`: file_import; symbol: not specified
- `chunk_6eecf9b51c6fc4dc` → `chunk_4567d473a70901a9`: imports_symbol; symbol: get_model
- `chunk_6eecf9b51c6fc4dc` → `chunk_589988301dc5c796`: imports_symbol; symbol: add_file_handler
- `chunk_6eecf9b51c6fc4dc` → `chunk_589988301dc5c796`: file_import; symbol: not specified
- `chunk_6eecf9b51c6fc4dc` → `chunk_5e5ea0bb98fba951`: imports_symbol; symbol: RunBatchProgressManager
- `chunk_6eecf9b51c6fc4dc` → `chunk_5e5ea0bb98fba951`: file_import; symbol: not specified
- `chunk_6eecf9b51c6fc4dc` → `chunk_63236af5541e60e3`: imports_symbol; symbol: recursive_merge
- `chunk_6eecf9b51c6fc4dc` → `chunk_63236af5541e60e3`: file_import; symbol: not specified
- `chunk_6eecf9b51c6fc4dc` → `chunk_6979a407975db252`: imports_symbol; symbol: get_config_from_spec
- `chunk_6eecf9b51c6fc4dc` → `chunk_c8f7612f6f51f7d6`: imports_symbol; symbol: get_environment
- `chunk_6eecf9b51c6fc4dc` → `chunk_cd1d73a686e478b7`: file_import; symbol: not specified
- `chunk_6eecf9b51c6fc4dc` → `chunk_fe748a0fdd7f4423`: imports_symbol; symbol: ProgressTrackingAgent
- `chunk_6eecf9b51c6fc4dc` → `chunk_fe748a0fdd7f4423`: file_import; symbol: not specified
- `chunk_740c85e6823cfe8d` → `chunk_4567d473a70901a9`: imports_symbol; symbol: get_model
- `chunk_78794a1a97a00dd5` → `chunk_63236af5541e60e3`: imports_symbol; symbol: recursive_merge
- `chunk_78794a1a97a00dd5` → `chunk_63236af5541e60e3`: file_import; symbol: not specified
- `chunk_78794a1a97a00dd5` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: Submitted
- `chunk_78794a1a97a00dd5` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_78794a1a97a00dd5` → `chunk_c99464483c37187a`: imports_symbol; symbol: Environment
- `chunk_78794a1a97a00dd5` → `chunk_cd1d73a686e478b7`: file_import; symbol: not specified
- `chunk_7989793fded05faf` → `chunk_0f7756391b750dc4`: file_import; symbol: not specified
- `chunk_7989793fded05faf` → `chunk_ae352e849425b0e3`: file_import; symbol: not specified
- `chunk_799a6fe5b1904ba5` → `chunk_0f7756391b750dc4`: imports_symbol; symbol: LitellmModel
- `chunk_799a6fe5b1904ba5` → `chunk_0f7756391b750dc4`: file_import; symbol: not specified
- `chunk_799a6fe5b1904ba5` → `chunk_5a5887c60edc8843`: imports_symbol; symbol: DefaultAgent
- `chunk_799a6fe5b1904ba5` → `chunk_d0fd281bfdef33e4`: imports_symbol; symbol: LocalEnvironment
- `chunk_799a6fe5b1904ba5` → `chunk_d0fd281bfdef33e4`: file_import; symbol: not specified
- `chunk_799a6fe5b1904ba5` → `chunk_f22c5058b892f148`: file_import; symbol: not specified
- `chunk_7ad2df29f66efd06` → `chunk_63236af5541e60e3`: imports_symbol; symbol: recursive_merge
- `chunk_7ad2df29f66efd06` → `chunk_63236af5541e60e3`: file_import; symbol: not specified
- `chunk_7ad2df29f66efd06` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: Submitted
- `chunk_7ad2df29f66efd06` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_80e870e27146fd2f` → `chunk_78794a1a97a00dd5`: imports_symbol; symbol: ContreeEnvironment
- `chunk_80e870e27146fd2f` → `chunk_78794a1a97a00dd5`: file_import; symbol: not specified
- `chunk_80e870e27146fd2f` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: Submitted
- `chunk_80e870e27146fd2f` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_80e870e27146fd2f` → `chunk_cd1d73a686e478b7`: file_import; symbol: not specified
- `chunk_8623be867d9af729` → `chunk_00fc09eee6751c65`: imports_symbol; symbol: DeterministicResponseAPIToolcallModelConfig
- `chunk_8623be867d9af729` → `chunk_01db2a32b2377fbc`: imports_symbol; symbol: DeterministicModel
- `chunk_8623be867d9af729` → `chunk_041d822261feab60`: imports_symbol; symbol: make_toolcall_output
- `chunk_8623be867d9af729` → `chunk_13621e8326bd0593`: imports_symbol; symbol: make_output
- `chunk_8623be867d9af729` → `chunk_422970b0496ca5ca`: imports_symbol; symbol: DeterministicResponseAPIToolcallModel
- `chunk_8623be867d9af729` → `chunk_6166fd9c0ac12e76`: file_import; symbol: not specified
- `chunk_8623be867d9af729` → `chunk_8a09104403c73a30`: imports_symbol; symbol: make_response_api_output
- `chunk_8623be867d9af729` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_8623be867d9af729` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_8623be867d9af729` → `chunk_c04c1f2e2843e3d0`: imports_symbol; symbol: DeterministicModelConfig
- `chunk_8623be867d9af729` → `chunk_d483a754fc3c7884`: imports_symbol; symbol: DeterministicToolcallModelConfig
- `chunk_8623be867d9af729` → `chunk_e6c44452329fea0f`: imports_symbol; symbol: DeterministicToolcallModel
- `chunk_8aa11d29c823da85` → `chunk_0f7756391b750dc4`: imports_symbol; symbol: LitellmModel
- `chunk_8aa11d29c823da85` → `chunk_0f7756391b750dc4`: imports_symbol; symbol: LitellmModelConfig
- `chunk_8aa11d29c823da85` → `chunk_0f7756391b750dc4`: file_import; symbol: not specified
- `chunk_8aa11d29c823da85` → `chunk_5a7e2e83d68b5009`: imports_symbol; symbol: format_observation_messages
- `chunk_8aa11d29c823da85` → `chunk_5a7e2e83d68b5009`: imports_symbol; symbol: parse_regex_actions
- `chunk_8aa11d29c823da85` → `chunk_5a7e2e83d68b5009`: file_import; symbol: not specified
- `chunk_905b71410cb2c811` → `chunk_0f7756391b750dc4`: file_import; symbol: not specified
- `chunk_92bec68a5abda8eb` → `chunk_87e1ac5a1fe5050f`: imports_symbol; symbol: _reorder_anthropic_thinking_blocks
- `chunk_92bec68a5abda8eb` → `chunk_87e1ac5a1fe5050f`: file_import; symbol: not specified
- `chunk_940ceb077d15730e` → `chunk_55c34f615652d67b`: imports_symbol; symbol: BubblewrapEnvironment
- `chunk_940ceb077d15730e` → `chunk_55c34f615652d67b`: imports_symbol; symbol: BubblewrapEnvironmentConfig
- `chunk_940ceb077d15730e` → `chunk_55c34f615652d67b`: file_import; symbol: not specified
- `chunk_993dd1249b129a8c` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_999caf9a5c6f2630` → `chunk_13de85721b3faf55`: imports_symbol; symbol: get_content_string
- `chunk_999caf9a5c6f2630` → `chunk_13de85721b3faf55`: file_import; symbol: not specified
- `chunk_99d9aff88846b2c8` → `chunk_0787bb470f27ba38`: imports_symbol; symbol: SwerexDockerEnvironment
- `chunk_99d9aff88846b2c8` → `chunk_0787bb470f27ba38`: file_import; symbol: not specified
- `chunk_a088f3e54d612b7b` → `chunk_d55ef449931ac735`: imports_symbol; symbol: DEFAULT_MULTIMODAL_REGEX
- `chunk_a088f3e54d612b7b` → `chunk_d55ef449931ac735`: imports_symbol; symbol: _expand_content_string
- `chunk_a088f3e54d612b7b` → `chunk_d55ef449931ac735`: imports_symbol; symbol: expand_multimodal_content
- `chunk_a088f3e54d612b7b` → `chunk_d55ef449931ac735`: file_import; symbol: not specified
- `chunk_a34cd843d9488a79` → `chunk_9bd9f3e0dfd43e6d`: imports_symbol; symbol: set_cache_control
- `chunk_a34cd843d9488a79` → `chunk_9bd9f3e0dfd43e6d`: file_import; symbol: not specified
- `chunk_a3cfc322b7c11184` → `chunk_5a7e2e83d68b5009`: imports_symbol; symbol: parse_regex_actions
- `chunk_a3cfc322b7c11184` → `chunk_5a7e2e83d68b5009`: file_import; symbol: not specified
- `chunk_a3cfc322b7c11184` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: parse_toolcall_actions
- `chunk_a3cfc322b7c11184` → `chunk_bb150d3352e3d600`: file_import; symbol: not specified
- `chunk_a3cfc322b7c11184` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_a3cfc322b7c11184` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_a3cfc322b7c11184` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: finish_reason_from_responses_api
- `chunk_a3cfc322b7c11184` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: parse_toolcall_actions_response
- `chunk_a3cfc322b7c11184` → `chunk_bf7acfc3bc96fe67`: file_import; symbol: not specified
- `chunk_a6b06e4719f28d60` → `chunk_01c94c8c07ea442b`: imports_symbol; symbol: OpenRouterAuthenticationError
- `chunk_a6b06e4719f28d60` → `chunk_01c94c8c07ea442b`: file_import; symbol: not specified
- `chunk_a6b06e4719f28d60` → `chunk_3b4deea29d570d48`: imports_symbol; symbol: OpenRouterTextbasedModel
- `chunk_a6b06e4719f28d60` → `chunk_3b4deea29d570d48`: file_import; symbol: not specified
- `chunk_a708e0b47736f387` → `chunk_3b4deea29d570d48`: file_import; symbol: not specified
- `chunk_ac4d8b565e5fd8b9` → `chunk_4567d473a70901a9`: imports_symbol; symbol: get_model
- `chunk_ac4d8b565e5fd8b9` → `chunk_c99464483c37187a`: imports_symbol; symbol: Model
- `chunk_ad0c9ffd42523e10` → `chunk_63236af5541e60e3`: imports_symbol; symbol: recursive_merge
- `chunk_ad0c9ffd42523e10` → `chunk_63236af5541e60e3`: file_import; symbol: not specified
- `chunk_ad0c9ffd42523e10` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: Submitted
- `chunk_ad0c9ffd42523e10` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_ae352e849425b0e3` → `chunk_0f7756391b750dc4`: imports_symbol; symbol: LitellmModel
- `chunk_ae352e849425b0e3` → `chunk_0f7756391b750dc4`: imports_symbol; symbol: LitellmModelConfig
- `chunk_ae352e849425b0e3` → `chunk_0f7756391b750dc4`: file_import; symbol: not specified
- `chunk_ae352e849425b0e3` → `chunk_57fb9f9187f07ab8`: imports_symbol; symbol: retry
- `chunk_ae352e849425b0e3` → `chunk_57fb9f9187f07ab8`: file_import; symbol: not specified
- `chunk_ae352e849425b0e3` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_ae352e849425b0e3` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_ae352e849425b0e3` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: BASH_TOOL_RESPONSE_API
- `chunk_ae352e849425b0e3` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: finish_reason_from_responses_api
- `chunk_ae352e849425b0e3` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: format_toolcall_observation_messages
- `chunk_ae352e849425b0e3` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: parse_toolcall_actions_response
- `chunk_ae352e849425b0e3` → `chunk_bf7acfc3bc96fe67`: file_import; symbol: not specified
- `chunk_ae81727a01b5d55f` → `chunk_ad0c9ffd42523e10`: imports_symbol; symbol: SwerexModalEnvironment
- `chunk_ae81727a01b5d55f` → `chunk_ad0c9ffd42523e10`: imports_symbol; symbol: SwerexModalEnvironmentConfig
- `chunk_ae81727a01b5d55f` → `chunk_ad0c9ffd42523e10`: file_import; symbol: not specified
- `chunk_ae81727a01b5d55f` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: Submitted
- `chunk_ae81727a01b5d55f` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_af4ecfeda1b4e8d9` → `chunk_01db2a32b2377fbc`: imports_symbol; symbol: DeterministicModel
- `chunk_af4ecfeda1b4e8d9` → `chunk_13621e8326bd0593`: imports_symbol; symbol: make_output
- `chunk_af4ecfeda1b4e8d9` → `chunk_1524a0dadbc8d637`: imports_symbol; symbol: main
- `chunk_af4ecfeda1b4e8d9` → `chunk_1524a0dadbc8d637`: file_import; symbol: not specified
- `chunk_af4ecfeda1b4e8d9` → `chunk_6166fd9c0ac12e76`: file_import; symbol: not specified
- `chunk_af4ecfeda1b4e8d9` → `chunk_e85f1f276eb98a0c`: imports_symbol; symbol: assert_observations_match
- `chunk_af4ecfeda1b4e8d9` → `chunk_e85f1f276eb98a0c`: file_import; symbol: not specified
- `chunk_b056e34e1e8ee84a` → `chunk_2e7078da4140aa34`: imports_symbol; symbol: SingularityEnvironment
- `chunk_b056e34e1e8ee84a` → `chunk_2e7078da4140aa34`: imports_symbol; symbol: SingularityEnvironmentConfig
- `chunk_b056e34e1e8ee84a` → `chunk_2e7078da4140aa34`: file_import; symbol: not specified
- `chunk_b23fe33efbdb04e9` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_b23fe33efbdb04e9` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_b5b91af81653d133` → `chunk_d0fd281bfdef33e4`: imports_symbol; symbol: LocalEnvironment
- `chunk_b5b91af81653d133` → `chunk_d0fd281bfdef33e4`: imports_symbol; symbol: LocalEnvironmentConfig
- `chunk_b5b91af81653d133` → `chunk_d0fd281bfdef33e4`: file_import; symbol: not specified
- `chunk_b8968245573ae673` → `chunk_ae352e849425b0e3`: file_import; symbol: not specified
- `chunk_bb150d3352e3d600` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_bb150d3352e3d600` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_bb150d3352e3d600` → `chunk_d55ef449931ac735`: imports_symbol; symbol: expand_multimodal_content
- `chunk_bb150d3352e3d600` → `chunk_d55ef449931ac735`: file_import; symbol: not specified
- `chunk_bdb04ba2525b387b` → `chunk_0f7756391b750dc4`: file_import; symbol: not specified
- `chunk_be31683c4ea827b8` → `chunk_01db2a32b2377fbc`: imports_symbol; symbol: DeterministicModel
- `chunk_be31683c4ea827b8` → `chunk_041d822261feab60`: imports_symbol; symbol: make_toolcall_output
- `chunk_be31683c4ea827b8` → `chunk_13621e8326bd0593`: imports_symbol; symbol: make_output
- `chunk_be31683c4ea827b8` → `chunk_422970b0496ca5ca`: imports_symbol; symbol: DeterministicResponseAPIToolcallModel
- `chunk_be31683c4ea827b8` → `chunk_5a5887c60edc8843`: imports_symbol; symbol: DefaultAgent
- `chunk_be31683c4ea827b8` → `chunk_6166fd9c0ac12e76`: file_import; symbol: not specified
- `chunk_be31683c4ea827b8` → `chunk_8a09104403c73a30`: imports_symbol; symbol: make_response_api_output
- `chunk_be31683c4ea827b8` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_be31683c4ea827b8` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_be31683c4ea827b8` → `chunk_d0fd281bfdef33e4`: imports_symbol; symbol: LocalEnvironment
- `chunk_be31683c4ea827b8` → `chunk_d0fd281bfdef33e4`: file_import; symbol: not specified
- `chunk_be31683c4ea827b8` → `chunk_e6c44452329fea0f`: imports_symbol; symbol: DeterministicToolcallModel
- `chunk_be31683c4ea827b8` → `chunk_f22c5058b892f148`: file_import; symbol: not specified
- `chunk_bf7acfc3bc96fe67` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_bf7acfc3bc96fe67` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_c2d7833ef09d4f64` → `chunk_8aa11d29c823da85`: imports_symbol; symbol: LitellmTextbasedModel
- `chunk_c2d7833ef09d4f64` → `chunk_8aa11d29c823da85`: file_import; symbol: not specified
- `chunk_c8f7612f6f51f7d6` → `chunk_c99464483c37187a`: imports_symbol; symbol: Environment
- `chunk_c99464483c37187a` → `chunk_589988301dc5c796`: file_import; symbol: not specified
- `chunk_cab89355a4f15d29` → `chunk_3e3cca98a1ee3f4e`: file_import; symbol: not specified
- `chunk_cd6d10fa8a2ed51b` → `chunk_1524a0dadbc8d637`: file_import; symbol: not specified
- `chunk_cf4c14030a6be5b0` → `chunk_7ad2df29f66efd06`: imports_symbol; symbol: DockerEnvironment
- `chunk_cf4c14030a6be5b0` → `chunk_7ad2df29f66efd06`: imports_symbol; symbol: DockerEnvironmentConfig
- `chunk_cf4c14030a6be5b0` → `chunk_7ad2df29f66efd06`: file_import; symbol: not specified
- `chunk_d0fd281bfdef33e4` → `chunk_63236af5541e60e3`: imports_symbol; symbol: recursive_merge
- `chunk_d0fd281bfdef33e4` → `chunk_63236af5541e60e3`: file_import; symbol: not specified
- `chunk_d0fd281bfdef33e4` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: Submitted
- `chunk_d0fd281bfdef33e4` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_de13ba6224a4f262` → `chunk_01db2a32b2377fbc`: imports_symbol; symbol: DeterministicModel
- `chunk_de13ba6224a4f262` → `chunk_13621e8326bd0593`: imports_symbol; symbol: make_output
- `chunk_de13ba6224a4f262` → `chunk_5a5887c60edc8843`: imports_symbol; symbol: DefaultAgent
- `chunk_de13ba6224a4f262` → `chunk_6166fd9c0ac12e76`: file_import; symbol: not specified
- `chunk_de13ba6224a4f262` → `chunk_d0fd281bfdef33e4`: imports_symbol; symbol: LocalEnvironment
- `chunk_de13ba6224a4f262` → `chunk_d0fd281bfdef33e4`: file_import; symbol: not specified
- `chunk_de13ba6224a4f262` → `chunk_f22c5058b892f148`: file_import; symbol: not specified
- `chunk_dfc7ee01ae80b4ef` → `chunk_13de85721b3faf55`: imports_symbol; symbol: get_content_string
- `chunk_dfc7ee01ae80b4ef` → `chunk_13de85721b3faf55`: file_import; symbol: not specified
- `chunk_e03b603aa0247d63` → `chunk_6621213052031421`: file_import; symbol: not specified
- `chunk_e120db9f97fbf10e` → `chunk_01db2a32b2377fbc`: imports_symbol; symbol: DeterministicModel
- `chunk_e120db9f97fbf10e` → `chunk_0a69e435cedc1bc5`: file_import; symbol: not specified
- `chunk_e120db9f97fbf10e` → `chunk_14741a57a30d6b30`: imports_symbol; symbol: get_agent
- `chunk_e120db9f97fbf10e` → `chunk_14741a57a30d6b30`: imports_symbol; symbol: get_agent_class
- `chunk_e120db9f97fbf10e` → `chunk_5a5887c60edc8843`: imports_symbol; symbol: DefaultAgent
- `chunk_e120db9f97fbf10e` → `chunk_6166fd9c0ac12e76`: file_import; symbol: not specified
- `chunk_e120db9f97fbf10e` → `chunk_d0fd281bfdef33e4`: imports_symbol; symbol: LocalEnvironment
- `chunk_e120db9f97fbf10e` → `chunk_d0fd281bfdef33e4`: file_import; symbol: not specified
- `chunk_e120db9f97fbf10e` → `chunk_e5c59a4f9a311533`: imports_symbol; symbol: InteractiveAgent
- `chunk_e120db9f97fbf10e` → `chunk_f22c5058b892f148`: file_import; symbol: not specified
- `chunk_e1ed86a408aee5de` → `chunk_57fb9f9187f07ab8`: imports_symbol; symbol: retry
- `chunk_e1ed86a408aee5de` → `chunk_57fb9f9187f07ab8`: file_import; symbol: not specified
- `chunk_e1ed86a408aee5de` → `chunk_87e1ac5a1fe5050f`: imports_symbol; symbol: _reorder_anthropic_thinking_blocks
- `chunk_e1ed86a408aee5de` → `chunk_87e1ac5a1fe5050f`: file_import; symbol: not specified
- `chunk_e1ed86a408aee5de` → `chunk_9bd9f3e0dfd43e6d`: imports_symbol; symbol: set_cache_control
- `chunk_e1ed86a408aee5de` → `chunk_9bd9f3e0dfd43e6d`: file_import; symbol: not specified
- `chunk_e1ed86a408aee5de` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: BASH_TOOL
- `chunk_e1ed86a408aee5de` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: format_toolcall_observation_messages
- `chunk_e1ed86a408aee5de` → `chunk_bb150d3352e3d600`: imports_symbol; symbol: parse_toolcall_actions
- `chunk_e1ed86a408aee5de` → `chunk_bb150d3352e3d600`: file_import; symbol: not specified
- `chunk_e1ed86a408aee5de` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_e1ed86a408aee5de` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_e1ed86a408aee5de` → `chunk_d55ef449931ac735`: imports_symbol; symbol: expand_multimodal_content
- `chunk_e1ed86a408aee5de` → `chunk_d55ef449931ac735`: file_import; symbol: not specified
- `chunk_e21248c4ea6f3a22` → `chunk_cd1d73a686e478b7`: imports_symbol; symbol: configure_if_first_time
- `chunk_e21248c4ea6f3a22` → `chunk_cd1d73a686e478b7`: imports_symbol; symbol: edit
- `chunk_e21248c4ea6f3a22` → `chunk_cd1d73a686e478b7`: imports_symbol; symbol: set
- `chunk_e21248c4ea6f3a22` → `chunk_cd1d73a686e478b7`: imports_symbol; symbol: setup
- `chunk_e21248c4ea6f3a22` → `chunk_cd1d73a686e478b7`: imports_symbol; symbol: unset
- `chunk_e21248c4ea6f3a22` → `chunk_cd1d73a686e478b7`: file_import; symbol: not specified
- `chunk_e2cb96d353d48ed2` → `chunk_8f30f2a408c8f61c`: imports_symbol; symbol: AgentConfig
- `chunk_e2cb96d353d48ed2` → `chunk_f22c5058b892f148`: file_import; symbol: not specified
- `chunk_e30c483dc7038f6a` → `chunk_6621213052031421`: file_import; symbol: not specified
- `chunk_eaff58997eb46d2a` → `chunk_01c94c8c07ea442b`: imports_symbol; symbol: OpenRouterAPIError
- `chunk_eaff58997eb46d2a` → `chunk_01c94c8c07ea442b`: imports_symbol; symbol: OpenRouterAuthenticationError
- `chunk_eaff58997eb46d2a` → `chunk_01c94c8c07ea442b`: imports_symbol; symbol: OpenRouterModel
- `chunk_eaff58997eb46d2a` → `chunk_01c94c8c07ea442b`: imports_symbol; symbol: OpenRouterModelConfig
- `chunk_eaff58997eb46d2a` → `chunk_01c94c8c07ea442b`: imports_symbol; symbol: OpenRouterRateLimitError
- `chunk_eaff58997eb46d2a` → `chunk_01c94c8c07ea442b`: file_import; symbol: not specified
- `chunk_eaff58997eb46d2a` → `chunk_57fb9f9187f07ab8`: imports_symbol; symbol: retry
- `chunk_eaff58997eb46d2a` → `chunk_57fb9f9187f07ab8`: file_import; symbol: not specified
- `chunk_eaff58997eb46d2a` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_eaff58997eb46d2a` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_eaff58997eb46d2a` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: BASH_TOOL_RESPONSE_API
- `chunk_eaff58997eb46d2a` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: finish_reason_from_responses_api
- `chunk_eaff58997eb46d2a` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: format_toolcall_observation_messages
- `chunk_eaff58997eb46d2a` → `chunk_bf7acfc3bc96fe67`: imports_symbol; symbol: parse_toolcall_actions_response
- `chunk_eaff58997eb46d2a` → `chunk_bf7acfc3bc96fe67`: file_import; symbol: not specified
- `chunk_ef0158240404aa4b` → `chunk_4567d473a70901a9`: imports_symbol; symbol: get_model
- `chunk_ef0158240404aa4b` → `chunk_589988301dc5c796`: imports_symbol; symbol: add_file_handler
- `chunk_ef0158240404aa4b` → `chunk_589988301dc5c796`: file_import; symbol: not specified
- `chunk_ef0158240404aa4b` → `chunk_5e5ea0bb98fba951`: imports_symbol; symbol: RunBatchProgressManager
- `chunk_ef0158240404aa4b` → `chunk_5e5ea0bb98fba951`: file_import; symbol: not specified
- `chunk_ef0158240404aa4b` → `chunk_63236af5541e60e3`: imports_symbol; symbol: recursive_merge
- `chunk_ef0158240404aa4b` → `chunk_63236af5541e60e3`: file_import; symbol: not specified
- `chunk_ef0158240404aa4b` → `chunk_6979a407975db252`: imports_symbol; symbol: get_config_from_spec
- `chunk_ef0158240404aa4b` → `chunk_c8f7612f6f51f7d6`: imports_symbol; symbol: get_environment
- `chunk_ef0158240404aa4b` → `chunk_c99464483c37187a`: imports_symbol; symbol: Environment
- `chunk_ef0158240404aa4b` → `chunk_cd1d73a686e478b7`: file_import; symbol: not specified
- `chunk_ef0158240404aa4b` → `chunk_fe748a0fdd7f4423`: imports_symbol; symbol: ProgressTrackingAgent
- `chunk_ef0158240404aa4b` → `chunk_fe748a0fdd7f4423`: file_import; symbol: not specified
- `chunk_f22c5058b892f148` → `chunk_63236af5541e60e3`: imports_symbol; symbol: recursive_merge
- `chunk_f22c5058b892f148` → `chunk_63236af5541e60e3`: file_import; symbol: not specified
- `chunk_f22c5058b892f148` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: FormatError
- `chunk_f22c5058b892f148` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: InterruptAgentFlow
- `chunk_f22c5058b892f148` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: LimitsExceeded
- `chunk_f22c5058b892f148` → `chunk_beeff3307d88c18a`: imports_symbol; symbol: TimeExceeded
- `chunk_f22c5058b892f148` → `chunk_beeff3307d88c18a`: file_import; symbol: not specified
- `chunk_f22c5058b892f148` → `chunk_c99464483c37187a`: imports_symbol; symbol: Environment
- `chunk_f22c5058b892f148` → `chunk_c99464483c37187a`: imports_symbol; symbol: Model
- `chunk_f4094160a3674c29` → `chunk_01db2a32b2377fbc`: imports_symbol; symbol: DeterministicModel
- `chunk_f4094160a3674c29` → `chunk_1524a0dadbc8d637`: imports_symbol; symbol: main
- `chunk_f4094160a3674c29` → `chunk_1524a0dadbc8d637`: file_import; symbol: not specified
- `chunk_f4094160a3674c29` → `chunk_6166fd9c0ac12e76`: file_import; symbol: not specified
- `chunk_fe748a0fdd7f4423` → `chunk_5a5887c60edc8843`: imports_symbol; symbol: DefaultAgent
- `chunk_fe748a0fdd7f4423` → `chunk_5e5ea0bb98fba951`: imports_symbol; symbol: RunBatchProgressManager
- `chunk_fe748a0fdd7f4423` → `chunk_5e5ea0bb98fba951`: file_import; symbol: not specified
- `chunk_fe748a0fdd7f4423` → `chunk_f22c5058b892f148`: file_import; symbol: not specified

Other source sections remain available in `chunks.jsonl`; code is stored only once.

## 3. Business risks

Analysis status: **COMPLETED**

No reportable risk findings. This does not mean the repository is risk-free.
