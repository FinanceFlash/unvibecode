# smolagents-main — Context for AI

30 workflows · 1 risk findings · 537 verified connections · 560 code sections

Attach this file and `chunks.jsonl` together. Every code reference below identifies a source section in `chunks.jsonl`.

## 1. Business workflows

### 1. Agent run memory, replay, and message reconstruction

Workflow ID: `business_path_790217de04fcbbb8`

Agent task/action/planning history is stored in AgentMemory, converted back into messages, replayed to logs, and can yield concatenated code actions.

**Purpose:** Persist and inspect an agent's step-by-step work product

**Business outcome**

- Enables debugging and auditability of agent runs
- Preserves task, planning, tool-call, and final-answer context for later inspection
- Supports reconstruction of executable code from prior actions

**Important behavior and rules**

- MemoryStep.to_messages is abstract and must be implemented by concrete step types.
- AgentMemory.replay logs the system prompt first, then iterates over stored steps and renders step-specific content.
- ActionStep.to_messages includes tool-call and observation/error messages when present.

**Identified functions:** `AgentMemory.replay`, `ActionStep.to_messages`, `TaskStep.to_messages`, `AgentMemory.__init__`, `PlanningStep.to_messages`, `AgentMemory.return_full_code`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `tests/test_memory.py` | `chunk_2492744194c34fa5` |
| PlanningStep.to_messages | `src/smolagents/memory.py` | `chunk_3de1572485e2fce0` |
| ActionStep | `src/smolagents/memory.py` | `chunk_45f6250361c1ce52` |
| Source section | `tests/test_memory.py` | `chunk_508949eafcf705bb` |
| MemoryStep | `src/smolagents/memory.py` | `chunk_51084f1f1523258d` |
| Source section | `tests/test_memory.py` | `chunk_6cee8f1ecf72f271` |
| AgentMemory | `src/smolagents/memory.py` | `chunk_85488c685b6c6896` |
| Source section | `tests/test_memory.py` | `chunk_9666f8f5724bbc50` |
| Source section | `tests/test_memory.py` | `chunk_fa8eaea80492245d` |

### 2. Chat UI rendering for agent step logs

Workflow ID: `business_path_a64e1675fe62c580`

Agent step logs are converted into Gradio chat messages, including formatted tool calls, execution logs, images, and footnotes.

**Purpose:** Present agent reasoning, tool usage, observations, and errors in a conversational interface

**Business outcome**

- Provides a readable live transcript of agent execution
- Surfaces tool call arguments, logs, images, and errors in the UI
- Preserves step metadata such as duration and token counts for display

**Important behavior and rules**

- If a step has tool calls, the first call determines whether code formatting is applied and how the parent message is labeled.
- Execution logs are stripped of a leading 'Execution logs:' prefix before display.
- Observed images are converted through AgentImage.to_string before being shown as image messages.

**Identified functions:** `_process_action_step`, `_format_code_content`, `_clean_model_output`, `get_step_footnote_content`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| get_step_footnote_content | `src/smolagents/gradio_ui.py` | `chunk_28c1755c0a912a5f` |
| file_context | `src/smolagents/gradio_ui.py` | `chunk_53b3aa2807c8155d` |
| _clean_model_output | `src/smolagents/gradio_ui.py` | `chunk_6542250bc72bcba3` |
| _format_code_content | `src/smolagents/gradio_ui.py` | `chunk_a416fabd3ec7c043` |
| _process_action_step | `src/smolagents/gradio_ui.py` | `chunk_d60ec934f45724ef` |
| file_context | `tests/test_gradio_ui.py` | `chunk_e08b69c3a756297f` |

### 3. Normalize multimodal agent inputs and outputs

Workflow ID: `business_path_c46d37bd14535f77`

AgentImage and AgentAudio normalize text, image, and audio outputs into raw objects or serialized file paths, enabling display and transport across agent tools and notebooks.

**Purpose:** Convert agent outputs into portable artifacts and recover raw objects from serialized forms

**Business outcome**

- Allows images and audio to be passed through agent workflows
- Creates temporary file artifacts for notebook/UI consumption
- Handles remote audio URLs by downloading and decoding content

**Important behavior and rules**

- AgentImage preserves an existing path when one is already supplied, otherwise serializes raw/tensor content into a temporary PNG path.
- AgentAudio can read remote URLs via requests.get and local files via soundfile.read.
- AgentAudio requires the soundfile and torch packages before use.
- AgentImage raises TypeError when the input value is not a supported image/tensor/path form.

**Identified functions:** `AgentImage.to_string`, `AgentImage.__init__`, `handle_agent_input_types`, `handle_agent_output_types`, `AgentImage.to_raw`, `AgentAudio.to_raw`, `AgentAudio.__init__`, `AgentAudio.to_string`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `src/smolagents/agent_types.py` | `chunk_3580777ec4448745` |
| AgentAudioTests | `tests/test_types.py` | `chunk_532b4422a106b452` |
| file_context | `src/smolagents/tools.py` | `chunk_6e4e1079370eff5b` |
| Source section | `src/smolagents/agent_types.py` | `chunk_8a9cc8e314eb2552` |
| Source section | `src/smolagents/agent_types.py` | `chunk_8bf17b194cbd8ea0` |
| file_context | `tests/test_gradio_ui.py` | `chunk_e08b69c3a756297f` |

### 4. Remote code execution transport and answer handoff

Workflow ID: `business_path_6f9b965a64d7e675`

An agent executor serializes variables and final answers for transport into a remote Python environment, then deserializes results under an explicit safe-versus-pickle policy.

**Purpose:** Run agent code in a remote sandbox while preserving data fidelity and transport safety

**Business outcome**

- Moves agent state into the remote kernel namespace
- Encodes final answers for return to the caller
- Rejects unsafe pickle payloads unless explicitly enabled

**Important behavior and rules**

- Remote executor transport defaults to safe JSON serialization and only permits pickle as an explicit legacy/insecure mode.
- Final answer patching serializes the returned value before raising the sentinel exception used by the remote executor.
- If allow_pickle is false, pickle payloads are rejected during deserialization.
- If serialization cannot be done safely, the code falls back to pickle only when explicitly allowed.

**Identified functions:** `RemotePythonExecutor.send_variables`, `RemotePythonExecutor._patch_final_answer_with_exception`, `RemotePythonExecutor._deserialize_final_answer`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `src/smolagents/remote_executors.py` | `chunk_155870ae90198e14` |
| Source section | `src/smolagents/remote_executors.py` | `chunk_2df2b2ce5d21e128` |
| Source section | `src/smolagents/serialization.py` | `chunk_749cc9767a547c2f` |
| Source section | `src/smolagents/remote_executors.py` | `chunk_bd10f3bc40e34575` |
| Source section | `src/smolagents/serialization.py` | `chunk_d033b7ab3f0eb5f2` |

### 5. Interactive UI presentation of agent progress

Workflow ID: `business_path_704f32c74eb4a775`

Agent execution steps are converted into Gradio chat messages and streamed to a UI consumer as planning, action, or final-answer updates.

**Purpose:** Show the user what the agent is planning or answering in real time

**Business outcome**

- Surfaces intermediate reasoning and final answers to the user
- Preserves stream order across planning, action, and final-answer events
- Converts rich outputs such as images and audio into UI-friendly payloads

**Important behavior and rules**

- Streaming UI output must not duplicate model text when the agent already streams outputs.
- Unsupported step types are rejected with a ValueError.
- Gradio package must be available before message streaming is attempted.
- Final answers are typed and rendered differently for text, image, and audio outputs.

**Identified functions:** `stream_to_gradio`, `_process_final_answer_step`, `pull_messages_from_step`, `_process_planning_step`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| _process_final_answer_step | `src/smolagents/gradio_ui.py` | `chunk_1d31f01212817109` |
| pull_messages_from_step | `src/smolagents/gradio_ui.py` | `chunk_93bd7c68efd93883` |
| _process_planning_step | `src/smolagents/gradio_ui.py` | `chunk_b5036a608d9ce3a6` |
| stream_to_gradio | `src/smolagents/gradio_ui.py` | `chunk_c0b427e4adc94817` |

### 6. web research question answering

Workflow ID: `business_path_5c4827b45442a541`

CLI user supplies a question; the open_deep_research script builds a browsing/search agent stack and runs it to produce an answer.

**Purpose:** ask a natural-language question and get a researched answer

**Business outcome**

- Produces a synthesized answer from web browsing and file inspection
- Uses external search and model inference services to complete the task

**Important behavior and rules**

- The managed search agent is given web-search, page navigation, archive search, and text inspection tools, and the manager agent can also use visual inspection.
- The browser configuration includes a SerpAPI key, custom user agent, timeout, and downloads folder for browsing tasks.

**Identified functions:** `examples/open_deep_research/run.py:create_agent`, `examples/open_deep_research/run.py:main`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| main/create_agent | `examples/open_deep_research/run.py` | `chunk_0d5dd88a1bd25045` |

### 7. LLM tool-call execution

Workflow ID: `business_path_4c88daccb6ceec38`

A ToolCallingAgent receives an LLM-produced tool call, validates it, executes the tool or managed agent, and records the resulting observation or final answer.

**Purpose:** invoke a tool or managed agent on behalf of the model

**Business outcome**

- Turns model decisions into concrete tool actions
- Captures observations and final answers for subsequent steps

**Important behavior and rules**

- If stream_outputs is enabled, the model must implement generate_stream; otherwise initialization fails.
- The agent rejects unknown tool names that are not in the combined tool/managed-agent registry.
- Tool arguments are validated before execution and may be substituted from agent state variables.

**Identified functions:** `src/smolagents/agents.py:ToolCallingAgent.execute_tool_call`, `src/smolagents/agents.py:ToolCallingAgent._step_stream`, `src/smolagents/agents.py:ToolCallingAgent.process_tool_calls`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `src/smolagents/agents.py` | `chunk_4ed5d4eeb4d8917c` |
| Source section | `src/smolagents/agents.py` | `chunk_add3572d271a45c3` |
| Source section | `src/smolagents/agents.py` | `chunk_c205a07ef94436f6` |

### 8. code-based agent execution

Workflow ID: `business_path_68d5c9f7e2c84755`

A CodeAgent generates code from the model, parses it, executes it through a Python executor, and returns the resulting output or final answer.

**Purpose:** let the model solve a task by emitting executable code

**Business outcome**

- Runs model-written code to complete tasks
- Supports local or remote execution backends
- Produces truncated logs/output for the user-facing run

**Important behavior and rules**

- CodeAgent only supports a fixed set of executor types and raises on unsupported values.
- Managed agents are not supported when using remote code execution backends.
- The generated code is validated, executed, and its output may be truncated before being logged or returned.

**Identified functions:** `src/smolagents/agents.py:CodeAgent.create_python_executor`, `src/smolagents/agents.py:CodeAgent._step_stream`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `src/smolagents/agents.py` | `chunk_2bfbe6642aa933b9` |
| Source section | `src/smolagents/agents.py` | `chunk_7a9d2e02e6e8a9fd` |
| Source section | `src/smolagents/agents.py` | `chunk_bfc7f5e109e85487` |

### 9. agentic web browsing and retrieval

Workflow ID: `business_path_d15ef6b6c515ac29`

Agent-facing browser/search tools let an agent search the web, visit pages, and receive readable page content or search result summaries.

**Purpose:** find online information and read webpage content through a text browser

**Business outcome**

- returns searchable text from web pages
- surfaces prior-visit context and viewport position
- enables agentic research workflows

**Important behavior and rules**

- Browser search requires a SerpAPI key before executing Google search queries.
- Repeated Ctrl+F-style searches advance to the next match when the same query is repeated at the current result.
- Search results are redacted into a text summary rather than returning raw provider payloads.
- If the query is empty after normalization, no viewport match is returned.
- If SerpAPI key is missing, browser search raises an error.

**Identified functions:** `SearchInformationTool.forward`, `SimpleTextBrowser.visit_page`, `VisitTool.forward`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `examples/open_deep_research/scripts/text_web_browser.py` | `chunk_25f7523258e2470e` |
| VisitTool.forward | `examples/open_deep_research/scripts/text_web_browser.py` | `chunk_48a658afdaa0a924` |
| Source section | `examples/open_deep_research/scripts/text_web_browser.py` | `chunk_5036562777bf3210` |
| Source section | `examples/open_deep_research/scripts/text_web_browser.py` | `chunk_5979466314168959` |
| CodeAgent | `examples/gradio_ui.py` | `chunk_96d6713188685f53` |
| SearchInformationTool.forward | `examples/open_deep_research/scripts/text_web_browser.py` | `chunk_fc4a55bc31a2e48b` |

### 10. external file acquisition and web archival lookup

Workflow ID: `business_path_8319c7f20c390e59`

Browser download and archive tools fetch external files or archived URLs, persist downloads locally, and then route content back into the browser state for inspection.

**Purpose:** retrieve a remote file or closest archived copy of a URL for later inspection

**Business outcome**

- downloads binary assets to a local path
- returns archive snapshot text for inspection
- supports research on unavailable or historical pages

**Important behavior and rules**

- The download tool is intentionally limited away from pdf/txt/html content.
- Archive retrieval uses the closest available Wayback snapshot and then re-enters browser inspection flow.
- PDF, TXT, and HTML files should not use the download tool; visit_page should be used instead.
- Archive lookup requires either a timestamped or non-timestamped archived snapshot to exist.

**Identified functions:** `ArchiveSearchTool.forward`, `DownloadTool.forward`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| ArchiveSearchTool.forward | `examples/open_deep_research/scripts/text_web_browser.py` | `chunk_1854e89f3f5e9751` |
| Source section | `examples/open_deep_research/scripts/text_web_browser.py` | `chunk_25f7523258e2470e` |
| Source section | `examples/open_deep_research/scripts/text_web_browser.py` | `chunk_5979466314168959` |
| DownloadTool.forward | `examples/open_deep_research/scripts/text_web_browser.py` | `chunk_8058fe431dbda830` |
| CodeAgent | `examples/gradio_ui.py` | `chunk_96d6713188685f53` |

### 11. constrained code execution for agent reasoning / sandboxed Python code execution

Workflow ID: `business_path_67020919c6a08dce`

Restricted local Python execution evaluates agent-generated code, enforces authorized imports and timeouts, and returns stdout plus a structured result. / A caller submits Python code to the local executor, which evaluates it against a controlled tool/state environment and returns the computed result while mutating execution state.

**Purpose:** run Python snippets to compute results or manipulate intermediate state / execute agent-authored Python snippets safely

**Business outcome**

- produces stdout and output for agent reasoning
- rejects unsupported imports and unsafe constructs
- limits execution duration
- returns computed values from code
- persists variables and print output into execution state
- prevents unsafe imports and tool overwrites
- limits runaway execution with operation and loop bounds

**Important behavior and rules**

- Final answer function calls are wrapped so a FinalAnswerException can carry the final value back to the caller.
- Dangerous modules and functions are explicitly enumerated for restricted execution.
- Assignments cannot overwrite an existing tool name such as print.
- The executor enforces an operation budget and raises once the maximum number of operations is reached.
- Explicitly unauthorized imports such as os and builtins are rejected unless included in the authorized import set.
- Dangerous functions and dunder access are blocked unless explicitly authorized.
- Only authorized imports are allowed and missing authorized modules cause an InterpreterError.
- Execution is time-bounded by a timeout wrapper when timeout_seconds is set.

**Identified functions:** `evaluate_python_code`, `PythonInterpreterTool.forward`, `LocalPythonExecutor.__call__`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| evaluate_python_code | `src/smolagents/local_python_executor.py` | `chunk_05fe36ff87a6bb25` |
| Source section | `tests/test_local_python_executor.py` | `chunk_07b30765d30934aa` |
| Source section | `tests/test_local_python_executor.py` | `chunk_0e23cbe5248e952a` |
| Source section | `tests/test_local_python_executor.py` | `chunk_3165ae68c5cb60d4` |
| Source section | `tests/test_local_python_executor.py` | `chunk_33d59e423418a221` |
| test_local_python_executor imports | `tests/test_local_python_executor.py` | `chunk_4fcb16579b65443f` |
| Source section | `tests/test_local_python_executor.py` | `chunk_62f8aeb93b47be37` |
| PythonInterpreterTool.forward | `src/smolagents/default_tools.py` | `chunk_7086f4b0a84c7e7a` |
| TestPrintContainer | `tests/test_local_python_executor.py` | `chunk_9d90fd6344d0910d` |
| DANGEROUS_MODULES/DANGEROUS_FUNCTIONS | `src/smolagents/local_python_executor.py` | `chunk_a237edab62e7666f` |
| timeout | `src/smolagents/local_python_executor.py` | `chunk_e1988e2f3bf5febf` |
| LocalPythonExecutor | `src/smolagents/local_python_executor.py` | `chunk_f01f016e43d2457f` |
| PrintContainer | `src/smolagents/local_python_executor.py` | `chunk_f3ebb1605c3121df` |
| Source section | `tests/test_local_python_executor.py` | `chunk_fc609bedeab15d64` |

### 12. Tool packaging and distribution

Workflow ID: `business_path_f3acbfe8dd000f3e`

A developer-defined Tool is validated, serialized, saved or published, and can later be reloaded from code, Hub, or MCP into an executable tool object.

**Purpose:** Prepare a tool for reuse, distribution, or deployment in another runtime

**Business outcome**

- Makes tool logic portable across local code, Hub, and MCP sources
- Creates executable UI and requirements artifacts for sharing
- Can initialize remote-backed tool wrappers for agent use

**Important behavior and rules**

- A tool cannot be loaded from Hub unless the caller explicitly opts into trusting remote code.
- A tool collection cannot be loaded from MCP unless the caller explicitly opts into trusting remote code.
- Tool schemas must only use authorized input types and a validated output_type.
- Tool subclasses must define description, name, inputs, and output_type, and inputs must use authorized types.
- Loading a tool or tool collection from remote sources requires trust_remote_code=True.

**Identified functions:** `Tool.validate_arguments`, `ToolCollection.from_mcp`, `Tool.push_to_hub`, `ToolCollection.from_hub`, `Tool.save`, `Tool.from_hub`, `Tool.from_dict`, `Tool.to_dict`, `Tool.from_code`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `src/smolagents/tools.py` | `chunk_12733d4c1c9c7b32` |
| Source section | `src/smolagents/tools.py` | `chunk_14855dca599749d8` |
| Source section | `src/smolagents/tools.py` | `chunk_34d872a6a0dc4c0b` |
| Source section | `src/smolagents/tools.py` | `chunk_3c0d9044a7978da3` |
| evaluate_ast | `src/smolagents/local_python_executor.py` | `chunk_63ff6fa2d49397e3` |
| Source section | `src/smolagents/tools.py` | `chunk_9dcfc65ca586b1bb` |
| load_tool | `src/smolagents/tools.py` | `chunk_d264973d2a27fb7b` |
| ToolCollection | `src/smolagents/tools.py` | `chunk_d3883465dc4f5bb1` |

### 13. Safe local Python execution

Workflow ID: `business_path_7a9ae5b1f18bf7fe`

Agent-generated Python code is parsed and evaluated locally with controlled imports, bounded operations, and explicit error handling.

**Purpose:** Run model-generated or user-supplied Python logic while constraining imports and runaway execution

**Business outcome**

- Allows the system to compute results from generated code
- Prevents unrestricted imports and excessive operation counts
- Surfaces interpreter errors and timeouts instead of hanging

**Important behavior and rules**

- Each AST evaluation increments an operation counter and fails after the configured maximum is reached.
- Only authorized imports may be executed and inserted into the evaluation state.
- Unsupported AST node types are rejected rather than silently executed.
- Execution stops once the maximum operation count is reached.
- Imports are only allowed when the module is authorized.

**Identified functions:** `evaluate_ast`, `evaluate_import`, `evaluate_generatorexp`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| evaluate_generatorexp | `src/smolagents/local_python_executor.py` | `chunk_2f9f15a3240443f8` |
| evaluate_ast | `src/smolagents/local_python_executor.py` | `chunk_63ff6fa2d49397e3` |
| file_context | `src/smolagents/local_python_executor.py` | `chunk_c84a4593d02c5694` |
| evaluate_import | `src/smolagents/local_python_executor.py` | `chunk_e2e2f74a13dea818` |

### 14. Web search and article retrieval

Workflow ID: `business_path_85c7d52d7bc68dce`

A user query is sent to external search or article sources and returned as formatted text results for agent consumption.

**Purpose:** Find and return source text or search results for a user query

**Business outcome**

- Provides external knowledge to the agent
- Formats results for downstream prompting or display
- Can fail gracefully when no result exists or the article is unavailable

**Important behavior and rules**

- If DuckDuckGo returns no results, the tool raises an exception instructing the caller to relax the query.
- Wikipedia lookup returns a friendly message when the page does not exist.
- DuckDuckGo requests are rate limited unless rate_limit is disabled.
- WikipediaSearchTool requires a non-empty user_agent and a valid extract_format.

**Identified functions:** `WikipediaSearchTool.forward`, `DuckDuckGoSearchTool.forward`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| file_context | `examples/open_deep_research/scripts/text_web_browser.py` | `chunk_a55c87b2258cc1c9` |
| WikipediaSearchTool | `src/smolagents/default_tools.py` | `chunk_c3e0e85d02526cf2` |
| DuckDuckGoSearchTool.forward | `src/smolagents/default_tools.py` | `chunk_e7fc7d59c1e16383` |

### 15. model generation with telemetry instrumentation

Workflow ID: `business_path_9c08a9ff1a95f0a5`

A caller invokes InferenceClientModel.generate, and instrumentation records a successful OpenTelemetry span around the model call.

**Purpose:** produce a language-model response while emitting trace data

**Business outcome**

- returns a model-generated answer
- records observability data for the call
- supports integration monitoring and tracing

**Important behavior and rules**

- Model calls are instrumented when SmolagentsInstrumentor is active.
- A successful model call yields exactly one finished span named InferenceClientModel.generate.

**Identified functions:** `InferenceClientModel.__call__`, `InferenceClientModel.generate`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| TestOpenTelemetry.test_model | `tests/test_telemetry.py` | `chunk_690616948aff1cff` |
| InferenceClientModel | `src/smolagents/models.py` | `chunk_d7218d91d6c17f8e` |

### 16. LLM task orchestration with tool use

Workflow ID: `business_path_5ea4317e5edba324`

A MultiStepAgent receives a task, cycles through planning and action steps with tools and memory, and returns a final answer or max-steps result.

**Purpose:** Solve a user-provided task step by step and produce a final answer

**Business outcome**

- Produces a task completion result
- Tracks execution steps, token usage, and timing
- Supports managed-agent delegation and step callbacks

**Important behavior and rules**

- An agent run may be streamed step-by-step or executed to completion and returned as a final answer, depending on the stream flag.
- If max steps are reached, the agent produces a max-steps error state and wraps the final answer through provide_final_answer().
- Prompt templates must include all required keys before agent initialization completes.
- final_answer_checks are validated before final answer acceptance when present.

**Identified functions:** `MultiStepAgent.run`, `MultiStepAgent.__call__`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `src/smolagents/agents.py` | `chunk_01f8c7552acf5d18` |
| Source section | `src/smolagents/vision_web_browser.py` | `chunk_25a92617fdcac7a5` |
| Source section | `src/smolagents/agents.py` | `chunk_2e5670edf14238db` |
| Source section | `src/smolagents/vision_web_browser.py` | `chunk_40944bf77dec76b0` |
| get_json_schema | `src/smolagents/_function_type_hints_utils.py` | `chunk_66d8a4eb45bee635` |
| Source section | `src/smolagents/vision_web_browser.py` | `chunk_84022c2972f09839` |
| Source section | `src/smolagents/vision_web_browser.py` | `chunk_87379eb3acbcbe4c` |
| Source section | `src/smolagents/agents.py` | `chunk_9c9463b9686a77ae` |
| Source section | `src/smolagents/agents.py` | `chunk_a5cbd1df16c65113` |
| Source section | `src/smolagents/vision_web_browser.py` | `chunk_af07f60a3585a62e` |
| Source section | `src/smolagents/vision_web_browser.py` | `chunk_c2334f083ffa2356` |
| Source section | `src/smolagents/agents.py` | `chunk_c79d84ede69722f5` |
| Source section | `src/smolagents/agents.py` | `chunk_c9b33078ee66d3b0` |
| Source section | `src/smolagents/vision_web_browser.py` | `chunk_fe182d30c8a13bdd` |

### 17. tool schema extraction

Workflow ID: `business_path_59dde4eb457065fa`

Utility functions inspect Python callables, parse Google-style docstrings and type hints, and emit JSON schemas for tool descriptions.

**Purpose:** Turn Python functions into machine-readable tool schemas

**Business outcome**

- Enables tool descriptions for chat templates
- Validates docstring and type-hint completeness
- Normalizes complex Python types into JSON-schema structures

**Important behavior and rules**

- Type hints take precedence over docstring type annotations when both are present.
- Optional/union types are converted into nullable or anyOf-style schema representations.
- A docstring must exist or schema generation fails.
- Every argument must be described in the docstring.

**Identified functions:** `_parse_google_format_docstring`, `get_imports`, `get_json_schema`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `tests/test_function_type_hints_utils.py` | `chunk_0a6b69344b232c9b` |
| _parse_google_format_docstring | `src/smolagents/_function_type_hints_utils.py` | `chunk_3ed237f1a6c2b333` |
| _parse_type_hint/_parse_union_type | `src/smolagents/_function_type_hints_utils.py` | `chunk_651f6332261a6d33` |
| get_json_schema | `src/smolagents/_function_type_hints_utils.py` | `chunk_66d8a4eb45bee635` |
| Source section | `tests/test_function_type_hints_utils.py` | `chunk_b32a62ee2c5e5f30` |
| _convert_type_hints_to_json_schema | `src/smolagents/_function_type_hints_utils.py` | `chunk_d05d4096a39d1d70` |

### 18. browser-assisted web navigation for an agent

Workflow ID: `business_path_70c59c5bcec67880`

A browser helper captures screenshots, appends current URL context, and exposes a safe search tool that focuses a matching page element.

**Purpose:** Find page text safely and keep browser observations current for the agent

**Business outcome**

- Supports web research and task completion
- Improves observation quality with screenshots and URL context
- Reduces XPath query injection risk via escaping

**Important behavior and rules**

- The browser search tool must focus the requested occurrence rather than the first match only.
- XPath text is escaped before being inserted into the query.
- If nth_result exceeds available matches, an exception is raised.

**Identified functions:** `initialize_agent`, `search_item_ctrl_f`, `save_screenshot`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `src/smolagents/vision_web_browser.py` | `chunk_0893c468a3f77874` |
| Source section | `src/smolagents/vision_web_browser.py` | `chunk_84022c2972f09839` |
| Source section | `src/smolagents/vision_web_browser.py` | `chunk_af07f60a3585a62e` |
| TestXPathEscaping.test_escape_prevents_injection | `tests/test_vision_web_browser.py` | `chunk_b36ace8abe06d509` |
| Source section | `src/smolagents/vision_web_browser.py` | `chunk_c2334f083ffa2356` |
| Source section | `src/smolagents/vision_web_browser.py` | `chunk_fe182d30c8a13bdd` |

### 19. model inference backend selection and prompt-to-response generation

Workflow ID: `business_path_d54aea15419136ba`

A backend model adapter loads a local or hosted LLM, prepares chat-formatted prompts, and returns assistant text or tool-call capable responses for agent use.

**Purpose:** obtain model-generated assistant output from a chosen inference backend

**Business outcome**

- Enables local inference and serving
- Produces assistant text for downstream agent steps
- Preserves token accounting and stop-sequence behavior

**Important behavior and rules**

- MLXModel rejects structured-output requests by raising ValueError when response_format is provided.
- TransformersModel rejects structured-output requests and directs callers to VLLMModel for that feature.

**Identified functions:** `MLXModel.generate`, `VLLMModel.generate`, `TransformersModel.generate`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `src/smolagents/models.py` | `chunk_334d444ea0aa10bc` |
| MLXModel | `src/smolagents/models.py` | `chunk_48846b64eea2fa6c` |
| Source section | `src/smolagents/models.py` | `chunk_8ebb08ad261941c4` |
| Source section | `src/smolagents/models.py` | `chunk_afc9cab547b46ed0` |
| VLLMModel | `src/smolagents/models.py` | `chunk_f8a6671f55a28530` |

### 20. remote LLM API integration

Workflow ID: `business_path_7825212fb53fed12`

An API-backed model adapter builds a completion request, rate-limits it, retries on rate-limit errors, and returns the provider response as a ChatMessage.

**Purpose:** call a hosted model endpoint safely and recover from transient rate limits

**Business outcome**

- Supports OpenAI-compatible, Azure OpenAI, and Bedrock deployments
- Applies retry and throttle controls for API stability
- Normalizes response content and token usage for the agent runtime

**Important behavior and rules**

- API completion requests are throttled through a rate limiter before execution.
- Retry behavior is enabled for rate-limit errors and can be disabled by constructing ApiModel with retry=False.
- Amazon Bedrock request payloads are rewritten to remove unsupported toolConfig and type fields before submission.

**Identified functions:** `OpenAIModel.generate`, `AmazonBedrockModel.generate`, `ApiModel.__init__`, `AzureOpenAIModel.create_client`, `OpenAIModel.generate_stream`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| AmazonBedrockModel | `src/smolagents/models.py` | `chunk_321b6965c7dd88a5` |
| OpenAIModel | `src/smolagents/models.py` | `chunk_bb6ff7d20bfe89ec` |
| ApiModel.__init__ | `src/smolagents/models.py` | `chunk_d1f9e8e6bd147513` |
| is_rate_limit_error | `src/smolagents/models.py` | `chunk_d448304059b3a280` |
| AzureOpenAIModel.create_client | `src/smolagents/models.py` | `chunk_d5f1a98396369af2` |

### 21. multi-step agent orchestration

Workflow ID: `business_path_b721e21635eb04ee`

Agent tests show a tool-calling or code-executing agent taking a task, invoking tools, recording memory steps, and producing a final answer or error state.

**Purpose:** solve a task by iterating between model reasoning and tool execution

**Business outcome**

- Demonstrates tool use and final-answer completion
- Records observations, tool calls, and errors in memory
- Supports streaming tool-call handling and validation

**Important behavior and rules**

- ToolCallingAgent passes both ordinary tools and managed agents into the model tool-selection set.
- process_tool_calls preserves each tool call's name, arguments, and id in memory when execution succeeds.
- A final answer tool call may be the only terminal tool call in a step, and its output becomes the final observation/output.

**Identified functions:** `TestAgent.test_fake_code_agent`, `TestToolCallingAgent.test_toolcalling_agent_api`, `TestAgent.test_fake_toolcalling_agent`, `TestToolCallingAgent.test_process_tool_calls`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `tests/test_agents.py` | `chunk_56ac3d0068d15e93` |
| Source section | `tests/test_agents.py` | `chunk_6adcdab8f6b6d12d` |
| Source section | `tests/test_agents.py` | `chunk_88a885c810f0c0bf` |
| Source section | `tests/test_agents.py` | `chunk_973420e50a5ca6ae` |
| Source section | `tests/test_agents.py` | `chunk_aba0136b2c90354c` |
| Source section | `tests/test_agents.py` | `chunk_bafbd1dd46d52173` |
| Source section | `tests/test_agents.py` | `chunk_c27c98dc57778c85` |
| Source section | `tests/test_agents.py` | `chunk_c31bab1cfcc83a0b` |
| Source section | `tests/test_agents.py` | `chunk_f51aba6a388d0dbc` |

### 22. inspect_file_as_text / document-to-text conversion

Workflow ID: `business_path_0adc88f8e9d30bb3`

File-inspection tools convert local text-like and web document inputs into markdown/text results for downstream research use.

**Purpose:** Read a local file as markdown/text so a research agent can ask questions about it

**Business outcome**

- Makes non-text documents queryable in a text-centric workflow
- Normalizes heterogeneous document formats into a common representation
- Reduces the need for format-specific downstream handling

**Important behavior and rules**

- Conversion is format-gated by file extension or URL pattern before any file processing occurs.
- HTML and Wikipedia conversion strips script/style elements before text extraction.
- Return None unless the guessed content type is text-like.
- Return None unless the extension is .html or .htm.
- Return None unless the URL matches the Wikipedia host pattern.
- Return None unless the URL starts with a YouTube watch URL.

**Identified functions:** `PptxConverter.convert`, `XlsxConverter.convert`, `PlainTextConverter.convert`, `HtmlConverter.convert`, `WikipediaConverter.convert`, `DocxConverter.convert`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| DocumentConverterResult | `examples/open_deep_research/scripts/mdconvert.py` | `chunk_39b1f5eefb71cf5a` |
| mdconvert imports | `examples/open_deep_research/scripts/mdconvert.py` | `chunk_5ffc1714a3d7f6eb` |
| PlainTextConverter.convert | `examples/open_deep_research/scripts/mdconvert.py` | `chunk_73cfc3f83e479fdf` |
| YouTubeConverter.convert | `examples/open_deep_research/scripts/mdconvert.py` | `chunk_816d1f2fda22a3d9` |
| WikipediaConverter.convert | `examples/open_deep_research/scripts/mdconvert.py` | `chunk_b0ee152518b24cf8` |
| HtmlConverter.convert | `examples/open_deep_research/scripts/mdconvert.py` | `chunk_f99570b911931d4a` |

### 23. media-to-text enrichment

Workflow ID: `business_path_c8b1a51610b5cd32`

Audio and image converters enrich media inputs with metadata, transcription, OCR/LLM-style description, and return text outputs.

**Purpose:** Turn audio or image files into readable research notes

**Business outcome**

- Makes non-text media searchable and inspectable
- Captures metadata alongside human-readable text
- Can add transcription or image description when optional dependencies are present

**Important behavior and rules**

- Media conversion prefers enrichment from metadata before transcription or description text.
- Audio transcription is attempted through speech_recognition and, for MP3/M4A, via a temporary WAV file.
- Return None unless the extension matches the converter's supported media type.
- Image description is only attempted when both mlm_client and mlm_model are provided.
- Transcription failure falls back to an error text instead of raising from convert.

**Identified functions:** `ImageConverter.convert`, `Mp3Converter.convert`, `WavConverter.convert`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| WavConverter.convert | `examples/open_deep_research/scripts/mdconvert.py` | `chunk_370a6b97d26a4ef6` |
| DocumentConverterResult | `examples/open_deep_research/scripts/mdconvert.py` | `chunk_39b1f5eefb71cf5a` |
| ImageConverter.convert | `examples/open_deep_research/scripts/mdconvert.py` | `chunk_88741bfebb94fb97` |
| Mp3Converter.convert | `examples/open_deep_research/scripts/mdconvert.py` | `chunk_abe5c6301353210d` |

### 24. archive extraction and file listing

Workflow ID: `business_path_25cd68dbab3d82ef`

ZIP archives are extracted to a local directory and a deterministic file listing is returned for the agent.

**Purpose:** Unpack a ZIP file into a local working directory and know what was extracted

**Business outcome**

- Makes packaged downloads usable as individual files
- Creates a stable extracted file listing for downstream processing
- Persists extracted content under a configured directory

**Important behavior and rules**

- Extraction occurs into a configured local directory that is created on initialization if missing.
- The returned listing is sorted for deterministic output.
- Return None unless the extension is .zip.
- Return None unless zipfile.is_zipfile(local_path) is true.

**Identified functions:** `ZipConverter.convert`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| ZipConverter | `examples/open_deep_research/scripts/mdconvert.py` | `chunk_4495f556da74aba3` |

### 25. web chat agent response

Workflow ID: `business_path_f0f21c0213e0c51c`

Anonymous web client submits a chat message to /chat, the server runs the code agent on the message, and returns a JSON reply.

**Purpose:** ask the agent a question and receive a response

**Business outcome**

- interactive conversational assistance
- immediate JSON response for the frontend

**Important behavior and rules**

- The chat handler executes the agent on a background thread to avoid blocking the event loop.
- Empty message returns early without calling the agent

**Identified functions:** `examples/server/main.py:Route('/chat', chat, methods=['POST'])`, `chat(request)`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| chat | `examples/server/main.py` | `chunk_1445026d556152f3` |

### 26. tool-session setup and teardown

Workflow ID: `business_path_e6be5d5a5e305331`

The MCP client establishes a tool session with a remote MCP server, exposes the tools to SmolAgents, and disconnects on cleanup.

**Purpose:** obtain usable tools from an MCP server for agent execution

**Business outcome**

- remote tools become callable by the agent
- session resources are cleaned up when disconnected

**Important behavior and rules**

- The client connects during initialization and exposes tools only after the connection is established.
- get_tools() raises an error if the session has not been connected.
- Default structured_output emits a FutureWarning and is forced to False when omitted
- Only 'sse' and 'streamable-http' transports are accepted for dict server parameters

**Identified functions:** `MCPClient.connect()`, `src/smolagents/mcp_client.py:MCPClient.__init__`, `MCPClient.get_tools()`, `MCPClient.disconnect()`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| test_mcp_client_with_structured_output | `tests/test_mcp_client.py` | `chunk_8d85e3348c38c5e6` |
| MCPClient | `src/smolagents/mcp_client.py` | `chunk_c94b43f21521f6b9` |

### 27. sandboxed Python evaluation

Workflow ID: `business_path_58dcd70f7f747b04`

The local Python executor evaluates AST/code with explicit safety gates, restricted imports/calls, bounded loops, and controlled state mutation.

**Purpose:** execute generated Python safely while preserving interpreter state control

**Business outcome**

- reduces unsafe access to dunder attributes and unauthorized builtins
- controls loop execution and assignment side effects
- produces evaluated results for tool execution

**Important behavior and rules**

- Assignments to names that would overwrite static tools are rejected.
- While loops are terminated if they exceed the configured iteration limit.
- Function return values are validated for safety before being accepted.
- Dunder attribute access is forbidden
- Unauthorised builtin function invocation is forbidden

**Identified functions:** `src/smolagents/local_python_executor.py:evaluate_while`, `src/smolagents/local_python_executor.py:safer_eval`, `src/smolagents/local_python_executor.py:evaluate_call`, `src/smolagents/local_python_executor.py:safer_func`, `src/smolagents/local_python_executor.py:set_value`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| MAX_WHILE_ITERATIONS | `src/smolagents/local_python_executor.py` | `chunk_65681e78bf82b808` |
| evaluate_attribute | `src/smolagents/local_python_executor.py` | `chunk_996b7972e6e923db` |
| safer_eval | `src/smolagents/local_python_executor.py` | `chunk_a10482b1bf87faf6` |
| evaluate_while | `src/smolagents/local_python_executor.py` | `chunk_ae6ce81d86aa8870` |
| create_function | `src/smolagents/local_python_executor.py` | `chunk_cb3cfe7b9232c819` |
| set_value | `src/smolagents/local_python_executor.py` | `chunk_d127dd9ade7dd479` |
| nodunder_getattr | `src/smolagents/local_python_executor.py` | `chunk_e6071cad0671732d` |
| evaluate_call | `src/smolagents/local_python_executor.py` | `chunk_ec46b60d69fd7178` |
| check_safer_result | `src/smolagents/local_python_executor.py` | `chunk_f4632a9cbc07dfea` |

### 28. remote python sandbox execution

Workflow ID: `business_path_6ea95c496e245025`

DockerExecutor initializes a Docker-backed Jupyter sandbox, connects to it over HTTP/websocket, executes remote Python code, and cleans up the container.

**Purpose:** start and manage a Docker-backed execution environment for agent code

**Business outcome**

- Provides isolated code execution for agents
- Returns executed code results through the remote kernel
- Releases container resources after use

**Important behavior and rules**

- The executor injects a generated KG_AUTH_TOKEN into the container environment before starting the kernel gateway.
- Cleanup is best-effort and logs errors instead of raising them.
- If build_new_image is false and the image already exists, reuse the existing Docker image instead of rebuilding it.
- If no container exists during cleanup, do nothing beyond error handling.

**Identified functions:** `DockerExecutor.__init__`, `DockerExecutor.run_code_raise_errors`, `DockerExecutor.cleanup`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| TestDockerExecutorUnit.test_cleanup | `tests/test_remote_executors.py` | `chunk_71483872da0ebb67` |
| DockerExecutor.__init__ | `src/smolagents/remote_executors.py` | `chunk_a95beb2e97fcff60` |
| TestDockerExecutorIntegration | `tests/test_remote_executors.py` | `chunk_f06b80adb4db94b8` |

### 29. remote python sandbox execution

Workflow ID: `business_path_3745840c15ec9e1c`

ModalExecutor creates a Modal sandbox, starts a Jupyter kernel gateway, executes remote Python code, and terminates the sandbox.

**Purpose:** provision and manage a Modal-backed execution environment

**Business outcome**

- Provides isolated execution for agent code
- Installs requested packages into the sandbox
- Ensures sandbox termination on cleanup

**Important behavior and rules**

- The executor injects a generated KG_AUTH_TOKEN into the sandbox secrets/environment before startup.
- Cleanup should terminate the sandbox and clear local references even if termination fails.
- If no additional imports are requested, package installation returns an empty list.
- Cleanup is idempotent via a private _cleaned_up flag.

**Identified functions:** `ModalExecutor.cleanup`, `ModalExecutor.run_code_raise_errors`, `ModalExecutor.__init__`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| ModalExecutor.install_packages | `src/smolagents/remote_executors.py` | `chunk_1e49bf366e95c986` |
| TestModalExecutorIntegration | `tests/test_remote_executors.py` | `chunk_560d643cd9d76a76` |
| TestModalExecutorUnit.test_sandbox_lifecycle | `tests/test_remote_executors.py` | `chunk_cd744e9d2e2d17c0` |
| ModalExecutor.__init__ | `src/smolagents/remote_executors.py` | `chunk_e874dbfc47f81d74` |

### 30. remote python sandbox execution

Workflow ID: `business_path_e972d791a670c247`

BlaxelExecutor provisions a Blaxel sandbox, creates a Jupyter kernel, installs packages, executes remote Python code, and deletes the sandbox on cleanup.

**Purpose:** provision and manage a Blaxel-backed execution environment

**Business outcome**

- Provides isolated execution for agent code
- Installs packages requested at runtime
- Ensures sandbox teardown on cleanup

**Important behavior and rules**

- The executor always provisions a default sandbox name when none is supplied.
- Cleanup should attempt deletion even when errors occur, then always clear local references.
- If additional imports are empty, package installation returns immediately with no work.
- Cleanup is idempotent via a private cleaned-up flag.

**Identified functions:** `BlaxelExecutor.cleanup`, `BlaxelExecutor.run_code_raise_errors`, `BlaxelExecutor.__init__`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| TestBlaxelExecutorUnit | `tests/test_remote_executors.py` | `chunk_07032a7d55ffcc28` |
| BlaxelExecutor.__init__ | `src/smolagents/remote_executors.py` | `chunk_1e49bf366e95c986` |

## 2. Verified code connections and remaining repository context

Connections are static source relationships; they do not prove runtime execution.

- `chunk_02d6e06d481358f0` → `chunk_152c43e583c81bac`: imports_symbol; symbol: parse_json_blob
- `chunk_02d6e06d481358f0` → `chunk_2037af895b0c6d50`: imports_symbol; symbol: get_source
- `chunk_02d6e06d481358f0` → `chunk_2bcb8bef88d9e7cc`: imports_symbol; symbol: instance_to_source
- `chunk_02d6e06d481358f0` → `chunk_539357549d8dfca1`: imports_symbol; symbol: is_valid_name
- `chunk_02d6e06d481358f0` → `chunk_89836993219a9e82`: imports_symbol; symbol: tool
- `chunk_02d6e06d481358f0` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_02d6e06d481358f0` → `chunk_ce569827a0fa0cb0`: imports_symbol; symbol: create_agent_gradio_app_template
- `chunk_02d6e06d481358f0` → `chunk_d5f0406f7083f4f4`: imports_symbol; symbol: parse_code_blobs
- `chunk_02d6e06d481358f0` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_042e37782041254c` → `chunk_334d444ea0aa10bc`: imports_symbol; symbol: TransformersModel
- `chunk_042e37782041254c` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_042e37782041254c` → `chunk_89836993219a9e82`: imports_symbol; symbol: tool
- `chunk_042e37782041254c` → `chunk_bb6ff7d20bfe89ec`: imports_symbol; symbol: OpenAIModel
- `chunk_042e37782041254c` → `chunk_c205a07ef94436f6`: imports_symbol; symbol: ToolCallingAgent
- `chunk_042e37782041254c` → `chunk_c67e8b7e20518df4`: imports_symbol; symbol: LiteLLMModel
- `chunk_042e37782041254c` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_0ba371f34198966f` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_0d5dd88a1bd25045` → `chunk_0afee5abeed723e8`: imports_symbol; symbol: PageDownTool
- `chunk_0d5dd88a1bd25045` → `chunk_1854e89f3f5e9751`: imports_symbol; symbol: ArchiveSearchTool
- `chunk_0d5dd88a1bd25045` → `chunk_193cf8b06c4c4ae2`: imports_symbol; symbol: FindNextTool
- `chunk_0d5dd88a1bd25045` → `chunk_48a658afdaa0a924`: imports_symbol; symbol: VisitTool
- `chunk_0d5dd88a1bd25045` → `chunk_4d24e6856969ab2a`: imports_symbol; symbol: TextInspectorTool
- `chunk_0d5dd88a1bd25045` → `chunk_4d24e6856969ab2a`: file_import; symbol: not specified
- `chunk_0d5dd88a1bd25045` → `chunk_5036562777bf3210`: imports_symbol; symbol: SimpleTextBrowser
- `chunk_0d5dd88a1bd25045` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_0d5dd88a1bd25045` → `chunk_8ff35c4c8a0ff2d0`: imports_symbol; symbol: PageUpTool
- `chunk_0d5dd88a1bd25045` → `chunk_a55c87b2258cc1c9`: file_import; symbol: not specified
- `chunk_0d5dd88a1bd25045` → `chunk_ac073ae28bbfe718`: imports_symbol; symbol: GoogleSearchTool
- `chunk_0d5dd88a1bd25045` → `chunk_c205a07ef94436f6`: imports_symbol; symbol: ToolCallingAgent
- `chunk_0d5dd88a1bd25045` → `chunk_c67e8b7e20518df4`: imports_symbol; symbol: LiteLLMModel
- `chunk_0d5dd88a1bd25045` → `chunk_c71af9a05dd29c6c`: imports_symbol; symbol: visualizer
- `chunk_0d5dd88a1bd25045` → `chunk_c71af9a05dd29c6c`: file_import; symbol: not specified
- `chunk_0d5dd88a1bd25045` → `chunk_fbc2b9e941ed6a24`: imports_symbol; symbol: FinderTool
- `chunk_0ecdf2f41fb83df0` → `chunk_1f40a7441069b8a8`: file_import; symbol: not specified
- `chunk_0ecdf2f41fb83df0` → `chunk_4476d3e434b7e25a`: file_import; symbol: not specified
- `chunk_0ecdf2f41fb83df0` → `chunk_53b3aa2807c8155d`: file_import; symbol: not specified
- `chunk_0ecdf2f41fb83df0` → `chunk_5e4aa89ae50f2cb0`: file_import; symbol: not specified
- `chunk_0ecdf2f41fb83df0` → `chunk_6994e3fbf6d2572b`: file_import; symbol: not specified
- `chunk_0ecdf2f41fb83df0` → `chunk_6e4e1079370eff5b`: file_import; symbol: not specified
- `chunk_0ecdf2f41fb83df0` → `chunk_75bc35e124957e79`: file_import; symbol: not specified
- `chunk_0ecdf2f41fb83df0` → `chunk_95e54890ffcb511b`: file_import; symbol: not specified
- `chunk_0ecdf2f41fb83df0` → `chunk_ab76abd1d00776a7`: file_import; symbol: not specified
- `chunk_0ecdf2f41fb83df0` → `chunk_b54ad530e7ff7911`: file_import; symbol: not specified
- `chunk_0ecdf2f41fb83df0` → `chunk_c84a4593d02c5694`: file_import; symbol: not specified
- `chunk_0ecdf2f41fb83df0` → `chunk_c94b43f21521f6b9`: file_import; symbol: not specified
- `chunk_0ecdf2f41fb83df0` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_0ecdf2f41fb83df0` → `chunk_e8720d701c83438c`: file_import; symbol: not specified
- `chunk_10b59079c7ac7162` → `chunk_1e49bf366e95c986`: imports_symbol; symbol: BlaxelExecutor
- `chunk_10b59079c7ac7162` → `chunk_227df583a137cf3a`: file_import; symbol: not specified
- `chunk_10b59079c7ac7162` → `chunk_2df2b2ce5d21e128`: imports_symbol; symbol: RemotePythonExecutor
- `chunk_10b59079c7ac7162` → `chunk_37db2c519ce9a4bb`: imports_symbol; symbol: E2BExecutor
- `chunk_10b59079c7ac7162` → `chunk_3a3d0b134d3d346d`: imports_symbol; symbol: LogLevel
- `chunk_10b59079c7ac7162` → `chunk_44305bba62c90525`: imports_symbol; symbol: AgentLogger
- `chunk_10b59079c7ac7162` → `chunk_4476d3e434b7e25a`: file_import; symbol: not specified
- `chunk_10b59079c7ac7162` → `chunk_4bf433ebbc725349`: imports_symbol; symbol: FinalAnswerTool
- `chunk_10b59079c7ac7162` → `chunk_56ccbdbff1582b67`: imports_symbol; symbol: SerializationError
- `chunk_10b59079c7ac7162` → `chunk_632afdaaac4519bc`: imports_symbol; symbol: AgentError
- `chunk_10b59079c7ac7162` → `chunk_6994e3fbf6d2572b`: file_import; symbol: not specified
- `chunk_10b59079c7ac7162` → `chunk_95e54890ffcb511b`: file_import; symbol: not specified
- `chunk_10b59079c7ac7162` → `chunk_a95beb2e97fcff60`: imports_symbol; symbol: DockerExecutor
- `chunk_10b59079c7ac7162` → `chunk_c3e0e85d02526cf2`: imports_symbol; symbol: WikipediaSearchTool
- `chunk_10b59079c7ac7162` → `chunk_c84a4593d02c5694`: file_import; symbol: not specified
- `chunk_10b59079c7ac7162` → `chunk_dc16b69080ba5cf1`: imports_symbol; symbol: CodeOutput
- `chunk_10b59079c7ac7162` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_10b59079c7ac7162` → `chunk_e8720d701c83438c`: file_import; symbol: not specified
- `chunk_10b59079c7ac7162` → `chunk_e874dbfc47f81d74`: imports_symbol; symbol: ModalExecutor
- `chunk_1445026d556152f3` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_1445026d556152f3` → `chunk_c94b43f21521f6b9`: imports_symbol; symbol: MCPClient
- `chunk_1445026d556152f3` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_1e49bf366e95c986` → `chunk_1f40a7441069b8a8`: file_import; symbol: not specified
- `chunk_1f40a7441069b8a8` → `chunk_152c43e583c81bac`: imports_symbol; symbol: parse_json_blob
- `chunk_1f40a7441069b8a8` → `chunk_1a4912d9debc30e2`: imports_symbol; symbol: _is_package_available
- `chunk_1f40a7441069b8a8` → `chunk_37e597a8058f3995`: imports_symbol; symbol: encode_image_base64
- `chunk_1f40a7441069b8a8` → `chunk_6c9a0dfffce11f3f`: imports_symbol; symbol: TokenUsage
- `chunk_1f40a7441069b8a8` → `chunk_6e4e1079370eff5b`: file_import; symbol: not specified
- `chunk_1f40a7441069b8a8` → `chunk_95e54890ffcb511b`: file_import; symbol: not specified
- `chunk_1f40a7441069b8a8` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_1f40a7441069b8a8` → `chunk_a6b534aa6dafec4b`: imports_symbol; symbol: Retrying
- `chunk_1f40a7441069b8a8` → `chunk_cc241832f7a5e3a8`: imports_symbol; symbol: RateLimiter
- `chunk_1f40a7441069b8a8` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_1f40a7441069b8a8` → `chunk_f92624bfbff3c627`: imports_symbol; symbol: make_image_url
- `chunk_1f7f9e0769c9157a` → `chunk_1f40a7441069b8a8`: file_import; symbol: not specified
- `chunk_1f7f9e0769c9157a` → `chunk_23b9916741622551`: imports_symbol; symbol: ChatMessage
- `chunk_1f7f9e0769c9157a` → `chunk_44305bba62c90525`: imports_symbol; symbol: AgentLogger
- `chunk_1f7f9e0769c9157a` → `chunk_45f6250361c1ce52`: imports_symbol; symbol: ActionStep
- `chunk_1f7f9e0769c9157a` → `chunk_6c9a0dfffce11f3f`: imports_symbol; symbol: TokenUsage
- `chunk_1f7f9e0769c9157a` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_1f7f9e0769c9157a` → `chunk_85488c685b6c6896`: imports_symbol; symbol: AgentMemory
- `chunk_1f7f9e0769c9157a` → `chunk_95e54890ffcb511b`: file_import; symbol: not specified
- `chunk_1f7f9e0769c9157a` → `chunk_ab76abd1d00776a7`: file_import; symbol: not specified
- `chunk_1f7f9e0769c9157a` → `chunk_c0b427e4adc94817`: imports_symbol; symbol: stream_to_gradio
- `chunk_1f7f9e0769c9157a` → `chunk_c205a07ef94436f6`: imports_symbol; symbol: ToolCallingAgent
- `chunk_1f7f9e0769c9157a` → `chunk_d4bd1fe8d216e3bc`: imports_symbol; symbol: ChatMessageToolCall
- `chunk_1f7f9e0769c9157a` → `chunk_d79aee5546696336`: imports_symbol; symbol: Model
- `chunk_1f7f9e0769c9157a` → `chunk_dae98f0fce37ebc4`: imports_symbol; symbol: ChatMessageToolCallFunction
- `chunk_1f7f9e0769c9157a` → `chunk_dd6fb7a1fd0bd1bd`: imports_symbol; symbol: MessageRole
- `chunk_204fbb342d46746a` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_204fbb342d46746a` → `chunk_88f46bebcfc327c6`: imports_symbol; symbol: LiteLLMRouterModel
- `chunk_204fbb342d46746a` → `chunk_bf0db332f7265593`: imports_symbol; symbol: WebSearchTool
- `chunk_2065cd7a3970372b` → `chunk_1b4a7357b5851ea1`: imports_symbol; symbol: SystemPromptStep
- `chunk_2065cd7a3970372b` → `chunk_1f40a7441069b8a8`: file_import; symbol: not specified
- `chunk_2065cd7a3970372b` → `chunk_23b9916741622551`: imports_symbol; symbol: ChatMessage
- `chunk_2065cd7a3970372b` → `chunk_24c257cb4d5ec2ac`: imports_symbol; symbol: VisitWebpageTool
- `chunk_2065cd7a3970372b` → `chunk_309cf2c9ed87abd7`: imports_symbol; symbol: populate_template
- `chunk_2065cd7a3970372b` → `chunk_334d444ea0aa10bc`: imports_symbol; symbol: TransformersModel
- `chunk_2065cd7a3970372b` → `chunk_3a3d0b134d3d346d`: imports_symbol; symbol: LogLevel
- `chunk_2065cd7a3970372b` → `chunk_3b4d3238038a5683`: imports_symbol; symbol: CallbackRegistry
- `chunk_2065cd7a3970372b` → `chunk_3de1572485e2fce0`: imports_symbol; symbol: PlanningStep
- `chunk_2065cd7a3970372b` → `chunk_44305bba62c90525`: imports_symbol; symbol: AgentLogger
- `chunk_2065cd7a3970372b` → `chunk_45f6250361c1ce52`: imports_symbol; symbol: ActionStep
- `chunk_2065cd7a3970372b` → `chunk_4a995b5282a37b71`: imports_symbol; symbol: BASE_BUILTIN_MODULES
- `chunk_2065cd7a3970372b` → `chunk_4bf433ebbc725349`: imports_symbol; symbol: FinalAnswerTool
- `chunk_2065cd7a3970372b` → `chunk_4e247a04fbd5d20a`: imports_symbol; symbol: TaskStep
- `chunk_2065cd7a3970372b` → `chunk_509f54d1bf14225f`: imports_symbol; symbol: AgentToolExecutionError
- `chunk_2065cd7a3970372b` → `chunk_51084f1f1523258d`: imports_symbol; symbol: MemoryStep
- `chunk_2065cd7a3970372b` → `chunk_567b91017c0e1c6d`: imports_symbol; symbol: ToolOutput
- `chunk_2065cd7a3970372b` → `chunk_6994e3fbf6d2572b`: file_import; symbol: not specified
- `chunk_2065cd7a3970372b` → `chunk_6c9a0dfffce11f3f`: imports_symbol; symbol: TokenUsage
- `chunk_2065cd7a3970372b` → `chunk_7086f4b0a84c7e7a`: imports_symbol; symbol: PythonInterpreterTool
- `chunk_2065cd7a3970372b` → `chunk_73c889d03f829286`: imports_symbol; symbol: FinalAnswerStep
- `chunk_2065cd7a3970372b` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_2065cd7a3970372b` → `chunk_89836993219a9e82`: imports_symbol; symbol: tool
- `chunk_2065cd7a3970372b` → `chunk_8a9cc8e314eb2552`: imports_symbol; symbol: AgentImage
- `chunk_2065cd7a3970372b` → `chunk_95e54890ffcb511b`: file_import; symbol: not specified
- `chunk_2065cd7a3970372b` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_2065cd7a3970372b` → `chunk_a5cbd1df16c65113`: imports_symbol; symbol: RunResult
- `chunk_2065cd7a3970372b` → `chunk_a6ed53ae3cdaefed`: imports_symbol; symbol: Timing
- `chunk_2065cd7a3970372b` → `chunk_ab76abd1d00776a7`: file_import; symbol: not specified
- `chunk_2065cd7a3970372b` → `chunk_abf7b539a8a708a2`: imports_symbol; symbol: AgentText
- `chunk_2065cd7a3970372b` → `chunk_b54ad530e7ff7911`: file_import; symbol: not specified
- `chunk_2065cd7a3970372b` → `chunk_bbffdc70b0621a87`: imports_symbol; symbol: AgentExecutionError
- `chunk_2065cd7a3970372b` → `chunk_c205a07ef94436f6`: imports_symbol; symbol: ToolCallingAgent
- `chunk_2065cd7a3970372b` → `chunk_c79d84ede69722f5`: imports_symbol; symbol: MultiStepAgent
- `chunk_2065cd7a3970372b` → `chunk_d06ede8c80044b65`: imports_symbol; symbol: AgentGenerationError
- `chunk_2065cd7a3970372b` → `chunk_d4bd1fe8d216e3bc`: imports_symbol; symbol: ChatMessageToolCall
- `chunk_2065cd7a3970372b` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_2065cd7a3970372b` → `chunk_d79aee5546696336`: imports_symbol; symbol: Model
- `chunk_2065cd7a3970372b` → `chunk_dae98f0fce37ebc4`: imports_symbol; symbol: ChatMessageToolCallFunction
- `chunk_2065cd7a3970372b` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_2065cd7a3970372b` → `chunk_dd6fb7a1fd0bd1bd`: imports_symbol; symbol: MessageRole
- `chunk_2065cd7a3970372b` → `chunk_e7fc7d59c1e16383`: imports_symbol; symbol: DuckDuckGoSearchTool
- `chunk_234b3a94c109219a` → `chunk_227df583a137cf3a`: file_import; symbol: not specified
- `chunk_234b3a94c109219a` → `chunk_4bf433ebbc725349`: imports_symbol; symbol: FinalAnswerTool
- `chunk_234b3a94c109219a` → `chunk_6994e3fbf6d2572b`: file_import; symbol: not specified
- `chunk_234b3a94c109219a` → `chunk_86d1504445211d2a`: imports_symbol; symbol: ToolTesterMixin
- `chunk_234b3a94c109219a` → `chunk_b54ad530e7ff7911`: file_import; symbol: not specified
- `chunk_234b3a94c109219a` → `chunk_e7d231233b5b0d73`: file_import; symbol: not specified
- `chunk_2492744194c34fa5` → `chunk_1b4a7357b5851ea1`: imports_symbol; symbol: SystemPromptStep
- `chunk_2492744194c34fa5` → `chunk_23b9916741622551`: imports_symbol; symbol: ChatMessage
- `chunk_2492744194c34fa5` → `chunk_3de1572485e2fce0`: imports_symbol; symbol: PlanningStep
- `chunk_2492744194c34fa5` → `chunk_45f6250361c1ce52`: imports_symbol; symbol: ActionStep
- `chunk_2492744194c34fa5` → `chunk_4e247a04fbd5d20a`: imports_symbol; symbol: TaskStep
- `chunk_2492744194c34fa5` → `chunk_51084f1f1523258d`: imports_symbol; symbol: MemoryStep
- `chunk_2492744194c34fa5` → `chunk_6c9a0dfffce11f3f`: imports_symbol; symbol: TokenUsage
- `chunk_2492744194c34fa5` → `chunk_85488c685b6c6896`: imports_symbol; symbol: AgentMemory
- `chunk_2492744194c34fa5` → `chunk_95e54890ffcb511b`: file_import; symbol: not specified
- `chunk_2492744194c34fa5` → `chunk_a6ed53ae3cdaefed`: imports_symbol; symbol: Timing
- `chunk_2492744194c34fa5` → `chunk_ab76abd1d00776a7`: file_import; symbol: not specified
- `chunk_2492744194c34fa5` → `chunk_dd6fb7a1fd0bd1bd`: imports_symbol; symbol: MessageRole
- `chunk_29d592fc81fc7e2b` → `chunk_0afee5abeed723e8`: imports_symbol; symbol: PageDownTool
- `chunk_29d592fc81fc7e2b` → `chunk_1854e89f3f5e9751`: imports_symbol; symbol: ArchiveSearchTool
- `chunk_29d592fc81fc7e2b` → `chunk_193cf8b06c4c4ae2`: imports_symbol; symbol: FindNextTool
- `chunk_29d592fc81fc7e2b` → `chunk_458d5619085cd759`: imports_symbol; symbol: prepare_response
- `chunk_29d592fc81fc7e2b` → `chunk_458d5619085cd759`: file_import; symbol: not specified
- `chunk_29d592fc81fc7e2b` → `chunk_48a658afdaa0a924`: imports_symbol; symbol: VisitTool
- `chunk_29d592fc81fc7e2b` → `chunk_4d24e6856969ab2a`: imports_symbol; symbol: TextInspectorTool
- `chunk_29d592fc81fc7e2b` → `chunk_4d24e6856969ab2a`: file_import; symbol: not specified
- `chunk_29d592fc81fc7e2b` → `chunk_5036562777bf3210`: imports_symbol; symbol: SimpleTextBrowser
- `chunk_29d592fc81fc7e2b` → `chunk_6c9a0dfffce11f3f`: imports_symbol; symbol: TokenUsage
- `chunk_29d592fc81fc7e2b` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_29d592fc81fc7e2b` → `chunk_8ff35c4c8a0ff2d0`: imports_symbol; symbol: PageUpTool
- `chunk_29d592fc81fc7e2b` → `chunk_a55c87b2258cc1c9`: file_import; symbol: not specified
- `chunk_29d592fc81fc7e2b` → `chunk_ac073ae28bbfe718`: imports_symbol; symbol: GoogleSearchTool
- `chunk_29d592fc81fc7e2b` → `chunk_c205a07ef94436f6`: imports_symbol; symbol: ToolCallingAgent
- `chunk_29d592fc81fc7e2b` → `chunk_c67e8b7e20518df4`: imports_symbol; symbol: LiteLLMModel
- `chunk_29d592fc81fc7e2b` → `chunk_c71af9a05dd29c6c`: imports_symbol; symbol: visualizer
- `chunk_29d592fc81fc7e2b` → `chunk_c71af9a05dd29c6c`: file_import; symbol: not specified
- `chunk_29d592fc81fc7e2b` → `chunk_d79aee5546696336`: imports_symbol; symbol: Model
- `chunk_29d592fc81fc7e2b` → `chunk_e430a6564e2d161b`: imports_symbol; symbol: get_single_file_description
- `chunk_29d592fc81fc7e2b` → `chunk_e430a6564e2d161b`: imports_symbol; symbol: get_zip_description
- `chunk_29d592fc81fc7e2b` → `chunk_e430a6564e2d161b`: file_import; symbol: not specified
- `chunk_29d592fc81fc7e2b` → `chunk_fbc2b9e941ed6a24`: imports_symbol; symbol: FinderTool
- `chunk_32e780a9d7f2efaf` → `chunk_3a3d0b134d3d346d`: imports_symbol; symbol: LogLevel
- `chunk_32e780a9d7f2efaf` → `chunk_95e54890ffcb511b`: file_import; symbol: not specified
- `chunk_32e780a9d7f2efaf` → `chunk_c79d84ede69722f5`: imports_symbol; symbol: MultiStepAgent
- `chunk_44b84035a5443d1a` → `chunk_c84a4593d02c5694`: file_import; symbol: not specified
- `chunk_458d5619085cd759` → `chunk_1f40a7441069b8a8`: file_import; symbol: not specified
- `chunk_458d5619085cd759` → `chunk_d79aee5546696336`: imports_symbol; symbol: Model
- `chunk_458d5619085cd759` → `chunk_dd6fb7a1fd0bd1bd`: imports_symbol; symbol: MessageRole
- `chunk_4cf7e63037123ce6` → `chunk_24c257cb4d5ec2ac`: imports_symbol; symbol: VisitWebpageTool
- `chunk_4cf7e63037123ce6` → `chunk_632afdaaac4519bc`: imports_symbol; symbol: AgentError
- `chunk_4cf7e63037123ce6` → `chunk_7086f4b0a84c7e7a`: imports_symbol; symbol: PythonInterpreterTool
- `chunk_4cf7e63037123ce6` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_4cf7e63037123ce6` → `chunk_ac073ae28bbfe718`: imports_symbol; symbol: GoogleSearchTool
- `chunk_4cf7e63037123ce6` → `chunk_c205a07ef94436f6`: imports_symbol; symbol: ToolCallingAgent
- `chunk_4cf7e63037123ce6` → `chunk_c67e8b7e20518df4`: imports_symbol; symbol: LiteLLMModel
- `chunk_4cf7e63037123ce6` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_4d24e6856969ab2a` → `chunk_1f40a7441069b8a8`: file_import; symbol: not specified
- `chunk_4d24e6856969ab2a` → `chunk_5ffc1714a3d7f6eb`: file_import; symbol: not specified
- `chunk_4d24e6856969ab2a` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_4d24e6856969ab2a` → `chunk_d79aee5546696336`: imports_symbol; symbol: Model
- `chunk_4fcb16579b65443f` → `chunk_05fe36ff87a6bb25`: imports_symbol; symbol: evaluate_python_code
- `chunk_4fcb16579b65443f` → `chunk_1965e2f49a1a65e9`: imports_symbol; symbol: InterpreterError
- `chunk_4fcb16579b65443f` → `chunk_2387033f752b3153`: imports_symbol; symbol: ExecutionTimeoutError
- `chunk_4fcb16579b65443f` → `chunk_251455ee4afef2ed`: imports_symbol; symbol: fix_final_answer_code
- `chunk_4fcb16579b65443f` → `chunk_4bf433ebbc725349`: imports_symbol; symbol: FinalAnswerTool
- `chunk_4fcb16579b65443f` → `chunk_55f1c8ebe6da5d8e`: imports_symbol; symbol: get_safe_module
- `chunk_4fcb16579b65443f` → `chunk_6913b6f155950540`: imports_symbol; symbol: evaluate_delete
- `chunk_4fcb16579b65443f` → `chunk_6994e3fbf6d2572b`: file_import; symbol: not specified
- `chunk_4fcb16579b65443f` → `chunk_735067dfb4763306`: imports_symbol; symbol: evaluate_condition
- `chunk_4fcb16579b65443f` → `chunk_7847aa430d7b92cb`: imports_symbol; symbol: evaluate_boolop
- `chunk_4fcb16579b65443f` → `chunk_a237edab62e7666f`: imports_symbol; symbol: DANGEROUS_FUNCTIONS
- `chunk_4fcb16579b65443f` → `chunk_a237edab62e7666f`: imports_symbol; symbol: DANGEROUS_MODULES
- `chunk_4fcb16579b65443f` → `chunk_c84a4593d02c5694`: file_import; symbol: not specified
- `chunk_4fcb16579b65443f` → `chunk_c9a135cb4c3511ec`: imports_symbol; symbol: check_import_authorized
- `chunk_4fcb16579b65443f` → `chunk_e1988e2f3bf5febf`: imports_symbol; symbol: timeout
- `chunk_4fcb16579b65443f` → `chunk_f01f016e43d2457f`: imports_symbol; symbol: LocalPythonExecutor
- `chunk_4fcb16579b65443f` → `chunk_f0d9c5e9ac5d5b4f`: imports_symbol; symbol: evaluate_subscript
- `chunk_4fcb16579b65443f` → `chunk_f3ebb1605c3121df`: imports_symbol; symbol: PrintContainer
- `chunk_532b4422a106b452` → `chunk_227df583a137cf3a`: file_import; symbol: not specified
- `chunk_532b4422a106b452` → `chunk_8a9cc8e314eb2552`: imports_symbol; symbol: AgentImage
- `chunk_532b4422a106b452` → `chunk_8bf17b194cbd8ea0`: imports_symbol; symbol: AgentAudio
- `chunk_532b4422a106b452` → `chunk_abf7b539a8a708a2`: imports_symbol; symbol: AgentText
- `chunk_532b4422a106b452` → `chunk_b54ad530e7ff7911`: file_import; symbol: not specified
- `chunk_53b3aa2807c8155d` → `chunk_13b554ebc82669f2`: imports_symbol; symbol: agglomerate_stream_deltas
- `chunk_53b3aa2807c8155d` → `chunk_160a42fb07f9ab29`: imports_symbol; symbol: ChatMessageStreamDelta
- `chunk_53b3aa2807c8155d` → `chunk_1a4912d9debc30e2`: imports_symbol; symbol: _is_package_available
- `chunk_53b3aa2807c8155d` → `chunk_1f40a7441069b8a8`: file_import; symbol: not specified
- `chunk_53b3aa2807c8155d` → `chunk_45f6250361c1ce52`: imports_symbol; symbol: ActionStep
- `chunk_53b3aa2807c8155d` → `chunk_73c889d03f829286`: imports_symbol; symbol: FinalAnswerStep
- `chunk_53b3aa2807c8155d` → `chunk_8a9cc8e314eb2552`: imports_symbol; symbol: AgentImage
- `chunk_53b3aa2807c8155d` → `chunk_8bf17b194cbd8ea0`: imports_symbol; symbol: AgentAudio
- `chunk_53b3aa2807c8155d` → `chunk_ab76abd1d00776a7`: file_import; symbol: not specified
- `chunk_53b3aa2807c8155d` → `chunk_abf7b539a8a708a2`: imports_symbol; symbol: AgentText
- `chunk_53b3aa2807c8155d` → `chunk_b54ad530e7ff7911`: file_import; symbol: not specified
- `chunk_53b3aa2807c8155d` → `chunk_c79d84ede69722f5`: imports_symbol; symbol: MultiStepAgent
- `chunk_53b3aa2807c8155d` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_53b3aa2807c8155d` → `chunk_dd6fb7a1fd0bd1bd`: imports_symbol; symbol: MessageRole
- `chunk_54c78decd5b7bfd1` → `chunk_89836993219a9e82`: imports_symbol; symbol: tool
- `chunk_54c78decd5b7bfd1` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_5b686763a444fe6b` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_5e4aa89ae50f2cb0` → `chunk_334d444ea0aa10bc`: imports_symbol; symbol: TransformersModel
- `chunk_5e4aa89ae50f2cb0` → `chunk_6994e3fbf6d2572b`: file_import; symbol: not specified
- `chunk_5e4aa89ae50f2cb0` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_5e4aa89ae50f2cb0` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_5e4aa89ae50f2cb0` → `chunk_bb6ff7d20bfe89ec`: imports_symbol; symbol: OpenAIModel
- `chunk_5e4aa89ae50f2cb0` → `chunk_c205a07ef94436f6`: imports_symbol; symbol: ToolCallingAgent
- `chunk_5e4aa89ae50f2cb0` → `chunk_c67e8b7e20518df4`: imports_symbol; symbol: LiteLLMModel
- `chunk_5e4aa89ae50f2cb0` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_5e4aa89ae50f2cb0` → `chunk_d79aee5546696336`: imports_symbol; symbol: Model
- `chunk_690616948aff1cff` → `chunk_1f40a7441069b8a8`: file_import; symbol: not specified
- `chunk_690616948aff1cff` → `chunk_227df583a137cf3a`: file_import; symbol: not specified
- `chunk_690616948aff1cff` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_6994e3fbf6d2572b` → `chunk_05fe36ff87a6bb25`: imports_symbol; symbol: evaluate_python_code
- `chunk_6994e3fbf6d2572b` → `chunk_4a995b5282a37b71`: imports_symbol; symbol: BASE_BUILTIN_MODULES
- `chunk_6994e3fbf6d2572b` → `chunk_5b686763a444fe6b`: imports_symbol; symbol: PipelineTool
- `chunk_6994e3fbf6d2572b` → `chunk_65681e78bf82b808`: imports_symbol; symbol: MAX_EXECUTION_TIME_SECONDS
- `chunk_6994e3fbf6d2572b` → `chunk_6e4e1079370eff5b`: file_import; symbol: not specified
- `chunk_6994e3fbf6d2572b` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_6994e3fbf6d2572b` → `chunk_c84a4593d02c5694`: file_import; symbol: not specified
- `chunk_6d9ae40b560921ee` → `chunk_227df583a137cf3a`: file_import; symbol: not specified
- `chunk_6e4e1079370eff5b` → `chunk_0d8490413924a82d`: imports_symbol; symbol: _get_json_schema_type
- `chunk_6e4e1079370eff5b` → `chunk_1a4912d9debc30e2`: imports_symbol; symbol: _is_package_available
- `chunk_6e4e1079370eff5b` → `chunk_2037af895b0c6d50`: imports_symbol; symbol: get_source
- `chunk_6e4e1079370eff5b` → `chunk_2bcb8bef88d9e7cc`: imports_symbol; symbol: instance_to_source
- `chunk_6e4e1079370eff5b` → `chunk_2e6bb0584a494dda`: imports_symbol; symbol: TypeHintParsingException
- `chunk_6e4e1079370eff5b` → `chunk_312297a6510fef70`: imports_symbol; symbol: get_imports
- `chunk_6e4e1079370eff5b` → `chunk_3580777ec4448745`: imports_symbol; symbol: handle_agent_input_types
- `chunk_6e4e1079370eff5b` → `chunk_47ead04a08e89128`: imports_symbol; symbol: handle_agent_output_types
- `chunk_6e4e1079370eff5b` → `chunk_4a995b5282a37b71`: imports_symbol; symbol: BASE_BUILTIN_MODULES
- `chunk_6e4e1079370eff5b` → `chunk_539357549d8dfca1`: imports_symbol; symbol: is_valid_name
- `chunk_6e4e1079370eff5b` → `chunk_66d8a4eb45bee635`: imports_symbol; symbol: get_json_schema
- `chunk_6e4e1079370eff5b` → `chunk_8a9cc8e314eb2552`: imports_symbol; symbol: AgentImage
- `chunk_6e4e1079370eff5b` → `chunk_8bf17b194cbd8ea0`: imports_symbol; symbol: AgentAudio
- `chunk_6e4e1079370eff5b` → `chunk_b54ad530e7ff7911`: file_import; symbol: not specified
- `chunk_6e4e1079370eff5b` → `chunk_d05d4096a39d1d70`: imports_symbol; symbol: _convert_type_hints_to_json_schema
- `chunk_6e4e1079370eff5b` → `chunk_da73689c1431d482`: file_import; symbol: not specified
- `chunk_6e4e1079370eff5b` → `chunk_db97eeb515771e24`: imports_symbol; symbol: validate_tool_attributes
- `chunk_6e4e1079370eff5b` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_6e4e1079370eff5b` → `chunk_e40783c2b0404db8`: imports_symbol; symbol: MethodChecker
- `chunk_6e4e1079370eff5b` → `chunk_e40783c2b0404db8`: file_import; symbol: not specified
- `chunk_6f786a20d6be2307` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_6f786a20d6be2307` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_6f786a20d6be2307` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_727ed47033db474b` → `chunk_0cd1c4e5d0729a36`: imports_symbol; symbol: supports_stop_parameter
- `chunk_727ed47033db474b` → `chunk_1f40a7441069b8a8`: file_import; symbol: not specified
- `chunk_727ed47033db474b` → `chunk_227df583a137cf3a`: file_import; symbol: not specified
- `chunk_727ed47033db474b` → `chunk_23b9916741622551`: imports_symbol; symbol: ChatMessage
- `chunk_727ed47033db474b` → `chunk_321b6965c7dd88a5`: imports_symbol; symbol: AmazonBedrockModel
- `chunk_727ed47033db474b` → `chunk_334d444ea0aa10bc`: imports_symbol; symbol: TransformersModel
- `chunk_727ed47033db474b` → `chunk_48846b64eea2fa6c`: imports_symbol; symbol: MLXModel
- `chunk_727ed47033db474b` → `chunk_4bf433ebbc725349`: imports_symbol; symbol: FinalAnswerTool
- `chunk_727ed47033db474b` → `chunk_6994e3fbf6d2572b`: file_import; symbol: not specified
- `chunk_727ed47033db474b` → `chunk_86bbe9214ac50a86`: imports_symbol; symbol: remove_content_after_stop_sequences
- `chunk_727ed47033db474b` → `chunk_88f46bebcfc327c6`: imports_symbol; symbol: LiteLLMRouterModel
- `chunk_727ed47033db474b` → `chunk_89836993219a9e82`: imports_symbol; symbol: tool
- `chunk_727ed47033db474b` → `chunk_a1082fc76868d693`: imports_symbol; symbol: get_tool_call_from_text
- `chunk_727ed47033db474b` → `chunk_b8315b5f2c8ff424`: imports_symbol; symbol: get_tool_json_schema
- `chunk_727ed47033db474b` → `chunk_bb6ff7d20bfe89ec`: imports_symbol; symbol: OpenAIModel
- `chunk_727ed47033db474b` → `chunk_c67e8b7e20518df4`: imports_symbol; symbol: LiteLLMModel
- `chunk_727ed47033db474b` → `chunk_d4bd1fe8d216e3bc`: imports_symbol; symbol: ChatMessageToolCall
- `chunk_727ed47033db474b` → `chunk_d5f1a98396369af2`: imports_symbol; symbol: AzureOpenAIModel
- `chunk_727ed47033db474b` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_727ed47033db474b` → `chunk_d753157a8f7e5562`: imports_symbol; symbol: get_clean_message_list
- `chunk_727ed47033db474b` → `chunk_d79aee5546696336`: imports_symbol; symbol: Model
- `chunk_727ed47033db474b` → `chunk_dd6fb7a1fd0bd1bd`: imports_symbol; symbol: MessageRole
- `chunk_727ed47033db474b` → `chunk_e74e1d3a5044060c`: imports_symbol; symbol: parse_json_if_needed
- `chunk_745384d22d586cb6` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_75bc35e124957e79` → `chunk_06f98a7ae8c67029`: imports_symbol; symbol: validate_tool_arguments
- `chunk_75bc35e124957e79` → `chunk_13b554ebc82669f2`: imports_symbol; symbol: agglomerate_stream_deltas
- `chunk_75bc35e124957e79` → `chunk_13c64fdd87edd5cd`: imports_symbol; symbol: extract_code_from_text
- `chunk_75bc35e124957e79` → `chunk_160a42fb07f9ab29`: imports_symbol; symbol: ChatMessageStreamDelta
- `chunk_75bc35e124957e79` → `chunk_1878bd521566573e`: imports_symbol; symbol: AgentToolCallError
- `chunk_75bc35e124957e79` → `chunk_1b4a7357b5851ea1`: imports_symbol; symbol: SystemPromptStep
- `chunk_75bc35e124957e79` → `chunk_1dd2845b2d7f9265`: imports_symbol; symbol: make_init_file
- `chunk_75bc35e124957e79` → `chunk_1e49bf366e95c986`: imports_symbol; symbol: BlaxelExecutor
- `chunk_75bc35e124957e79` → `chunk_1f40a7441069b8a8`: imports_symbol; symbol: CODEAGENT_RESPONSE_FORMAT
- `chunk_75bc35e124957e79` → `chunk_1f40a7441069b8a8`: file_import; symbol: not specified
- `chunk_75bc35e124957e79` → `chunk_23b9916741622551`: imports_symbol; symbol: ChatMessage
- `chunk_75bc35e124957e79` → `chunk_251455ee4afef2ed`: imports_symbol; symbol: fix_final_answer_code
- `chunk_75bc35e124957e79` → `chunk_2bacc59b239fb76c`: imports_symbol; symbol: Monitor
- `chunk_75bc35e124957e79` → `chunk_37db2c519ce9a4bb`: imports_symbol; symbol: E2BExecutor
- `chunk_75bc35e124957e79` → `chunk_3a3d0b134d3d346d`: imports_symbol; symbol: LogLevel
- `chunk_75bc35e124957e79` → `chunk_3b4d3238038a5683`: imports_symbol; symbol: CallbackRegistry
- `chunk_75bc35e124957e79` → `chunk_3de1572485e2fce0`: imports_symbol; symbol: PlanningStep
- `chunk_75bc35e124957e79` → `chunk_44305bba62c90525`: imports_symbol; symbol: YELLOW_HEX
- `chunk_75bc35e124957e79` → `chunk_44305bba62c90525`: imports_symbol; symbol: AgentLogger
- `chunk_75bc35e124957e79` → `chunk_45f6250361c1ce52`: imports_symbol; symbol: ActionStep
- `chunk_75bc35e124957e79` → `chunk_47ead04a08e89128`: imports_symbol; symbol: handle_agent_output_types
- `chunk_75bc35e124957e79` → `chunk_48d3e5672b9332bc`: imports_symbol; symbol: AgentMaxStepsError
- `chunk_75bc35e124957e79` → `chunk_4a995b5282a37b71`: imports_symbol; symbol: BASE_BUILTIN_MODULES
- `chunk_75bc35e124957e79` → `chunk_4bf433ebbc725349`: imports_symbol; symbol: FinalAnswerTool
- `chunk_75bc35e124957e79` → `chunk_4e247a04fbd5d20a`: imports_symbol; symbol: TaskStep
- `chunk_75bc35e124957e79` → `chunk_509f54d1bf14225f`: imports_symbol; symbol: AgentToolExecutionError
- `chunk_75bc35e124957e79` → `chunk_51084f1f1523258d`: imports_symbol; symbol: MemoryStep
- `chunk_75bc35e124957e79` → `chunk_539357549d8dfca1`: imports_symbol; symbol: is_valid_name
- `chunk_75bc35e124957e79` → `chunk_5b8a4f062cdb17dc`: imports_symbol; symbol: ToolCall
- `chunk_75bc35e124957e79` → `chunk_5cc62394dbd5069c`: imports_symbol; symbol: BaseTool
- `chunk_75bc35e124957e79` → `chunk_632afdaaac4519bc`: imports_symbol; symbol: AgentError
- `chunk_75bc35e124957e79` → `chunk_6994e3fbf6d2572b`: file_import; symbol: not specified
- `chunk_75bc35e124957e79` → `chunk_6c9a0dfffce11f3f`: imports_symbol; symbol: TokenUsage
- `chunk_75bc35e124957e79` → `chunk_6e4e1079370eff5b`: file_import; symbol: not specified
- `chunk_75bc35e124957e79` → `chunk_73c889d03f829286`: imports_symbol; symbol: FinalAnswerStep
- `chunk_75bc35e124957e79` → `chunk_85488c685b6c6896`: imports_symbol; symbol: AgentMemory
- `chunk_75bc35e124957e79` → `chunk_8a9cc8e314eb2552`: imports_symbol; symbol: AgentImage
- `chunk_75bc35e124957e79` → `chunk_8bf17b194cbd8ea0`: imports_symbol; symbol: AgentAudio
- `chunk_75bc35e124957e79` → `chunk_95e54890ffcb511b`: file_import; symbol: not specified
- `chunk_75bc35e124957e79` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_75bc35e124957e79` → `chunk_a08be8ac64689457`: imports_symbol; symbol: AgentParsingError
- `chunk_75bc35e124957e79` → `chunk_a6ed53ae3cdaefed`: imports_symbol; symbol: Timing
- `chunk_75bc35e124957e79` → `chunk_a95beb2e97fcff60`: imports_symbol; symbol: DockerExecutor
- `chunk_75bc35e124957e79` → `chunk_ab76abd1d00776a7`: file_import; symbol: not specified
- `chunk_75bc35e124957e79` → `chunk_b3dc67e96b7f30ea`: imports_symbol; symbol: PythonExecutor
- `chunk_75bc35e124957e79` → `chunk_b54ad530e7ff7911`: file_import; symbol: not specified
- `chunk_75bc35e124957e79` → `chunk_bbffdc70b0621a87`: imports_symbol; symbol: AgentExecutionError
- `chunk_75bc35e124957e79` → `chunk_c496fe30973c062c`: imports_symbol; symbol: truncate_content
- `chunk_75bc35e124957e79` → `chunk_c84a4593d02c5694`: file_import; symbol: not specified
- `chunk_75bc35e124957e79` → `chunk_ce569827a0fa0cb0`: imports_symbol; symbol: create_agent_gradio_app_template
- `chunk_75bc35e124957e79` → `chunk_d06ede8c80044b65`: imports_symbol; symbol: AgentGenerationError
- `chunk_75bc35e124957e79` → `chunk_d4bd1fe8d216e3bc`: imports_symbol; symbol: ChatMessageToolCall
- `chunk_75bc35e124957e79` → `chunk_d5f0406f7083f4f4`: imports_symbol; symbol: parse_code_blobs
- `chunk_75bc35e124957e79` → `chunk_d79aee5546696336`: imports_symbol; symbol: Model
- `chunk_75bc35e124957e79` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_75bc35e124957e79` → `chunk_dd6fb7a1fd0bd1bd`: imports_symbol; symbol: MessageRole
- `chunk_75bc35e124957e79` → `chunk_e74e1d3a5044060c`: imports_symbol; symbol: parse_json_if_needed
- `chunk_75bc35e124957e79` → `chunk_e8720d701c83438c`: file_import; symbol: not specified
- `chunk_75bc35e124957e79` → `chunk_e874dbfc47f81d74`: imports_symbol; symbol: ModalExecutor
- `chunk_75bc35e124957e79` → `chunk_f01f016e43d2457f`: imports_symbol; symbol: LocalPythonExecutor
- `chunk_77650836d88a833d` → `chunk_1f40a7441069b8a8`: file_import; symbol: not specified
- `chunk_77650836d88a833d` → `chunk_95e54890ffcb511b`: file_import; symbol: not specified
- `chunk_83c137fee9749bcc` → `chunk_3de1572485e2fce0`: imports_symbol; symbol: PlanningStep
- `chunk_83c137fee9749bcc` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_83c137fee9749bcc` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_83c137fee9749bcc` → `chunk_e7fc7d59c1e16383`: imports_symbol; symbol: DuckDuckGoSearchTool
- `chunk_8cc2fe345a49f0cf` → `chunk_24c257cb4d5ec2ac`: imports_symbol; symbol: VisitWebpageTool
- `chunk_8cc2fe345a49f0cf` → `chunk_6994e3fbf6d2572b`: file_import; symbol: not specified
- `chunk_8cc2fe345a49f0cf` → `chunk_89836993219a9e82`: imports_symbol; symbol: tool
- `chunk_8cc2fe345a49f0cf` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_8cc2fe345a49f0cf` → `chunk_ac073ae28bbfe718`: imports_symbol; symbol: GoogleSearchTool
- `chunk_8cc2fe345a49f0cf` → `chunk_bf0db332f7265593`: imports_symbol; symbol: WebSearchTool
- `chunk_8cc2fe345a49f0cf` → `chunk_db97eeb515771e24`: imports_symbol; symbol: validate_tool_attributes
- `chunk_8cc2fe345a49f0cf` → `chunk_e40783c2b0404db8`: imports_symbol; symbol: MethodChecker
- `chunk_8cc2fe345a49f0cf` → `chunk_e40783c2b0404db8`: file_import; symbol: not specified
- `chunk_8cc2fe345a49f0cf` → `chunk_e7fc7d59c1e16383`: imports_symbol; symbol: DuckDuckGoSearchTool
- `chunk_8cc2fe345a49f0cf` → `chunk_ee0da0acf195d440`: imports_symbol; symbol: SpeechToTextTool
- `chunk_8d85e3348c38c5e6` → `chunk_c94b43f21521f6b9`: imports_symbol; symbol: MCPClient
- `chunk_8d85e3348c38c5e6` → `chunk_c94b43f21521f6b9`: file_import; symbol: not specified
- `chunk_94dabe933d15ebd2` → `chunk_4476d3e434b7e25a`: file_import; symbol: not specified
- `chunk_94dabe933d15ebd2` → `chunk_56ccbdbff1582b67`: imports_symbol; symbol: SerializationError
- `chunk_94dabe933d15ebd2` → `chunk_a7a02456787b28ec`: imports_symbol; symbol: SafeSerializer
- `chunk_94f6c20a679ba03b` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_94f6c20a679ba03b` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_958985d1d3787c33` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_958985d1d3787c33` → `chunk_bf0db332f7265593`: imports_symbol; symbol: WebSearchTool
- `chunk_958985d1d3787c33` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_95e54890ffcb511b` → `chunk_4a995b5282a37b71`: imports_symbol; symbol: sanitize_for_rich
- `chunk_95e54890ffcb511b` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_9646d8c4714f76ec` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_9646d8c4714f76ec` → `chunk_89836993219a9e82`: imports_symbol; symbol: tool
- `chunk_9646d8c4714f76ec` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_96d6713188685f53` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_96d6713188685f53` → `chunk_bf0db332f7265593`: imports_symbol; symbol: WebSearchTool
- `chunk_96d6713188685f53` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_96d6713188685f53` → `chunk_dd6955c378a36bfc`: imports_symbol; symbol: GradioUI
- `chunk_a55c87b2258cc1c9` → `chunk_5ffc1714a3d7f6eb`: file_import; symbol: not specified
- `chunk_a55c87b2258cc1c9` → `chunk_8507a5663911d925`: imports_symbol; symbol: FileConversionException
- `chunk_a55c87b2258cc1c9` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_a55c87b2258cc1c9` → `chunk_a043505bd604cef7`: imports_symbol; symbol: MarkdownConverter
- `chunk_a55c87b2258cc1c9` → `chunk_ab954ab040581ec1`: imports_symbol; symbol: UnsupportedFormatException
- `chunk_a55c87b2258cc1c9` → `chunk_c76f0353c5e982d0`: file_import; symbol: not specified
- `chunk_a95400944a4c2c86` → `chunk_1f40a7441069b8a8`: file_import; symbol: not specified
- `chunk_a95400944a4c2c86` → `chunk_334d444ea0aa10bc`: imports_symbol; symbol: TransformersModel
- `chunk_a95400944a4c2c86` → `chunk_4a3457045a966a61`: imports_symbol; symbol: load_model
- `chunk_a95400944a4c2c86` → `chunk_5e4aa89ae50f2cb0`: file_import; symbol: not specified
- `chunk_a95400944a4c2c86` → `chunk_bb6ff7d20bfe89ec`: imports_symbol; symbol: OpenAIModel
- `chunk_a95400944a4c2c86` → `chunk_c67e8b7e20518df4`: imports_symbol; symbol: LiteLLMModel
- `chunk_a95400944a4c2c86` → `chunk_c84a4593d02c5694`: file_import; symbol: not specified
- `chunk_a95400944a4c2c86` → `chunk_cda1f5ebca1274f1`: file_import; symbol: not specified
- `chunk_a95400944a4c2c86` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_a95400944a4c2c86` → `chunk_dc16b69080ba5cf1`: imports_symbol; symbol: CodeOutput
- `chunk_a95400944a4c2c86` → `chunk_f01f016e43d2457f`: imports_symbol; symbol: LocalPythonExecutor
- `chunk_ab76abd1d00776a7` → `chunk_1f40a7441069b8a8`: file_import; symbol: not specified
- `chunk_ab76abd1d00776a7` → `chunk_23b9916741622551`: imports_symbol; symbol: ChatMessage
- `chunk_ab76abd1d00776a7` → `chunk_3a3d0b134d3d346d`: imports_symbol; symbol: LogLevel
- `chunk_ab76abd1d00776a7` → `chunk_44305bba62c90525`: imports_symbol; symbol: AgentLogger
- `chunk_ab76abd1d00776a7` → `chunk_48289a7c75b9c850`: imports_symbol; symbol: get_dict_from_nested_dataclasses
- `chunk_ab76abd1d00776a7` → `chunk_632afdaaac4519bc`: imports_symbol; symbol: AgentError
- `chunk_ab76abd1d00776a7` → `chunk_6c9a0dfffce11f3f`: imports_symbol; symbol: TokenUsage
- `chunk_ab76abd1d00776a7` → `chunk_95b0973b4c131dd8`: imports_symbol; symbol: make_json_serializable
- `chunk_ab76abd1d00776a7` → `chunk_95e54890ffcb511b`: file_import; symbol: not specified
- `chunk_ab76abd1d00776a7` → `chunk_a6ed53ae3cdaefed`: imports_symbol; symbol: Timing
- `chunk_ab76abd1d00776a7` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_ab76abd1d00776a7` → `chunk_dd6fb7a1fd0bd1bd`: imports_symbol; symbol: MessageRole
- `chunk_abab5e453b032ae7` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_abab5e453b032ae7` → `chunk_89836993219a9e82`: imports_symbol; symbol: tool
- `chunk_abab5e453b032ae7` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_b36ace8abe06d509` → `chunk_af07f60a3585a62e`: imports_symbol; symbol: _escape_xpath_string
- `chunk_b36ace8abe06d509` → `chunk_c2334f083ffa2356`: imports_symbol; symbol: search_item_ctrl_f
- `chunk_b36ace8abe06d509` → `chunk_cda1f5ebca1274f1`: file_import; symbol: not specified
- `chunk_b54ad530e7ff7911` → `chunk_1a4912d9debc30e2`: imports_symbol; symbol: _is_package_available
- `chunk_b54ad530e7ff7911` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_b9968368b14bfe6d` → `chunk_227df583a137cf3a`: file_import; symbol: not specified
- `chunk_b9968368b14bfe6d` → `chunk_2387033f752b3153`: imports_symbol; symbol: ExecutionTimeoutError
- `chunk_b9968368b14bfe6d` → `chunk_24c257cb4d5ec2ac`: imports_symbol; symbol: VisitWebpageTool
- `chunk_b9968368b14bfe6d` → `chunk_6994e3fbf6d2572b`: file_import; symbol: not specified
- `chunk_b9968368b14bfe6d` → `chunk_7086f4b0a84c7e7a`: imports_symbol; symbol: PythonInterpreterTool
- `chunk_b9968368b14bfe6d` → `chunk_86d1504445211d2a`: imports_symbol; symbol: ToolTesterMixin
- `chunk_b9968368b14bfe6d` → `chunk_b54ad530e7ff7911`: file_import; symbol: not specified
- `chunk_b9968368b14bfe6d` → `chunk_bf0db332f7265593`: imports_symbol; symbol: WebSearchTool
- `chunk_b9968368b14bfe6d` → `chunk_c3e0e85d02526cf2`: imports_symbol; symbol: WikipediaSearchTool
- `chunk_b9968368b14bfe6d` → `chunk_c84a4593d02c5694`: file_import; symbol: not specified
- `chunk_b9968368b14bfe6d` → `chunk_e7d231233b5b0d73`: file_import; symbol: not specified
- `chunk_b9968368b14bfe6d` → `chunk_e7fc7d59c1e16383`: imports_symbol; symbol: DuckDuckGoSearchTool
- `chunk_b9968368b14bfe6d` → `chunk_ee0da0acf195d440`: imports_symbol; symbol: SpeechToTextTool
- `chunk_bbe38dec406ff123` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_bbe38dec406ff123` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_bbe38dec406ff123` → `chunk_c67e8b7e20518df4`: imports_symbol; symbol: LiteLLMModel
- `chunk_c2552355e1f1f039` → `chunk_24c257cb4d5ec2ac`: imports_symbol; symbol: VisitWebpageTool
- `chunk_c2552355e1f1f039` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_c2552355e1f1f039` → `chunk_bf0db332f7265593`: imports_symbol; symbol: WebSearchTool
- `chunk_c2552355e1f1f039` → `chunk_c205a07ef94436f6`: imports_symbol; symbol: ToolCallingAgent
- `chunk_c2552355e1f1f039` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_c71af9a05dd29c6c` → `chunk_89836993219a9e82`: imports_symbol; symbol: tool
- `chunk_c71af9a05dd29c6c` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_c84a4593d02c5694` → `chunk_4a995b5282a37b71`: imports_symbol; symbol: BASE_BUILTIN_MODULES
- `chunk_c84a4593d02c5694` → `chunk_6e4e1079370eff5b`: file_import; symbol: not specified
- `chunk_c84a4593d02c5694` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_c84a4593d02c5694` → `chunk_c496fe30973c062c`: imports_symbol; symbol: truncate_content
- `chunk_c84a4593d02c5694` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_c94b43f21521f6b9` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_cda1f5ebca1274f1` → `chunk_4a3457045a966a61`: imports_symbol; symbol: load_model
- `chunk_cda1f5ebca1274f1` → `chunk_5e4aa89ae50f2cb0`: file_import; symbol: not specified
- `chunk_cda1f5ebca1274f1` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_cda1f5ebca1274f1` → `chunk_89836993219a9e82`: imports_symbol; symbol: tool
- `chunk_cda1f5ebca1274f1` → `chunk_bf0db332f7265593`: imports_symbol; symbol: WebSearchTool
- `chunk_d9b26eb454a395a8` → `chunk_312297a6510fef70`: imports_symbol; symbol: get_imports
- `chunk_d9b26eb454a395a8` → `chunk_66d8a4eb45bee635`: imports_symbol; symbol: get_json_schema
- `chunk_d9b26eb454a395a8` → `chunk_906798202f9bfe38`: imports_symbol; symbol: DocstringParsingException
- `chunk_d9b26eb454a395a8` → `chunk_da73689c1431d482`: file_import; symbol: not specified
- `chunk_d9f7f1f784e28530` → `chunk_227df583a137cf3a`: file_import; symbol: not specified
- `chunk_d9f7f1f784e28530` → `chunk_86d1504445211d2a`: imports_symbol; symbol: ToolTesterMixin
- `chunk_d9f7f1f784e28530` → `chunk_e7d231233b5b0d73`: file_import; symbol: not specified
- `chunk_d9f7f1f784e28530` → `chunk_e7fc7d59c1e16383`: imports_symbol; symbol: DuckDuckGoSearchTool
- `chunk_db0b792f63ae0bea` → `chunk_7a9d2e02e6e8a9fd`: imports_symbol; symbol: CodeAgent
- `chunk_db0b792f63ae0bea` → `chunk_c67e8b7e20518df4`: imports_symbol; symbol: LiteLLMModel
- `chunk_db0b792f63ae0bea` → `chunk_c94b43f21521f6b9`: imports_symbol; symbol: MCPClient
- `chunk_db0b792f63ae0bea` → `chunk_d7218d91d6c17f8e`: imports_symbol; symbol: InferenceClientModel
- `chunk_dc850b7f0d3d3f9b` → `chunk_ab76abd1d00776a7`: file_import; symbol: not specified
- `chunk_e08b69c3a756297f` → `chunk_160a42fb07f9ab29`: imports_symbol; symbol: ChatMessageStreamDelta
- `chunk_e08b69c3a756297f` → `chunk_1f40a7441069b8a8`: file_import; symbol: not specified
- `chunk_e08b69c3a756297f` → `chunk_3de1572485e2fce0`: imports_symbol; symbol: PlanningStep
- `chunk_e08b69c3a756297f` → `chunk_45f6250361c1ce52`: imports_symbol; symbol: ActionStep
- `chunk_e08b69c3a756297f` → `chunk_5b8a4f062cdb17dc`: imports_symbol; symbol: ToolCall
- `chunk_e08b69c3a756297f` → `chunk_6c9a0dfffce11f3f`: imports_symbol; symbol: TokenUsage
- `chunk_e08b69c3a756297f` → `chunk_73c889d03f829286`: imports_symbol; symbol: FinalAnswerStep
- `chunk_e08b69c3a756297f` → `chunk_8a9cc8e314eb2552`: imports_symbol; symbol: AgentImage
- `chunk_e08b69c3a756297f` → `chunk_8bf17b194cbd8ea0`: imports_symbol; symbol: AgentAudio
- `chunk_e08b69c3a756297f` → `chunk_93bd7c68efd93883`: imports_symbol; symbol: pull_messages_from_step
- `chunk_e08b69c3a756297f` → `chunk_95e54890ffcb511b`: file_import; symbol: not specified
- `chunk_e08b69c3a756297f` → `chunk_a6ed53ae3cdaefed`: imports_symbol; symbol: Timing
- `chunk_e08b69c3a756297f` → `chunk_ab76abd1d00776a7`: file_import; symbol: not specified
- `chunk_e08b69c3a756297f` → `chunk_abf7b539a8a708a2`: imports_symbol; symbol: AgentText
- `chunk_e08b69c3a756297f` → `chunk_b54ad530e7ff7911`: file_import; symbol: not specified
- `chunk_e08b69c3a756297f` → `chunk_c0b427e4adc94817`: imports_symbol; symbol: stream_to_gradio
- `chunk_e08b69c3a756297f` → `chunk_dd6955c378a36bfc`: imports_symbol; symbol: GradioUI
- `chunk_e0e3dc130e0bcb46` → `chunk_0d5dd88a1bd25045`: imports_symbol; symbol: create_agent
- `chunk_e0e3dc130e0bcb46` → `chunk_dd6955c378a36bfc`: imports_symbol; symbol: GradioUI
- `chunk_e40783c2b0404db8` → `chunk_2037af895b0c6d50`: imports_symbol; symbol: get_source
- `chunk_e40783c2b0404db8` → `chunk_4a995b5282a37b71`: imports_symbol; symbol: BASE_BUILTIN_MODULES
- `chunk_e40783c2b0404db8` → `chunk_539357549d8dfca1`: imports_symbol; symbol: is_valid_name
- `chunk_e40783c2b0404db8` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_e430a6564e2d161b` → `chunk_632afdaaac4519bc`: imports_symbol; symbol: AgentError
- `chunk_e430a6564e2d161b` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_e7d231233b5b0d73` → `chunk_06f98a7ae8c67029`: imports_symbol; symbol: validate_tool_arguments
- `chunk_e7d231233b5b0d73` → `chunk_227df583a137cf3a`: file_import; symbol: not specified
- `chunk_e7d231233b5b0d73` → `chunk_5cc62394dbd5069c`: imports_symbol; symbol: AUTHORIZED_TYPES
- `chunk_e7d231233b5b0d73` → `chunk_89836993219a9e82`: imports_symbol; symbol: tool
- `chunk_e7d231233b5b0d73` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_e7d231233b5b0d73` → `chunk_b54ad530e7ff7911`: file_import; symbol: not specified
- `chunk_e7d231233b5b0d73` → `chunk_b86662c65683727b`: imports_symbol; symbol: launch_gradio_demo
- `chunk_e7d231233b5b0d73` → `chunk_d3883465dc4f5bb1`: imports_symbol; symbol: ToolCollection
- `chunk_e8720d701c83438c` → `chunk_15f6fe775202bdc9`: imports_symbol; symbol: get_tools_definition_code
- `chunk_e8720d701c83438c` → `chunk_3a3d0b134d3d346d`: imports_symbol; symbol: LogLevel
- `chunk_e8720d701c83438c` → `chunk_4476d3e434b7e25a`: file_import; symbol: not specified
- `chunk_e8720d701c83438c` → `chunk_4bf433ebbc725349`: imports_symbol; symbol: FinalAnswerTool
- `chunk_e8720d701c83438c` → `chunk_56ccbdbff1582b67`: imports_symbol; symbol: SerializationError
- `chunk_e8720d701c83438c` → `chunk_632afdaaac4519bc`: imports_symbol; symbol: AgentError
- `chunk_e8720d701c83438c` → `chunk_6994e3fbf6d2572b`: file_import; symbol: not specified
- `chunk_e8720d701c83438c` → `chunk_6e4e1079370eff5b`: file_import; symbol: not specified
- `chunk_e8720d701c83438c` → `chunk_95e54890ffcb511b`: file_import; symbol: not specified
- `chunk_e8720d701c83438c` → `chunk_9dcfc65ca586b1bb`: imports_symbol; symbol: Tool
- `chunk_e8720d701c83438c` → `chunk_a7a02456787b28ec`: imports_symbol; symbol: SafeSerializer
- `chunk_e8720d701c83438c` → `chunk_b3dc67e96b7f30ea`: imports_symbol; symbol: PythonExecutor
- `chunk_e8720d701c83438c` → `chunk_c84a4593d02c5694`: file_import; symbol: not specified
- `chunk_e8720d701c83438c` → `chunk_dc16b69080ba5cf1`: imports_symbol; symbol: CodeOutput
- `chunk_e8720d701c83438c` → `chunk_dc850b7f0d3d3f9b`: file_import; symbol: not specified
- `chunk_ee0da0acf195d440` → `chunk_b54ad530e7ff7911`: file_import; symbol: not specified

Other source sections remain available in `chunks.jsonl`; code is stored only once.

## 3. Business risks

Analysis status: **COMPLETED**

### risk_0000: Timed-out executions keep changing shared interpreter state

**Finding:** When a local execution exceeds its timeout, the timed-out code continues running against shared state and later runs reuse that altered state.

**Trigger:** A caller runs code through the stateful local executor and the code exceeds the configured timeout.

**Observed behavior:** When the time limit is reached, the submitted code continues running in a worker thread against the same shared state object after the timeout boundary.

**Business impact:** Later runs use stale variables and logs from work that already timed out, so the timeout no longer contains the failed step.

**Expected behavior:** Timed-out executions stop mutating shared interpreter state and cannot influence later executions.

**Associated workflow IDs:** `business_path_67020919c6a08dce`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| evaluate_python_code | `src/smolagents/local_python_executor.py` | `chunk_05fe36ff87a6bb25` |
| Source section | `tests/test_local_python_executor.py` | `chunk_3165ae68c5cb60d4` |
| PythonInterpreterTool.forward | `src/smolagents/default_tools.py` | `chunk_7086f4b0a84c7e7a` |
| TestPrintContainer | `tests/test_local_python_executor.py` | `chunk_9d90fd6344d0910d` |
| timeout | `src/smolagents/local_python_executor.py` | `chunk_e1988e2f3bf5febf` |
| LocalPythonExecutor._check_authorized_imports_are_installed | `src/smolagents/local_python_executor.py` | `chunk_f01f016e43d2457f` |
| Source section | `tests/test_local_python_executor.py` | `chunk_fc609bedeab15d64` |
